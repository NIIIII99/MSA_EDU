package io.naraplatform.artcenter;

public class ArtcenterBootApplicationTests {

    public void contextLoads() {
    }

}
