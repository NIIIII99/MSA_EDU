package io.naraplatform.artcenter.query.rest.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.artcenter.domain.catalog.query.spec.CatalogQueryService;
import io.naraplatform.share.util.json.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class CatalogQueryResource implements CatalogQueryService {

    @Autowired
    CatalogQueryService catalogQueryService;

    @Override
    @GetMapping(value="/catalog/{catalogId}")
    public Catalog findCatalog(@PathVariable(value="catalogId") String catalogId) {
        //
        return catalogQueryService.findCatalog(catalogId);
    }

    @Override
    @GetMapping(value="/catalog/{catalogId}/category")
    public List<Category> findCategoris(@PathVariable(value="catalogId") String catalogId) {
        //
        return catalogQueryService.findCategoris(catalogId);
    }

    @Override
    @GetMapping(value="/category/{categoryId}")
    public Category findCategory(@PathVariable(value="categoryId") String categoryId) {
        //
        return catalogQueryService.findCategory(categoryId);
    }

    @Override
    @GetMapping(value="/category")
    public List<Category> findCategoris() {
        //
        return catalogQueryService.findCategoris();
    }

    @Override
    @GetMapping(value="/item/{itemId}")
    public Item findItem(@PathVariable(value="itemId") String itemId) {
        //
        return catalogQueryService.findItem(itemId);
    }

    @Override
    @GetMapping(value="/item")
    public List<Item> findItemByCatalogAndCategory(@RequestParam(value="catalogId") String catalogId, @RequestParam(value="categoryId") String categoryId, @RequestParam(value="offset", defaultValue="0") int offset, @RequestParam(value="limit", defaultValue="8") int limit) {
        //
        return catalogQueryService.findItemByCatalogAndCategory(catalogId, categoryId, offset, limit);
    }

    @Override
    @GetMapping(value="/rom/catalog/{catalogId}")
    public CatalogRom findCatalogRom(@RequestParam(value="langCode") String langCode, @PathVariable(value="catalogId") String catalogId) {
        //
        return catalogQueryService.findCatalogRom(langCode, catalogId);
    }

    @Override
    @GetMapping(value="/rom/catalog")
    public List<CatalogRom> findAllCatalogRoms(@RequestParam(value="langCode") String langCode) {
        //
        return catalogQueryService.findAllCatalogRoms(langCode);
    }

    @Override
    @GetMapping(value="/rom/catalog/{catalogId}/category")
    public List<CategoryRom> findCategoryRoms(@RequestParam(value="langCode") String langCode, @PathVariable(value="catalogId") String catalogId) {
        //
        return catalogQueryService.findCategoryRoms(langCode, catalogId);
    }

    @Override
    @GetMapping(value="/rom/category/{categoryId}")
    public CategoryRom findCategoryRom(@RequestParam(value="langCode") String langCode, @PathVariable(value="categoryId") String categoryId) {
        //
        return catalogQueryService.findCategoryRom(langCode, categoryId);
    }

    @Override
    @GetMapping(value="/rom/catalog/{catalogId}/category/{categoryId}/item")
    public List<ItemRom> findItemRoms(@PathVariable(value="catalogId") String catalogId, @PathVariable(value="categoryId") String categoryId, @RequestParam(value="langCode") String langCode, @RequestParam(value="offset", defaultValue="0") int offset, @RequestParam(value="limit", defaultValue="8") int limit, @RequestParam(value="keyword", required=false) Optional<String> keyword) {
        //
        return catalogQueryService.findItemRoms(catalogId, categoryId, langCode, offset, limit, keyword);
    }

    @Override
    @GetMapping(value="/rom/catalog/{catalogId}/item")
    public List<ItemRom> findItemRoms(@PathVariable(value="catalogId") String catalogId, @RequestParam(value="langCode") String langCode, @RequestParam(value="offset", defaultValue="0") int offset, @RequestParam(value="limit", defaultValue="8") int limit, @RequestParam(value="keyword", required=false) Optional<String> keyword) {
        //
        return catalogQueryService.findItemRoms(catalogId, langCode, offset, limit, keyword);
    }

    @Override
    @GetMapping(value="/rom/item/troupe/{troupeId}")
    public List<ItemRom> findItemRoms(@PathVariable(value="troupeId") String troupeId, @RequestParam(value="langCode") String langCode, @RequestParam(value="offset", defaultValue="0") int offset, @RequestParam(value="limit", defaultValue="8") int limit) {
        //
        return catalogQueryService.findItemRoms(troupeId, langCode, offset, limit);
    }

    @Override
    @GetMapping(value="/rom/catalog/{catalogId}/item/subscription")
    public List<ItemRom> findItemRomsBySubscriptionCount(@PathVariable(value="catalogId") String catalogId, @RequestParam(value="langCode") String langCode, @RequestParam(value="offset", defaultValue="0") int offset, @RequestParam(value="limit", defaultValue="8") int limit) {
        //
        return catalogQueryService.findItemRomsBySubscriptionCount(catalogId, langCode, offset, limit);
    }

    @Override
    @GetMapping(value="/rom/catalog/{catalogId}/item/sales")
    public List<ItemRom> findItemRomsBySalesAmount(@PathVariable(value="catalogId") String catalogId, @RequestParam(value="langCode") String langCode, @RequestParam(value="offset", defaultValue="0") int offset, @RequestParam(value="limit", defaultValue="8") int limit) {
        //
        return catalogQueryService.findItemRomsBySalesAmount(catalogId, langCode, offset, limit);
    }
}
