package io.naraplatform.artcenter.store.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;

import java.util.List;

public interface CatalogDomainStore {

    void create(Catalog catalog);
    Catalog retrieve(String catalogId);
    void update(Catalog catalog);
    void delete(String catalogId);

    Category retrieveCategory(String categoryId);
    List<Category> retrieveCategoriesByCatalog(String catalogId);

}
