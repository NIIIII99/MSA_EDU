package io.naraplatform.artcenter.query.listen.nation;

import io.naraplatform.artcenter.domain.nation.event.NationEvent;
import io.naraplatform.artcenter.store.nation.NationDomainStore;
import io.naraplatform.share.exception.IllegalRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(NationEventSink.class)
public class NationEventConsumer {

    @Autowired
    NationDomainStore nationDomainStore;

    @StreamListener(NationEventSink.NATION_INPUT)
    public void listenDramaEvent(@Payload NationEvent nationEvent) {
        //
        switch (nationEvent.getType()) {
            case Created:
                nationDomainStore.create(nationEvent.getNation());
                break;
            case Updated:
                nationDomainStore.update(nationEvent.getNation());
                break;
            case Deleted:
                nationDomainStore.delete(nationEvent.getId());
                break;
            default:
                throw new IllegalRequestException(String.format("[%s] is not permitted event type", nationEvent.getType().toString()));
        }
    }

}
