package io.naraplatform.artcenter.query.listen.order;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface SubscriptionEventSink {

    String SUBSCRIPTION_INPUT = "subscriptionInput";

	@Input(SUBSCRIPTION_INPUT)
    MessageChannel subscriptionInput();

}
