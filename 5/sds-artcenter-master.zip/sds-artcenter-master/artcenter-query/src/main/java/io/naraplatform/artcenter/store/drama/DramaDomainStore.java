package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;

import java.util.List;

public interface DramaDomainStore {
    //
    void create(Drama drama);
    Drama retrieve(String dramaId);
    List<Drama> retrieveDramasByTroupe(String troupeId, int offset, int limit);
    void update(Drama drama);
    void delete(String dramaId);

}
