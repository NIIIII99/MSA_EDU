package io.naraplatform.artcenter.query.listen.catalog;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface SubscriptionCatalogEventSink {

    String SUBSCRIPTION_CATALOG_INPUT = "subscriptionCatalogInput";

	@Input(SUBSCRIPTION_CATALOG_INPUT)
    MessageChannel subscriptionCatalogInput();

}
