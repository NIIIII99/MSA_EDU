package io.naraplatform.artcenter.query.rest.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.domain.troupe.query.spec.TroupeQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("troupe")
public class TroupeQueryResource implements TroupeQueryService {
	//
	@Autowired
	TroupeQueryService troupeQueryService;
	
	@Override
	@GetMapping("/sample")
    public Troupe findTroupeSample() {
        return Troupe.sample();
    }

	@Override
	@GetMapping("/{id}")
    public Troupe findTroupe(@PathVariable("id") String id) {
        return troupeQueryService.findTroupe(id);
    }

	@Override
	@GetMapping(value="/rom/{id}")
    public String findTroupeJson(@PathVariable("id") String troupeId) {
	    //
		return troupeQueryService.findTroupeJson(troupeId);
    }

	@Override
	@GetMapping("/email/{email}")
    public Troupe findTroupeByEmail(@PathVariable("email") String email) {
        return troupeQueryService.findTroupeByEmail(email);
    }

	@Override
	@GetMapping("/email/{email}/exist")
    public boolean existTroupeByEmail(@PathVariable("email") String email) {
        return troupeQueryService.existTroupeByEmail(email);
    }

	@Override
	@GetMapping(value="/rom/email/{email}")
    public String findTroupeJsonByEmail(@PathVariable("email") String email) {
        return troupeQueryService.findTroupeJsonByEmail(email);
    }

	@Override
	@GetMapping("/userId/{userId}")
    public Troupe findTroupeByLoginUserId(@PathVariable("userId") String loginUserId) {
		return troupeQueryService.findTroupeByLoginUserId(loginUserId);
    }

	@Override
    @GetMapping(value="/rom/userId/{userId}")
    public String findTroupeJsonByLoginUserId(@PathVariable("userId") String loginUserId) {
    	return troupeQueryService.findTroupeJsonByLoginUserId(loginUserId);
    }

	@Override
	@GetMapping(value={"/", ""})
    public List<Troupe> findAllTroupes(@RequestParam("offset") int offset,
                                       @RequestParam("limit") int limit) {
        return troupeQueryService.findAllTroupes(offset, limit);
    }

	@Override
	@GetMapping(value={"/rom"})
    public List<String> findAllTroupeJsons(@RequestParam("offset") int offset,
                                           @RequestParam("limit") int limit) {
        return troupeQueryService.findAllTroupeJsons(offset, limit);
    }
}
