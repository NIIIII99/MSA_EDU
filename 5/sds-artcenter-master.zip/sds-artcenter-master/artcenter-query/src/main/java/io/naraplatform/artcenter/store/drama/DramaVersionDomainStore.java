package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;

import java.util.List;

public interface DramaVersionDomainStore {

    void create(DramaVersion dramaVersion);
    DramaVersion retrieve(String dramaVersionId);
    DramaVersion retrieve(String dramaId, String versionName);
    List<DramaVersion> retrieveAllByDramaId(String dramaId);
    List<DramaVersion> retrieveAllByDramaId(String dramaId, int offset, int limit);
    void update(DramaVersion dramaVersion);
    void delete(String dramaVersionId);

}
