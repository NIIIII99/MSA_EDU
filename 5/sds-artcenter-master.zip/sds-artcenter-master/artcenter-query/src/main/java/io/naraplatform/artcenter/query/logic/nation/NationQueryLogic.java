package io.naraplatform.artcenter.query.logic.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.artcenter.domain.nation.query.spec.NationQueryService;
import io.naraplatform.artcenter.store.nation.NationDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NationQueryLogic implements NationQueryService {

    @Autowired
    NationDomainStore nationDomainStore;

    @Override
    public Nation findNation(String nationId) {
        //
        return nationDomainStore.retrieve(nationId);
    }

    @Override
    public List<Nation> findAllNations() {
        //
        return nationDomainStore.retrieveAll();
    }
}
