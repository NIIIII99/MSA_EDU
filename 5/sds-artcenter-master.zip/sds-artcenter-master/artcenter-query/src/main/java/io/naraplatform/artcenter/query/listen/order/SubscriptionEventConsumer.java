package io.naraplatform.artcenter.query.listen.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.domain.order.event.SubscriptionEvent;
import io.naraplatform.artcenter.store.order.SubscriptionDomainStore;
import io.naraplatform.share.exception.IllegalRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(SubscriptionEventSink.class)
public class SubscriptionEventConsumer {

    @Autowired
    SubscriptionDomainStore subscriptionDomainStore;

    @StreamListener(SubscriptionEventSink.SUBSCRIPTION_INPUT)
    public void listenDramaEvent(@Payload SubscriptionEvent subscriptionEvent) {
        //
        Subscription subscription = subscriptionEvent.getSubscription();

        switch (subscriptionEvent.getType()) {
            case Created:
                subscriptionDomainStore.create(subscription);
                break;
            case StateChanged:
                subscriptionDomainStore.update(subscription);
                break;
            default:
                throw new IllegalRequestException(String.format("[%s] is not permitted event type", subscriptionEvent.getType().toString()));
        }
    }

}
