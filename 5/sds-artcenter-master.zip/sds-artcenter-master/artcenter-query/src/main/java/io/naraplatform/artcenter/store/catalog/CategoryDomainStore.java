package io.naraplatform.artcenter.store.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;

import java.util.List;

public interface CategoryDomainStore {
    //
    void create(Category category);
    Category retrieve(String categoryId);
    List<Category> retrieveAll();
    void update(Category category);
    void delete(String categoryId);
    List<Category> retrieveAllByCatalogId(String catalogId);
}
