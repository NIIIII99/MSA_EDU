package io.naraplatform.artcenter.store.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;

import java.util.List;

public interface TroupeRomStore {
    //
	void create(Troupe troupe);
    String retrieveJson(String troupeId);
    String retrieveJsonByEmail(String email);
    String retrieveJsonByLoginUserId(String loginUserId);
    List<String> retrieveAllJsons(int offset, int limit);

    void update(Troupe troupe);
    void delete(String troupeId);

    boolean existsByEmail(String email);
}
