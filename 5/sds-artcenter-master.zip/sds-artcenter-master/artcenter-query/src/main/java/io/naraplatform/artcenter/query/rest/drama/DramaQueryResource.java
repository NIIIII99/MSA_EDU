package io.naraplatform.artcenter.query.rest.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;
import io.naraplatform.artcenter.domain.drama.query.spec.DramaQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/drama")
public class DramaQueryResource implements DramaQueryService {

    @Autowired
    DramaQueryService dramaQueryService;

    @Override
    @GetMapping(value="/{dramaId}")
    public Drama findDrama(@PathVariable(value="dramaId") String dramaId) {
        //
        return dramaQueryService.findDrama(dramaId);
    }

    @Override
    @GetMapping("/ticket/{dramaTicketId}")
    public DramaTicket findDramaTicket(@PathVariable(value="dramaTicketId") String dramaTicketId) {
        //
        return dramaQueryService.findDramaTicket(dramaTicketId);
    }

    @Override
    @GetMapping(value="/{dramaId}/ticket")
    public DramaTicket findDramaTicketByDrama(@PathVariable(value="dramaId") String dramaId) {
        //
        return dramaQueryService.findDramaTicketByDrama(dramaId);
    }

    @Override
    @GetMapping(value="/rom/{dramaId}")
    public DramaRom findDramaRom(@RequestParam(value="langCode") String lang, @PathVariable(value="dramaId") String dramaId) {
        //
        return dramaQueryService.findDramaRom(lang, dramaId);
    }

    @Override
    @GetMapping(value="/feature/{featureId}")
    public DramaFeature findFeature(@PathVariable(value="featureId") String featureId) {
        //
        return dramaQueryService.findFeature(featureId);
    }

    @Override
    @GetMapping(value="/{dramaId}/feature")
    public List<DramaFeature> findFeatures(@PathVariable(value="dramaId") String dramaId) {
        //
        return dramaQueryService.findFeatures(dramaId);
    }

    @Override
    @GetMapping(value="/rom/{dramaId}/feature")
    public List<DramaFeatureRom> findFeatureRoms(@PathVariable(value="dramaId") String dramaId, @RequestParam(value="langCode") String lang) {
        //
        return dramaQueryService.findFeatureRoms(dramaId, lang);
    }

    @Override
    @GetMapping(value="/{dramaId}/version/latest")
    public DramaVersion findLatestVersion(@PathVariable(value="dramaId") String dramaId) {
        //
        return dramaQueryService.findLatestVersion(dramaId);
    }

    @Override
    @GetMapping(value="/{dramaId}/version")
    public List<DramaVersion> findVersions(@PathVariable(value="dramaId") String dramaId, @RequestParam(value="offset") int offset, @RequestParam(value="limit") int limit) {
        //
        return dramaQueryService.findVersions(dramaId, offset, limit);
    }

    @Override
    @GetMapping(value="/rom/{dramaId}/version/latest")
    public DramaVersionRom findLatestVersionRom(@PathVariable(value="dramaId") String dramaId) {
        //
        return dramaQueryService.findLatestVersionRom(dramaId);
    }

    @Override
    @GetMapping(value="/rom/{dramaId}/version")
    public List<DramaVersionRom> findVersionRoms(@PathVariable(value="dramaId") String dramaId, @RequestParam(value="offset") int offset, @RequestParam(value="limit") int limit) {
        //
        return dramaQueryService.findVersionRoms(dramaId, offset, limit);
    }

    @Override
    @GetMapping(value="/troupe/{troupeId}")
    public List<Drama> findDramaByTroupe(@PathVariable(value="troupeId") String troupeId, @RequestParam(value="offset") int offset, @RequestParam(value="limit") int limit) {
        //
        return dramaQueryService.findDramaByTroupe(troupeId, offset, limit);
    }
}
