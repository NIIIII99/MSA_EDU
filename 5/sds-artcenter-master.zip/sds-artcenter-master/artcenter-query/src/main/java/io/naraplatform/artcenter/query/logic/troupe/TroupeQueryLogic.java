package io.naraplatform.artcenter.query.logic.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.domain.troupe.query.spec.TroupeQueryService;
import io.naraplatform.artcenter.store.troupe.TroupeDomainStore;
import io.naraplatform.artcenter.store.troupe.TroupeRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TroupeQueryLogic implements TroupeQueryService {
    //
	@Autowired
    private TroupeDomainStore troupeDomainStore;
	@Autowired
    private TroupeRomStore troupeReadStore;

    public TroupeQueryLogic() {
        //
    }

    @Override
    public Troupe findTroupeSample() {
        //
        return Troupe.sample();
    }

    @Override
    public Troupe findTroupe(String troupeId) {
        //
        return troupeDomainStore.retrieve(troupeId);
    }

    @Override
    public String findTroupeJson(String id) {
        //
        return troupeReadStore.retrieveJson(id);
    }

    @Override
    public Troupe findTroupeByEmail(String email) {
        //
        String troupeJson = troupeReadStore.retrieveJsonByEmail(email);
        return Troupe.fromJson(troupeJson);
    }

    @Override
    public boolean existTroupeByEmail(String email) {
        //
        return troupeReadStore.existsByEmail(email);
    }

    @Override
    public String findTroupeJsonByEmail(String email) {
        //
        return troupeReadStore.retrieveJsonByEmail(email);
    }

    @Override
    public Troupe findTroupeByLoginUserId(String loginUserId) {
        //
        String troupeJson = troupeReadStore.retrieveJsonByLoginUserId(loginUserId);
        return Troupe.fromJson(troupeJson);
    }

    @Override
    public String findTroupeJsonByLoginUserId(String loginUserId) {
        //
        return troupeReadStore.retrieveJsonByLoginUserId(loginUserId);
    }

    @Override
    public List<Troupe> findAllTroupes(int offset, int limit) {
        //
        List<String> troupeJsons = troupeReadStore.retrieveAllJsons(offset, limit);
        return troupeJsons.stream().map(json -> Troupe.fromJson(json)).collect(Collectors.toList());
    }

    @Override
    public List<String> findAllTroupeJsons(int offset, int limit) {
        //
        return troupeReadStore.retrieveAllJsons(offset, limit);
    }
}
