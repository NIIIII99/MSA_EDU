package io.naraplatform.artcenter.store.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Item;

import java.util.List;

public interface ItemDomainStore {

    void create(Item item);

    Item retrieve(String itemId);
    Item retrieveByDramaVersion(String dramaVersionId);
    List<Item> retrieveByCatalogAndCategory(String catalogId, String categoryName, int offset, int limit);

    void update(Item item);

}
