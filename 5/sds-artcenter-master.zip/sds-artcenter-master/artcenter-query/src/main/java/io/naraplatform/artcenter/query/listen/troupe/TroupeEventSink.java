package io.naraplatform.artcenter.query.listen.troupe;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface TroupeEventSink {

    String TROUPE_INPUT = "troupeInput";

    @Input(TROUPE_INPUT)
    MessageChannel troupeInput();

}
