package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;

public interface DramaTicketDomainStore {
    //
    void create(DramaTicket dramaTicket);
    DramaTicket retrieve(String dramaTicketId);
    DramaTicket retrieveByDrama(String dramaId);
}
