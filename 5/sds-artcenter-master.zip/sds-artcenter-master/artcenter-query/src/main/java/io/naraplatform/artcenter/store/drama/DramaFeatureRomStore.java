package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;

import java.util.List;

public interface DramaFeatureRomStore {

    void create(DramaFeatureRom dramaFeatureRom);
    DramaFeatureRom retrieve(String dramaFeatureId, String langCode);
    List<DramaFeatureRom> retrieveAllByDramaId(String dramaId, String langCode);
    void update(DramaFeatureRom dramaFeatureRomCmo);
    void delete(String dramaFeatureId);
    void delete(String dramaFeatureId, String langCode);

}
