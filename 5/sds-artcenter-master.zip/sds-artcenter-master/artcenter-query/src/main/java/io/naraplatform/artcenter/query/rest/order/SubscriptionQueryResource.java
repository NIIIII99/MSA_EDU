package io.naraplatform.artcenter.query.rest.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.domain.order.query.spec.SubscriptionQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value="/order")
public class SubscriptionQueryResource implements SubscriptionQueryService {

    @Autowired
    SubscriptionQueryService subscriptionQueryService;

    @Override
    @GetMapping(value="/{subscriptionId}")
    public Subscription findSubscription(@PathVariable(value="subscriptionId") String subscriptionId) {
        //
        return subscriptionQueryService.findSubscription(subscriptionId);
    }

    @Override
    @GetMapping(value="/subscriber/{subscriberId}")
    public List<Subscription> findSubscriptionsBySubscriber(@PathVariable(value="subscriberId") String subscriberId) {
        //
        return subscriptionQueryService.findSubscriptionsBySubscriber(subscriberId);
    }

    @Override
    @GetMapping(value="/team/{teamId}")
    public List<Subscription> findSubscriptionsByTeam(@PathVariable(value="teamId") String teamId) {
        //
        return subscriptionQueryService.findSubscriptionsByTeam(teamId);
    }
}
