package io.naraplatform.artcenter.store.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;

import java.util.List;

public interface CategoryRomStore {

    void create(CategoryRom categoryRom);

    List<CategoryRom> retrieve(String categoryId);
    CategoryRom retrieve(String categoryId, String langCode);

    List<CategoryRom> retrieveAllByCatalogId(String catalogId);
    List<CategoryRom> retrieveAllByCatalogId(String catalogId, String langCode);

    void update(CategoryRom categoryRom);

    void delete(String categoryId);

}
