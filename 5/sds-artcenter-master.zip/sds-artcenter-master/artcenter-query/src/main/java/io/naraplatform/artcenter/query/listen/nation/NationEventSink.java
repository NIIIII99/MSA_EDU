package io.naraplatform.artcenter.query.listen.nation;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface NationEventSink {

    String NATION_INPUT = "nationInput";

	@Input(NATION_INPUT)
    MessageChannel nationInput();

}
