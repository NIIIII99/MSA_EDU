package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;

import java.util.List;

public interface DramaFeatureDomainStore {

    void create(DramaFeature dramaFeature);
    DramaFeature retrieve(String dramaFeatureId);
    List<DramaFeature> retrieveAllByDramaId(String dramaId);
    void update(DramaFeature dramaFeature);
    void delete(String dramaFeatureId);

}
