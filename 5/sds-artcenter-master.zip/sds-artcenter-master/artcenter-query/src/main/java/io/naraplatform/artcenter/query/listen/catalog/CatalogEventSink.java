package io.naraplatform.artcenter.query.listen.catalog;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface CatalogEventSink {

    String CATALOG_INPUT = "catalogInput";

	@Input(CATALOG_INPUT)
    MessageChannel catalogInput();

}
