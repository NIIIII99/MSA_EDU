package io.naraplatform.artcenter.query.logic.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.artcenter.domain.catalog.query.spec.CatalogQueryService;
import io.naraplatform.artcenter.store.catalog.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CatalogQueryLogic implements CatalogQueryService {

    @Autowired
    CatalogDomainStore catalogDomainStore;
    @Autowired
    CatalogRomStore catalogReadStore;

    @Autowired
    CategoryDomainStore categoryDomainStore;
    @Autowired
    CategoryRomStore categoryReadStore;

    @Autowired
    ItemDomainStore itemDomainStore;
    @Autowired
    ItemRomStore itemReadStore;

    @Override
    public Catalog findCatalog(String catalogId) {
        //
        return catalogDomainStore.retrieve(catalogId);
    }

    @Override
    public List<Category> findCategoris(String catalogId) {
        //
        return catalogDomainStore.retrieveCategoriesByCatalog(catalogId);
    }

    @Override
    public Category findCategory(String categoryId) {
        //
        return catalogDomainStore.retrieveCategory(categoryId);
    }

    @Override
    public List<Category> findCategoris() {
        //
        return categoryDomainStore.retrieveAll();
    }

    @Override
    public Item findItem(String itemId) {
        //
        return itemDomainStore.retrieve(itemId);
    }

    @Override
    public List<Item> findItemByCatalogAndCategory(String catalogId, String categoryId, int offset, int limit) {
        //
        return itemDomainStore.retrieveByCatalogAndCategory(catalogId, categoryId, offset, limit);
    }

    @Override
    public CatalogRom findCatalogRom(String langCode, String catalogId) {
        //
        return catalogReadStore.retrieve(catalogId, langCode);
    }

    @Override
    public List<CatalogRom> findAllCatalogRoms(String langCode) {
        //
        return catalogReadStore.retrieveAllByLangCode(langCode);
    }

    @Override
    public List<CategoryRom> findCategoryRoms(String langCode, String catalogId) {
        //
        return categoryReadStore.retrieveAllByCatalogId(catalogId, langCode);
    }

    @Override
    public CategoryRom findCategoryRom(String langCode, String categoryId) {
        //
        return categoryReadStore.retrieve(categoryId, langCode);
    }

    @Override
    public List<ItemRom> findItemRoms(String catalogId, String categoryId, String langCode, int offset, int limit, Optional<String> keyword) {
        //
        List<ItemRom> itemRoms = itemReadStore.retrieve(catalogId, categoryId, langCode, offset, limit);
        if (!keyword.isPresent()) {
            return itemRoms;
        }

        return itemRoms.stream()
            .filter(itemRom -> itemRom.getTitle().startsWith(keyword.get()))
            .collect(Collectors.toList());
    }

    @Override
    public List<ItemRom> findItemRoms(String catalogId, String langCode, int offset, int limit, Optional<String> keyword) {
        //
        List<ItemRom> itemRoms = itemReadStore.retrieve(catalogId, langCode, offset, limit);

        if (!keyword.isPresent()) {
            return itemRoms;
        }

        return itemRoms.stream()
            .filter(itemRom -> itemRom.getTitle().startsWith(keyword.get()))
            .collect(Collectors.toList());
    }

    @Override
    public List<ItemRom> findItemRoms(String troupeId, String langCode, int offset, int limit) {
        //
        return itemReadStore.retrieveByTroupe(troupeId, langCode, offset, limit);
    }

    @Override
    public List<ItemRom> findItemRomsBySubscriptionCount(String catalogId, String langCode, int offset, int limit) {
        //
        return itemReadStore.retrieveBySubscriptionCount(catalogId, langCode, offset, limit);
    }

    @Override
    public List<ItemRom> findItemRomsBySalesAmount(String catalogId, String langCode, int offset, int limit) {
        //
        return itemReadStore.retrieveBySalesAmount(catalogId, langCode, offset, limit);
    }
}
