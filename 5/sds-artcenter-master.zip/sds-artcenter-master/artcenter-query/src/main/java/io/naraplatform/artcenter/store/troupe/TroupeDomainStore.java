package io.naraplatform.artcenter.store.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;

public interface TroupeDomainStore {
    //
    void create(Troupe troupe);
    Troupe retrieve(String troupeId);
    void update(Troupe troupe);
    void delete(String troupeId);
}
