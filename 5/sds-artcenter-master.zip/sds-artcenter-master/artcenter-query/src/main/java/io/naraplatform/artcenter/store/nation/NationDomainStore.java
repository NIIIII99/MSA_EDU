package io.naraplatform.artcenter.store.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;

import java.util.List;

public interface NationDomainStore {

    void create(Nation nation);
    Nation retrieve(String nationId);
    List<Nation> retrieveAll();
    void update(Nation nation);
    void delete(String nationId);

}
