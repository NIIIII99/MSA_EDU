package io.naraplatform.artcenter.query.listen.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.domain.troupe.event.TroupeEvent;
import io.naraplatform.artcenter.store.troupe.TroupeDomainStore;
import io.naraplatform.artcenter.store.troupe.TroupeRomStore;
import io.naraplatform.share.exception.IllegalRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(TroupeEventSink.class)
public class TroupeEventConsumer {

    @Autowired
    TroupeDomainStore troupeDomainStore;

    @Autowired
    TroupeRomStore troupeReadStore;

    @StreamListener(TroupeEventSink.TROUPE_INPUT)
    public void listenTroupeEvent(@Payload TroupeEvent troupeEvent) {
        //
        Troupe troupe = troupeEvent.getTroupe();

        switch (troupeEvent.getType()) {
            case Created:
                listenTroupeCreatedEvent(troupe);
                break;
            case Updated:
                listenTroupeUpdatedEvent(troupe);
                break;
            case Deleted:
                listenTroupeDeletedEvent(troupe);
                break;
            default:
                throw new IllegalRequestException(String.format("[%s] is not permitted event type", troupeEvent.getType().toString()));
        }

    }

    private void listenTroupeCreatedEvent(Troupe troupe) {
        //
        troupeDomainStore.create(troupe);
        troupeReadStore.create(troupe);
    }

    private void listenTroupeUpdatedEvent(Troupe troupe) {
        //
        troupeDomainStore.update(troupe);
        troupeReadStore.update(troupe);
    }

    private void listenTroupeDeletedEvent(Troupe troupe) {
        //
        String troupeId = troupe.getId();

        troupeDomainStore.delete(troupeId);
        troupeReadStore.delete(troupeId);
    }

}
