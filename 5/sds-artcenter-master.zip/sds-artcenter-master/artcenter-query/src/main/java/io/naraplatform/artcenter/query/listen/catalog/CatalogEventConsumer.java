package io.naraplatform.artcenter.query.listen.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.event.CatalogEvent;
import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.artcenter.store.catalog.CatalogDomainStore;
import io.naraplatform.artcenter.store.catalog.CatalogRomStore;
import io.naraplatform.artcenter.store.catalog.CategoryDomainStore;
import io.naraplatform.artcenter.store.catalog.CategoryRomStore;
import io.naraplatform.share.exception.IllegalRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(CatalogEventSink.class)
public class CatalogEventConsumer {

    @Autowired
    CatalogDomainStore catalogDomainStore;
    @Autowired
    CatalogRomStore catalogReadStore;

    @Autowired
    CategoryDomainStore categoryDomainStore;
    @Autowired
    CategoryRomStore categoryReadStore;

    @StreamListener(CatalogEventSink.CATALOG_INPUT)
    public void listenCatalogEvent(@Payload CatalogEvent catalogEvent) {
        //
        switch (catalogEvent.getType()) {
            case Created:
                listenCatalogCreatedEvent(catalogEvent);
                break;
            case Updated:
                listenCatalogUpdatedEvent(catalogEvent);
                break;
            case Deleted:
                listenCatalogDeletedEvent(catalogEvent);
                break;
            default:
                throw new IllegalRequestException(String.format("[%s] is not permitted event type", catalogEvent.getType().toString()));
        }
    }

    private void listenCatalogCreatedEvent(CatalogEvent catalogEvent) {
        //
        if (Catalog.class.getSimpleName().equals(catalogEvent.getName())) {
            Catalog catalog = catalogEvent.getCatalog();

            catalogDomainStore.create(catalog);
            catalog.getTitles().list().stream()
                .map(title -> new CatalogRom(title.getLang(), catalog))
                .forEach(catalogRom -> catalogReadStore.create(catalogRom));
        } else if (Category.class.getSimpleName().equals(catalogEvent.getName())) {
            Category category = catalogEvent.getCategory();

            categoryDomainStore.create(category);
            category.getNames().list().stream()
                .map(name -> new CategoryRom(name.getLang(), category))
                .forEach(categoryRom -> categoryReadStore.create(categoryRom));
        }

    }

    private void listenCatalogUpdatedEvent(CatalogEvent catalogEvent) {
        //
        if (Catalog.class.getSimpleName().equals(catalogEvent.getName())) {
            Catalog catalog = catalogEvent.getCatalog();

            catalogDomainStore.update(catalog);
            catalogReadStore.delete(catalog.getId());
            catalog.getTitles().list().stream()
                .map(title -> new CatalogRom(title.getLang(), catalog))
                .forEach(catalogRom -> catalogReadStore.create(catalogRom));
        } else if (Category.class.getSimpleName().equals(catalogEvent.getName())) {
            Category category = catalogEvent.getCategory();

            categoryDomainStore.update(category);
            categoryReadStore.delete(category.getId());
            category.getNames().list().stream()
                .map(title -> new CategoryRom(title.getLang(), category))
                .forEach(catalogRom -> categoryReadStore.create(catalogRom));
        }
    }

    private void listenCatalogDeletedEvent(CatalogEvent catalogEvent) {
        //
        if (Catalog.class.getSimpleName().equals(catalogEvent.getName())) {
            Catalog catalog = catalogEvent.getCatalog();

            catalogDomainStore.delete(catalog.getId());
            catalogReadStore.delete(catalog.getId());
        } else if (Category.class.getSimpleName().equals(catalogEvent.getName())) {
            Category category = catalogEvent.getCategory();

            categoryDomainStore.delete(category.getId());
            categoryReadStore.delete(category.getId());
        }
    }

}
