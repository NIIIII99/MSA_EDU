package io.naraplatform.artcenter.store.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;

import java.util.List;

public interface CatalogRomStore {

    void create(CatalogRom catalogRom);
    CatalogRom retrieve(String catalogId, String langCode);
    List<CatalogRom> retrieveAllByLangCode(String langCode);
    List<CatalogRom> retrieveAllByNationId(String nationId);
    void update(CatalogRom catalogRom);
    void delete(String catalogId);
}
