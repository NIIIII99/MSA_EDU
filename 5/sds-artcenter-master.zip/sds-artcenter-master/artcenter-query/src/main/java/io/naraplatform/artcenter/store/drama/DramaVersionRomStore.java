package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;

import java.util.List;

public interface DramaVersionRomStore {

    void create(DramaVersionRom dramaVersionRom);
    DramaVersionRom retrieve(String dramaVersionId, String langCode);
    List<DramaVersionRom> retrieve(String dramaId);
    List<DramaVersionRom> retrieveAllByDramaId(String dramaId, String langCode);
    List<DramaVersionRom> retrieveVersionsByDrama(String dramaId, int offset, int limit);
    void update(DramaVersionRom dramaVersionRom);
    void delete(String dramaVersionId);
    void delete(String dramaVersionId, String langCode);

}
