package io.naraplatform.artcenter.query.listen.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.command.model.SalesSummary;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.domain.order.event.SubscriptionEvent;
import io.naraplatform.artcenter.store.catalog.ItemDomainStore;
import io.naraplatform.artcenter.store.catalog.ItemRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(SubscriptionCatalogEventSink.class)
public class SubscriptionCatalogEventConsumer {

    @Autowired
    ItemDomainStore itemDomainStore;
    @Autowired
    ItemRomStore itemReadStore;

    @StreamListener(SubscriptionCatalogEventSink.SUBSCRIPTION_CATALOG_INPUT)
    public void listenDramaEvent(@Payload SubscriptionEvent subscriptionEvent) {
        //
        if (Subscription.class.getSimpleName().equals(subscriptionEvent.getName())) {
            listenSubscribeEvent(subscriptionEvent);
        }
    }

    private void listenSubscribeEvent(SubscriptionEvent subscriptionEvent) {
        //
        Subscription subscription = subscriptionEvent.getSubscription();
        String dramaVersionId = subscription.getDramaVersion().getId();
        String langCode = subscription.getLangCode();

        Item item = itemDomainStore.retrieveByDramaVersion(subscription.getDramaVersion().getId());

        SalesSummary domainSalesSummary = item.getSalesSummary();
        domainSalesSummary.newSales(item.getPrice());
        item.setSalesSummary(domainSalesSummary);

        itemDomainStore.update(item);

        ItemRom itemRom = itemReadStore.retrieve(dramaVersionId, langCode);
        SalesSummary romSalesSummary = itemRom.getSalesSummary();
        romSalesSummary.newSales(item.getPrice());
        itemRom.setSalesSummary(romSalesSummary);
        itemReadStore.update(itemRom);
    }

}
