package io.naraplatform.artcenter.store.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;

import java.util.List;

public interface DramaRomStore {
    //
    void create(DramaRom drama);
    DramaRom retrieve(String dramaId, String langCode);
    List<DramaRom> retrieveDramasByFeedbackId(String feedbackId, String langCode);
    void update(DramaRom drama);
    void delete(String dramaId);

}
