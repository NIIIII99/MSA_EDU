package io.naraplatform.artcenter.store.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;

import java.util.List;

public interface ItemRomStore {

    void create(ItemRom itemRom);

    List<ItemRom> retrieve(String itemId);
    ItemRom retrieve(String itemId, String langCode);

    List<ItemRom> retrieve(String catalogId, String categoryId, String langCode, int offset, int limit);
    List<ItemRom> retrieve(String catalogId, String langCode, int offset, int limit);
    List<ItemRom> retrieveBySubscriptionCount(String catalogId, String langCode, int offset, int limit);
    List<ItemRom> retrieveBySalesAmount(String catalogId, String langCode, int offset, int limit);

    List<ItemRom> retrieveByTroupe(String troupeId, String langCode, int offset, int limit);

    void update(ItemRom itemRom);

    void deleteByDramaVersion(String dramaVersionId);

}
