package io.naraplatform.artcenter.query.listen.drama;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface DramaEventSink {

    String DRAMA_INPUT = "dramaInput";

	@Input(DRAMA_INPUT)
    MessageChannel dramaInput();

}
