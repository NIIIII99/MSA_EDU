package io.naraplatform.artcenter.query.logic.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.domain.order.query.spec.SubscriptionQueryService;
import io.naraplatform.artcenter.store.order.SubscriptionDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubscriptionQueryLogic implements SubscriptionQueryService {

    @Autowired
    SubscriptionDomainStore subscriptionDomainStore;

    @Override
    public Subscription findSubscription(String subscriptionId) {
        //
        return subscriptionDomainStore.retrieve(subscriptionId);
    }

    @Override
    public List<Subscription> findSubscriptionsBySubscriber(String subscriberId) {
        //
        return subscriptionDomainStore.retrieveSubscriptionsBySubscriber(subscriberId);
    }

    @Override
    public List<Subscription> findSubscriptionsByTeam(String teamId) {
        //
        return subscriptionDomainStore.retrieveSubscriptionsByTeam(teamId);
    }
}
