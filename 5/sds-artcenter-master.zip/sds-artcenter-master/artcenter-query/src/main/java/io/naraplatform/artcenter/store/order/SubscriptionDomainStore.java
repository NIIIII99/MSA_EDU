package io.naraplatform.artcenter.store.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;

import java.util.List;

public interface SubscriptionDomainStore {

    void create(Subscription subscription);
    Subscription retrieve(String subscriptionId);
    Subscription retrieve(String subscriptionId, String langCode);
    List<Subscription> retrieveSubscriptionsBySubscriber(String subscriberId);
    List<Subscription> retrieveSubscriptionsByTeam(String teamId);
    void update(Subscription subscription);
    void delete(String subscriptionId);

}
