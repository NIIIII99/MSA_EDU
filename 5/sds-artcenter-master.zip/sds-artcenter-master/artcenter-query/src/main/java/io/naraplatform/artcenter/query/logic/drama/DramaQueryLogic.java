package io.naraplatform.artcenter.query.logic.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;
import io.naraplatform.artcenter.domain.drama.query.spec.DramaQueryService;
import io.naraplatform.artcenter.store.drama.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class DramaQueryLogic implements DramaQueryService {

    @Autowired
    DramaDomainStore dramaDomainStore;
    @Autowired
    DramaRomStore dramaReadStore;

    @Autowired
    DramaTicketDomainStore dramaTicketDomainStore;

    @Autowired
    DramaVersionDomainStore dramaVersionDomainStore;
    @Autowired
    DramaVersionRomStore dramaVersionReadStore;
    @Autowired
    DramaFeatureDomainStore dramaFeatureDomainStore;
    @Autowired
    DramaFeatureRomStore dramaFeatureReadStore;

    @Override
    public Drama findDrama(String dramaId) {
        //
        Drama drama = dramaDomainStore.retrieve(dramaId);
        drama.setVersions(dramaVersionDomainStore.retrieveAllByDramaId(dramaId));

        return drama;
    }

    @Override
    public DramaTicket findDramaTicket(String dramaTicketId) {
        //
        return dramaTicketDomainStore.retrieve(dramaTicketId);
    }

    @Override
    public DramaTicket findDramaTicketByDrama(String dramaId) {
        //
        return dramaTicketDomainStore.retrieveByDrama(dramaId);
    }

    @Override
    public DramaRom findDramaRom(String lang, String dramaId) {
        //
        return dramaReadStore.retrieve(dramaId, lang);
    }

    @Override
    public DramaFeature findFeature(String featureId) {
        //
        return dramaFeatureDomainStore.retrieve(featureId);
    }

    @Override
    public List<DramaFeature> findFeatures(String dramaId) {
        //
        return dramaFeatureDomainStore.retrieveAllByDramaId(dramaId);
    }

    @Override
    public List<DramaFeatureRom> findFeatureRoms(String dramaId, String lang) {
        //
        return dramaFeatureReadStore.retrieveAllByDramaId(dramaId, lang);
    }

    @Override
    public DramaVersion findLatestVersion(String dramaId) {
        //
        List<DramaVersion> dramaVersions = dramaVersionDomainStore.retrieveAllByDramaId(dramaId);

        if (dramaVersions.isEmpty()) {
            throw new NoSuchElementException();
        }

        Comparator<DramaVersion> comparator = Comparator.comparing(DramaVersion::getReleaseDate);
        return dramaVersions.stream().max(comparator).get();
    }

    @Override
    public List<DramaVersion> findVersions(String dramaId, int offset, int limit) {
        //
        return dramaVersionDomainStore.retrieveAllByDramaId(dramaId, offset, limit);
    }

    @Override
    public DramaVersionRom findLatestVersionRom(String dramaId) {
        //
        List<DramaVersionRom> dramaVersionRoms = dramaVersionReadStore.retrieve(dramaId);

        if (dramaVersionRoms.isEmpty()) {
            throw new NoSuchElementException();
        }

        Comparator<DramaVersionRom> comparator = Comparator.comparing(DramaVersionRom::getReleaseDate);
        return dramaVersionRoms.stream().max(comparator).get();
    }

    @Override
    public List<DramaVersionRom> findVersionRoms(String dramaId, int offset, int limit) {
        //
        return dramaVersionReadStore.retrieveVersionsByDrama(dramaId, offset, limit);
    }

    @Override
    public List<Drama> findDramaByTroupe(String troupeId, int offset, int limit) {
        //
        return dramaDomainStore.retrieveDramasByTroupe(troupeId, offset, limit);
    }
}
