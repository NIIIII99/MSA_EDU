package io.naraplatform.artcenter.query.listen.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.event.DramaEvent;
import io.naraplatform.artcenter.store.catalog.CategoryDomainStore;
import io.naraplatform.artcenter.store.catalog.ItemDomainStore;
import io.naraplatform.artcenter.store.catalog.ItemRomStore;
import io.naraplatform.artcenter.store.drama.DramaDomainStore;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.exception.IllegalRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(DramaCatalogEventSink.class)
public class DramaCatalogEventConsumer {

    @Autowired
    DramaDomainStore dramaDomainStore;
    @Autowired
    CategoryDomainStore categoryDomainStore;

    @Autowired
    ItemDomainStore itemDomainStore;
    @Autowired
    ItemRomStore itemReadStore;

    @StreamListener(DramaCatalogEventSink.DRAMA_CATALOG_INPUT)
    public void listenDramaEvent(@Payload DramaEvent dramaEvent) {
        //
        if (DramaVersion.class.getSimpleName().equals(dramaEvent.getName())) {
            listenDramaVersionEvent(dramaEvent);
        }
    }

    private void listenDramaVersionEvent(DramaEvent dramaEvent) {
        //
        DramaVersion dramaVersion = dramaEvent.getDramaVersion();
        Drama drama = dramaDomainStore.retrieve(dramaVersion.getDramaId());
        Category category = categoryDomainStore.retrieve(drama.getCategoryId());

        if (dramaEvent.getType() == EventType.ChildAdded) {
            Item item = new Item(category.getCatalogId(), drama, dramaVersion);

            itemDomainStore.create(item);
            dramaVersion.getSupportLangs().list().stream()
                .map(langString -> new ItemRom(langString.getLang(), item))
                .forEach(itemRom -> itemReadStore.create(itemRom));
        } else if (dramaEvent.getType() == EventType.ChildUpdated) {
            Item item = new Item(category.getCatalogId(), drama, dramaVersion);

            itemDomainStore.update(item);
            itemReadStore.deleteByDramaVersion(dramaVersion.getId());

            dramaVersion.getSupportLangs().list().stream()
                .map(langString -> new ItemRom(langString.getLang(), item))
                .forEach(itemRom -> itemReadStore.create(itemRom));
        } else {
            throw new IllegalRequestException(String.format("[%s] is not permitted event type", dramaEvent.getType().toString()));
        }
    }

}
