package io.naraplatform.artcenter.query.listen.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.event.DramaEvent;
import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;
import io.naraplatform.artcenter.store.drama.*;
import io.naraplatform.share.exception.IllegalRequestException;
import io.naraplatform.share.util.json.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

@EnableBinding(DramaEventSink.class)
public class DramaEventConsumer {

    @Autowired
    DramaDomainStore dramaDomainStore;
    @Autowired
    DramaRomStore dramaReadStore;

    @Autowired
    DramaTicketDomainStore dramaTicketDomainStore;

    @Autowired
    DramaVersionDomainStore dramaVersionDomainStore;
    @Autowired
    DramaVersionRomStore dramaVersionReadStore;

    @Autowired
    DramaFeatureDomainStore dramaFeatureDomainStore;
    @Autowired
    DramaFeatureRomStore dramaFeatureReadStore;

    @StreamListener(DramaEventSink.DRAMA_INPUT)
    public void listenDramaEvent(@Payload DramaEvent dramaEvent) {
        //
        System.out.println("====================================");
        System.out.println("EVENT");
        System.out.println("====================================");
        System.out.println(JsonUtil.toJson(dramaEvent));
        System.out.println("====================================");


        switch (dramaEvent.getType()) {
            case Created:
                listenDramaCreatedEvent(dramaEvent);
                break;
            case Updated:
                listenDramaUpdatedEvent(dramaEvent);
                break;
            case Deleted:
                listenDramaDeletedEvent(dramaEvent);
                break;
            case ChildAdded:
                listenDramaChildAddedEvent(dramaEvent);
                break;
            case ChildUpdated:
                listenDramaChildUpdatedEvent(dramaEvent);
                break;
            case ChildRemoved:
                listenDramaChildRemovedEvent(dramaEvent);
                break;
            default:
                throw new IllegalRequestException(String.format("[%s] is not permitted event type", dramaEvent.getType().toString()));
        }
    }

    private void listenDramaCreatedEvent(DramaEvent dramaEvent) {
        //
        Drama drama = dramaEvent.getDrama();

        dramaDomainStore.create(drama);
        drama.getTitles().list().stream()
            .map(title -> new DramaRom(title.getLang(), drama))
            .forEach(rom -> dramaReadStore.create(rom));

        DramaTicket dramaTicket = new DramaTicket(drama);
        dramaTicketDomainStore.create(dramaTicket);
    }

    private void listenDramaUpdatedEvent(DramaEvent dramaEvent) {
        //
        Drama drama = dramaEvent.getDrama();

        dramaDomainStore.update(drama);
        dramaReadStore.delete(drama.getId());
        drama.getTitles().list().stream()
            .map(title -> new DramaRom(title.getLang(), drama))
            .forEach(dramaRom -> {
                dramaReadStore.create(dramaRom);
            });
    }

    private void listenDramaDeletedEvent(DramaEvent dramaEvent) {
        //
        Drama drama = dramaEvent.getDrama();

        dramaDomainStore.delete(drama.getId());
        dramaReadStore.delete(drama.getId());
    }

    private void listenDramaChildAddedEvent(DramaEvent dramaEvent) {
        //
        if (DramaVersion.class.getSimpleName().equals(dramaEvent.getName())) {
            DramaVersion dramaVersion = dramaEvent.getDramaVersion();
            dramaVersionDomainStore.create(dramaVersion);
            dramaVersionReadStore.delete(dramaVersion.getId());
            dramaVersion.getSupportLangs().list()
                .stream()
                .map(lang -> new DramaVersionRom(lang.getLang(), dramaVersion))
                .forEach(rom -> dramaVersionReadStore.create(rom));
        } else if (DramaFeature.class.getSimpleName().equals(dramaEvent.getName())) {
            DramaFeature dramaFeature = dramaEvent.getDramaFeature();
            dramaFeatureDomainStore.create(dramaFeature);
            dramaFeatureReadStore.delete(dramaFeature.getId());
            dramaFeature.getNames().getLangs()
                .stream()
                .map(lang -> new DramaFeatureRom(lang, dramaFeature))
                .forEach(rom -> dramaFeatureReadStore.create(rom));
        } else {
            throw new IllegalRequestException(String.format("[%s] is not permitted event name", dramaEvent.getName().toString()));
        }
    }

    private void listenDramaChildUpdatedEvent(DramaEvent dramaEvent) {
        //
        if (DramaVersion.class.getSimpleName().equals(dramaEvent.getName())) {
            DramaVersion dramaVersion = dramaEvent.getDramaVersion();
            dramaVersionDomainStore.update(dramaVersion);
            dramaVersionReadStore.delete(dramaVersion.getId());
            dramaVersion.getSupportLangs().list()
                .stream()
                .map(lang -> new DramaVersionRom(lang.getLang(), dramaVersion))
                .forEach(versionRom -> {
                    dramaVersionReadStore.create(versionRom);
                });
        } else if (DramaFeature.class.getSimpleName().equals(dramaEvent.getName())) {
            DramaFeature dramaFeature = dramaEvent.getDramaFeature();
            dramaFeatureDomainStore.update(dramaFeature);
            dramaFeatureReadStore.delete(dramaFeature.getId());
            dramaFeature.getNames().getLangs()
                .stream()
                .map(lang -> new DramaFeatureRom(lang, dramaFeature))
                .forEach(featureRom -> {
                    dramaFeatureReadStore.create(featureRom);
                });
        } else {
            throw new IllegalRequestException(String.format("[%s] is not permitted event name", dramaEvent.getName().toString()));
        }
    }

    private void listenDramaChildRemovedEvent(DramaEvent dramaEvent) {
        //
        if (DramaVersion.class.getSimpleName().equals(dramaEvent.getName())) {
            DramaVersion dramaVersion = dramaEvent.getDramaVersion();

            dramaVersionDomainStore.delete(dramaVersion.getId());
            dramaVersionReadStore.delete(dramaVersion.getId());
        } else if (DramaFeature.class.getSimpleName().equals(dramaEvent.getName())) {
            DramaFeature dramaFeature = dramaEvent.getDramaFeature();

            dramaFeatureDomainStore.delete(dramaFeature.getId());
            dramaFeatureReadStore.delete(dramaFeature.getId());
        } else {
            throw new IllegalRequestException(String.format("[%s] is not permitted event name", dramaEvent.getName().toString()));
        }
    }

}
