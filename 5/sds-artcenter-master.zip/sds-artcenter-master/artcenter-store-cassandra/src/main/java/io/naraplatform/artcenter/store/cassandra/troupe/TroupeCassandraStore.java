package io.naraplatform.artcenter.store.cassandra.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeCmo;
import io.naraplatform.artcenter.store.cassandra.troupe.repository.TroupeRepository;
import io.naraplatform.artcenter.store.troupe.TroupeDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.NoSuchElementException;
import java.util.Optional;

@Repository
public class TroupeCassandraStore implements TroupeDomainStore {

	@Autowired
    TroupeRepository troupeRepository;
	
	private static final String NO_SUCH_ELEMENT_MESSAGE = "No troupe[%s] to retrieve.";

	@Override
	public void create(Troupe troupe) {
		//
		troupeRepository.save(new TroupeCmo(troupe));
	}

	@Override
	public Troupe retrieve(String id) {
		//
		Optional<TroupeCmo> foundTroupeCpo = troupeRepository.findById(id);
		if (!foundTroupeCpo.isPresent()) {
			throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, id));
		}
		
		return foundTroupeCpo.get().toDomain();
	}

	@Override
	public void update(Troupe troupe) {
		//
		troupeRepository.save(new TroupeCmo(troupe));
	}

	@Override
	public void delete(String id) {
		//
		troupeRepository.deleteById(id);
	}
}
