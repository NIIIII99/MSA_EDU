package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaByTroupeCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaByTroupeRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaRepository;
import io.naraplatform.artcenter.store.drama.DramaDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DramaCassandraStore implements DramaDomainStore {

    @Autowired
    DramaRepository dramaRepository;
    @Autowired
    DramaByTroupeRepository dramaByTroupeRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No drama[%s] to retrieve.";

    @Override
    public void create(Drama drama) {
        //
        dramaRepository.insert(new DramaCmo(drama));
        dramaByTroupeRepository.insert(new DramaByTroupeCmo(drama));
    }

    @Override
    public Drama retrieve(String dramaId) {
        //
        Optional<DramaCmo> dramaCmo = dramaRepository.findById(dramaId);
        if (!dramaCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaId));
        }

        return dramaCmo.get().toDomain();
    }

    @Override
    public List<Drama> retrieveDramasByTroupe(String troupeId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<DramaByTroupeCmo> dramaByTroupeCmos = dramaByTroupeRepository.findAllByTroupeId(troupeId, pageable);
        return dramaByTroupeCmos.stream().map(DramaByTroupeCmo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(Drama drama) {
        //
        dramaRepository.save(new DramaCmo(drama));
        dramaByTroupeRepository.save(new DramaByTroupeCmo(drama));
    }

    @Override
    public void delete(String dramaId) {
        //
        Optional<DramaCmo> dramaCmo = dramaRepository.findById(dramaId);

        if (dramaCmo.isPresent()) {
            Drama drama = dramaCmo.get().toDomain();
            dramaRepository.delete(dramaCmo.get());
            dramaByTroupeRepository.delete(new DramaByTroupeCmo(drama));
        }
    }

}
