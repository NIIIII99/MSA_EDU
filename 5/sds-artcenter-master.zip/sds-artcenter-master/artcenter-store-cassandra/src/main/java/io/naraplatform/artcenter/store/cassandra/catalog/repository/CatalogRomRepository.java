package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;
import java.util.Optional;

public interface CatalogRomRepository extends CassandraRepository<CatalogRomCmo, String> {
    //
    List<CatalogRomCmo> findAllById(String id);
    Optional<CatalogRomCmo> findByIdAndLangCode(String id, String langCode);
}
