package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;
import java.util.Optional;

public interface DramaFeatureRomRepository extends CassandraRepository<DramaFeatureRomCmo, String> {
    //
    List<DramaFeatureRomCmo> findAllById(String dramaFeatureId);
    Optional<DramaFeatureRomCmo> findByIdAndLangCode(String dramaFeatureId, String langCode);
}
