package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CatalogRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CategoryRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CategoryRomRepository;
import io.naraplatform.artcenter.store.catalog.CatalogDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class CatalogCassandraStore implements CatalogDomainStore {
    //

    @Autowired
    CatalogRepository catalogRepository;

    @Autowired
    CategoryRepository categoryRepository;
    @Autowired
    CategoryRomRepository categoryRomRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No catalog[%s] to retrieve.";

    @Override
    public void create(Catalog catalog) {
        //
        catalogRepository.insert(new CatalogCmo(catalog));
    }

    @Override
    public Catalog retrieve(String catalogId) {
        //
        Optional<CatalogCmo> catalogCmo = catalogRepository.findById(catalogId);
        if (!catalogCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, catalogId));
        }

        return catalogCmo.get().toDomain();
    }

    @Override
    public void update(Catalog catalog) {
        //
        catalogRepository.save(new CatalogCmo(catalog));
    }

    @Override
    public void delete(String catalogId) {
        //
        catalogRepository.deleteById(catalogId);
    }

    @Override
    public Category retrieveCategory(String categoryId) {
        //
        Optional<CategoryCmo> categoryCmo = categoryRepository.findById(categoryId);
        if (!categoryCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, categoryId));
        }

        return categoryCmo.get().toDomain();
    }

    @Override
    public List<Category> retrieveCategoriesByCatalog(String catalogId) {
        //
        return categoryRepository.findAllByCatalogId(catalogId)
            .stream()
            .map(CategoryCmo::toDomain)
            .collect(Collectors.toList());
    }

}
