package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomByDramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface ItemRomByDramaRepository extends CassandraRepository<ItemRomByDramaCmo, String> {
    //
    List<ItemRomByDramaCmo> findAllByDramaVersionId(String dramaVersionId);
    ItemRomByDramaCmo findByDramaVersionIdAndLangCode(String dramaVersionId, String langCode);

    //void deleteByDramaVersionIdAndLangCodeAndId(String dramaVersionId, String langCode, String itemId);
}
