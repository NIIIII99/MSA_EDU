package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;
import java.util.Optional;

public interface DramaRomRepository extends CassandraRepository<DramaRomCmo, String> {
    //
    @Query(allowFiltering=true)
    List<DramaRomCmo> findAllByFeedbackIdAndLangCode(String feedbackId, String langCode);

    void save(DramaRom drama);

    @Query(allowFiltering=true)
    void deleteByIdAndLangCode(String dramaId, String langCode);

    @Query(allowFiltering=true)
    List<DramaRomCmo> findAllById(String dramaId);

    @Query(allowFiltering=true)
    Optional<DramaRomCmo> findByIdAndLangCode(String dramaId, String langCode);
}
