package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryRomByCatalogCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface CategoryRomByCatalogRepository extends CassandraRepository<CategoryRomByCatalogCmo, String> {
    //
    List<CategoryRomByCatalogCmo> findAllByCatalogId(String catalogId);
    List<CategoryRomByCatalogCmo> findAllByCatalogIdAndLangCode(String catalogId, String langCode);
}
