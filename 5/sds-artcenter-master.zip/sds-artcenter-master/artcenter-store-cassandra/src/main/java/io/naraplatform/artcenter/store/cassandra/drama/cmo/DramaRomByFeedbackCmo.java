package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_rom_by_feedback")
@Getter
@Setter
@NoArgsConstructor
public class DramaRomByFeedbackCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "feedbackId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String feedbackId;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;

    private String id;
    private String title;
    private String description;
    private String troupeJson;
    private String base64Icon;
    private String categoryName;

    public DramaRomByFeedbackCmo(String feedbackId, String langCode) {
        //
        this.feedbackId = feedbackId;
        this.langCode = langCode;
    }

    public DramaRomByFeedbackCmo(DramaRom dramaRom) {
        //
        BeanUtils.copyProperties(dramaRom, this);
        this.troupeJson = dramaRom.getTroupe().toJson();
    }

    public DramaRom toDomain(){
        //
        DramaRom dramaRom = new DramaRom(this.id);
        BeanUtils.copyProperties(this, dramaRom);
        dramaRom.setTroupe(IdName.fromJson(this.troupeJson));

        return dramaRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaRomByFeedbackCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaRomByFeedbackCmo.class);
    }

    public static DramaRomByFeedbackCmo sample() {
        //
        DramaRom dramaRom = DramaRom.sample();
        return new DramaRomByFeedbackCmo(dramaRom);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
