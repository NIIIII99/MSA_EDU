package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionByDramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;
import java.util.Optional;

public interface DramaVersionByDramaRepository extends CassandraRepository<DramaVersionByDramaCmo, String> {
    //
    List<DramaVersionByDramaCmo> findAllByDramaId(String dramaId);
    Slice<DramaVersionByDramaCmo> findAllByDramaId(String dramaId, Pageable pageable);
    Optional<DramaVersionByDramaCmo> findByDramaIdAndVersionName(String dramaId, String versionName);
}
