package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureRomByDramaCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureRomCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaFeatureRomByDramaRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaFeatureRomRepository;
import io.naraplatform.artcenter.store.drama.DramaFeatureRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;


@Repository
public class DramaFeatureRomCassandraStore implements DramaFeatureRomStore {
    //
    @Autowired
    DramaFeatureRomRepository dramaFeatureRomRepository;
    @Autowired
    DramaFeatureRomByDramaRepository dramaFeatureRomByDramaRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DramaFeatureRom[%s] to retrieve.";

    @Override
    public void create(DramaFeatureRom dramaFeatureRom) {
        //
        dramaFeatureRomRepository.insert(new DramaFeatureRomCmo(dramaFeatureRom));
        dramaFeatureRomByDramaRepository.insert(new DramaFeatureRomByDramaCmo(dramaFeatureRom));
    }

    @Override
    public DramaFeatureRom retrieve(String dramaFeatureId, String langCode) {
        //
        Optional<DramaFeatureRomCmo> dramaFeatureRomCmo = dramaFeatureRomRepository.findByIdAndLangCode(dramaFeatureId, langCode);
        if (!dramaFeatureRomCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaFeatureId));
        }

        return dramaFeatureRomCmo.get().toDomain();
    }

    @Override
    public List<DramaFeatureRom> retrieveAllByDramaId(String dramaId, String langCode) {
        //
        List<DramaFeatureRomByDramaCmo> dramaFeatureRomByDramaCmos = dramaFeatureRomByDramaRepository.findAllByDramaIdAndLangCode(dramaId, langCode);
        return dramaFeatureRomByDramaCmos
            .stream()
            .map(DramaFeatureRomByDramaCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(DramaFeatureRom dramaFeatureRom) {
        //
        dramaFeatureRomRepository.save(new DramaFeatureRomCmo(dramaFeatureRom));
        dramaFeatureRomByDramaRepository.save(new DramaFeatureRomByDramaCmo(dramaFeatureRom));
    }

    @Override
    public void delete(String dramaFeatureId) {
        //
        List<DramaFeatureRomCmo> dramaFeatureRomCmos = dramaFeatureRomRepository.findAllById(dramaFeatureId);

        dramaFeatureRomCmos.stream().forEach(dramaFeatureRomCmo -> dramaFeatureRomRepository.delete(dramaFeatureRomCmo));
        dramaFeatureRomCmos.stream().map(cmo -> cmo.toDomain()).forEach(dramaFeatureRom -> dramaFeatureRomByDramaRepository.delete(new DramaFeatureRomByDramaCmo((dramaFeatureRom))));
    }

    @Override
    public void delete(String dramaFeatureId, String langCode) {
        //
        Optional<DramaFeatureRomCmo> dramaFeatureRomCmo = dramaFeatureRomRepository.findByIdAndLangCode(dramaFeatureId, langCode);

        if (dramaFeatureRomCmo.isPresent()) {
            DramaFeatureRom dramaFeatureRom = dramaFeatureRomCmo.get().toDomain();
            dramaFeatureRomRepository.delete(new DramaFeatureRomCmo(dramaFeatureRom));
            dramaFeatureRomByDramaRepository.delete(new DramaFeatureRomByDramaCmo(dramaFeatureRom));
        }
    }

}
