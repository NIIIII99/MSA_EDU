package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.command.model.SalesSummary;
import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.Indexed;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("item")
@Getter
@Setter
@NoArgsConstructor
public class ItemCmo implements JsonSerializable {

    @PrimaryKey
    private String id;
    @Indexed
    private String catalogId;
    @Indexed
    private String categoryId;
    @Indexed
    private String troupeId;
    @Indexed
    private String dramaVersionId;
    private String versionName;

    private String titlesJson;
    private String base64Icon;
    private String troupeJson;
    private String priceJson;
    private String releaseDate;
    private String salesSummaryJson;
    private String categoryNamesJson;

    public ItemCmo(Item item) {
        //
        BeanUtils.copyProperties(item, this);

        this.dramaVersionId = item.getDramaVersion().getId();
        this.versionName = item.getDramaVersion().getName();
        this.setTroupeId(item.getTroupe().getId());
        this.setTitlesJson(item.getTitles().toJson());
        this.setTroupeJson(item.getTroupe().toJson());
        this.setPriceJson(item.getPrice().toJson());
        this.setSalesSummaryJson(item.getSalesSummary().toJson());
        this.setCategoryNamesJson(item.getCategoryNames().toJson());
    }

    public Item toDomain() {
        //
        Item item = new Item(this.id);;

        BeanUtils.copyProperties(this, item);

        item.setDramaVersion(new IdName(dramaVersionId, versionName));
        item.setTroupe(JsonUtil.fromJson(troupeJson, IdLangName.class));
        item.setTitles(JsonUtil.fromJson(titlesJson, LangStrings.class));
        item.setPrice(JsonUtil.fromJson(priceJson, GlobalPrice.class));
        item.setSalesSummary(JsonUtil.fromJson(salesSummaryJson, SalesSummary.class));
        item.setCategoryNames(JsonUtil.fromJson(categoryNamesJson, LangStrings.class));

        return item;
    }

    public String toString() {
        //
        return toJson();
    }

    public static ItemCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ItemCmo.class);
    }

    public static ItemCmo sample() {
        //
        Item item = Item.sample();
        item.setSalesSummary(SalesSummary.sample());
        return new ItemCmo(item);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }

}
