package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;
import java.util.Optional;

public interface CategoryRomRepository extends CassandraRepository<CategoryRomCmo, String> {
    //
    List<CategoryRomCmo> findAllById(String categoryId);
    Optional<CategoryRomCmo> findByIdAndLangCode(String categoryId, String langCode);
}
