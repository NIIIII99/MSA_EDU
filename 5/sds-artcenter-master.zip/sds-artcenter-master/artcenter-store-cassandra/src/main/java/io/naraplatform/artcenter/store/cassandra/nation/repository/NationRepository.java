package io.naraplatform.artcenter.store.cassandra.nation.repository;

import io.naraplatform.artcenter.store.cassandra.nation.cmo.NationCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface NationRepository extends CassandraRepository<NationCmo, String> {

}
