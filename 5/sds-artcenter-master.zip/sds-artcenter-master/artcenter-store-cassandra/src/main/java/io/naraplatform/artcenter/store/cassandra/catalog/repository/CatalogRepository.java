package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface CatalogRepository extends CassandraRepository<CatalogCmo, String> {
}
