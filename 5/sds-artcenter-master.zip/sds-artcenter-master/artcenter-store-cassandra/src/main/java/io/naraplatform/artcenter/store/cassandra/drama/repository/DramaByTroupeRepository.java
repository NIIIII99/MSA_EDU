package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaByTroupeCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DramaByTroupeRepository extends CassandraRepository<DramaByTroupeCmo, String> {
    //
    List<DramaByTroupeCmo> findAllByTroupeId(String troupeId, Pageable pageable);
}
