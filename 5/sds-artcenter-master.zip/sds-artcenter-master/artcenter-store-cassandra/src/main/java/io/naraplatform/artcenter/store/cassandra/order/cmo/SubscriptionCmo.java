package io.naraplatform.artcenter.store.cassandra.order.cmo;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.domain.order.command.model.SubscriptionState;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("subscription")
@Getter
@Setter
@NoArgsConstructor
public class SubscriptionCmo implements JsonSerializable {
    //
    @PrimaryKey //Column(name = "id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String id;
    //@PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;

    private String editionName;
    private String startDate;
    private String endDate;
    private SubscriptionState state;
    private String dramaVersionJson;
    private String dramaJson;
    private String base64Icon;
    private String teamJson;
    private String subscriberJson;

    public SubscriptionCmo(Subscription subscription){
        //
        BeanUtils.copyProperties(subscription, this);

        this.dramaJson = subscription.getDrama().toJson();
        this.dramaVersionJson = subscription.getDramaVersion().toJson();
        this.teamJson = subscription.getTeam().toJson();
        this.subscriberJson = subscription.getSubscriber().toJson();

    }

    public Subscription toDomain(){
        //
        Subscription subscription = new Subscription(this.id);

        BeanUtils.copyProperties(this, subscription);

        subscription.setDramaVersion(IdName.fromJson(this.dramaVersionJson));
        subscription.setDrama(IdName.fromJson(this.dramaJson));
        subscription.setTeam(IdName.fromJson(this.teamJson));
        subscription.setSubscriber(IdName.fromJson(this.subscriberJson));

        return subscription;
    }

    public String toString() {
        //
        return toJson();
    }

    public static SubscriptionCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubscriptionCmo.class);
    }

    public static SubscriptionCmo sample() {
        //
        return new SubscriptionCmo(Subscription.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
