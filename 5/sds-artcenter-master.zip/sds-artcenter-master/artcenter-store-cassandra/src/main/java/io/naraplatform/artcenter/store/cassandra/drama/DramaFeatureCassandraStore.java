package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureByDramaCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaFeatureByDramaRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaFeatureRepository;
import io.naraplatform.artcenter.store.drama.DramaFeatureDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DramaFeatureCassandraStore implements DramaFeatureDomainStore {
    //
    @Autowired
    DramaFeatureRepository dramaFeatureRepository;
    @Autowired
    DramaFeatureByDramaRepository dramaFeatureByDramaRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DramaFeature[%s] to retrieve.";

    @Override
    public void create(DramaFeature dramaFeature) {
        //
        dramaFeatureRepository.insert(new DramaFeatureCmo(dramaFeature));
        dramaFeatureByDramaRepository.insert(new DramaFeatureByDramaCmo(dramaFeature));
    }

    @Override
    public DramaFeature retrieve(String featureId) {
        //
        Optional<DramaFeatureCmo> dramaFeatureCmo = dramaFeatureRepository.findById(featureId);
        if (!dramaFeatureCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, featureId));
        }

        return dramaFeatureCmo.get().toDomain();
    }

    @Override
    public List<DramaFeature> retrieveAllByDramaId(String dramaId) {
        //
        Collection<DramaFeatureByDramaCmo> dramaFeatureByDramaCmos = dramaFeatureByDramaRepository.findAllByDramaId(dramaId);
        return dramaFeatureByDramaCmos
            .stream()
            .map(DramaFeatureByDramaCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(DramaFeature dramaFeature) {
        //
        dramaFeatureRepository.save(new DramaFeatureCmo(dramaFeature));
        dramaFeatureByDramaRepository.save(new DramaFeatureByDramaCmo(dramaFeature));
    }

    @Override
    public void delete(String dramaFeatureId) {
        //
        Optional<DramaFeatureCmo> dramaFeatureCmo = dramaFeatureRepository.findById(dramaFeatureId);

        if (dramaFeatureCmo.isPresent()) {
            DramaFeature dramaFeature = dramaFeatureCmo.get().toDomain();

            dramaFeatureRepository.delete(dramaFeatureCmo.get());
            dramaFeatureByDramaRepository.delete(new DramaFeatureByDramaCmo(dramaFeature));
        }
    }

}
