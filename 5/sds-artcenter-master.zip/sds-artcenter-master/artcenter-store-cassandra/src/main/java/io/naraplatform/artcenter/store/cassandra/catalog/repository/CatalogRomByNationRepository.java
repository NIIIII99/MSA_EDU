package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogRomByNationCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface CatalogRomByNationRepository extends CassandraRepository<CatalogRomByNationCmo, String> {
    //
    List<CatalogRomByNationCmo> findAllByNationId(String nationId);
}
