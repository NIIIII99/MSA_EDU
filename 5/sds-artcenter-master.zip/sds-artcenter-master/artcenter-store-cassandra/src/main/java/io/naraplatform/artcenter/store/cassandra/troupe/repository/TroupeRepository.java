package io.naraplatform.artcenter.store.cassandra.troupe.repository;

import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TroupeRepository extends CassandraRepository<TroupeCmo, String> {
}
