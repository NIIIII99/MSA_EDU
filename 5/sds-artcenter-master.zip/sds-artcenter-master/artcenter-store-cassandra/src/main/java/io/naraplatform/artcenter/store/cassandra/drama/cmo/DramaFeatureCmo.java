package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.List;

@Table("drama_feature")
@Getter
@Setter
@NoArgsConstructor
public class DramaFeatureCmo implements JsonSerializable {

    @PrimaryKey
    private String id;

    private int index;
    private String dramaId;
    private String defaultLang;
    private String namesJson;
    private String descriptionsJson;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;

    public DramaFeatureCmo(DramaFeature dramaFeature) {
        //
        BeanUtils.copyProperties(dramaFeature, this);
        this.namesJson = dramaFeature.getNames().toJson();
        this.descriptionsJson = dramaFeature.getDescriptions().toJson();
    }

    public DramaFeature toDomain() {
        //
        DramaFeature dramaFeature = new DramaFeature(this.id);
        BeanUtils.copyProperties(this, dramaFeature);
        dramaFeature.setNames(LangStrings.fromJson(this.namesJson));
        dramaFeature.setDescriptions(LangStrings.fromJson(this.descriptionsJson));

        return dramaFeature;
    }
}
