package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_ticket_by_drama")
@Getter
@Setter
@NoArgsConstructor
public class DramaTicketByDramaCmo implements JsonSerializable {

    @PrimaryKey
    private String dramaId;

    private String id;
    private String troupeId;

    public DramaTicketByDramaCmo(String id) {
        //
        this.id = id;
    }

    public DramaTicketByDramaCmo(DramaTicket dramaTicket) {
        //
        BeanUtils.copyProperties(dramaTicket, this);
    }

    public DramaTicket toDomain(){
        //
        DramaTicket dramaTicket = new DramaTicket(this.id);

        BeanUtils.copyProperties(this, dramaTicket);

        return dramaTicket;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaTicketByDramaCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaTicketByDramaCmo.class);
    }

    public static DramaTicketByDramaCmo sample() {
        //
        DramaTicket dramaTicket = DramaTicket.sample();
        return new DramaTicketByDramaCmo(dramaTicket);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
