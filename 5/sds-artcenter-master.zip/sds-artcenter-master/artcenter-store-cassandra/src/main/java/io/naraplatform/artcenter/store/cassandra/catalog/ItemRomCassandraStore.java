package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomByCatalogCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomByDramaCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomByTroupeCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.ItemRomByCatalogRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.ItemRomByDramaRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.ItemRomByTroupeRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.ItemRomRepository;
import io.naraplatform.artcenter.store.catalog.ItemRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class ItemRomCassandraStore implements ItemRomStore {
    //
    @Autowired
    ItemRomRepository itemRomRepository;
    @Autowired
    ItemRomByDramaRepository itemRomByDramaRepository;
    @Autowired
    ItemRomByCatalogRepository itemRomByCatalogRepository;
    @Autowired
    ItemRomByTroupeRepository itemRomByTroupeRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No itemRom[%s] to retrieve.";

    @Override
    public void create(ItemRom itemRom) {
        //
        itemRomRepository.insert(new ItemRomCmo(itemRom));
        itemRomByDramaRepository.insert(new ItemRomByDramaCmo(itemRom));
        itemRomByCatalogRepository.insert(new ItemRomByCatalogCmo(itemRom));
        itemRomByTroupeRepository.insert(new ItemRomByTroupeCmo(itemRom));
    }

    @Override
    public List<ItemRom> retrieve(String itemId) {
        List<ItemRomCmo> itemRomCmos = itemRomRepository.findAllById(itemId);
        return itemRomCmos
            .stream()
            .map(ItemRomCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public ItemRom retrieve(String itemId, String langCode) {
        //
        Optional<ItemRomCmo> itemRomCmo = itemRomRepository.findByIdAndLangCode(itemId, langCode);
        if (!itemRomCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, itemId));
        }

        return itemRomCmo.get().toDomain();
    }

    @Override
    public List<ItemRom> retrieve(String catalogId, String categoryId, String langCode, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ItemRomByCatalogCmo> itemRomByCatalogCmos = itemRomByCatalogRepository.findAllByCatalogIdAndCategoryIdAndLangCode(catalogId, categoryId, langCode, pageable);
        return itemRomByCatalogCmos
            .stream()
            .filter(cmo -> cmo.getCategoryId().equals(categoryId))
            .map(ItemRomByCatalogCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<ItemRom> retrieve(String catalogId, String langCode, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ItemRomByCatalogCmo> itemRomByCatalogCmos = itemRomByCatalogRepository.findAllByCatalogIdAndLangCode(catalogId, langCode, pageable);
        return itemRomByCatalogCmos
            .stream()
            .map(ItemRomByCatalogCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<ItemRom> retrieveBySubscriptionCount(String catalogId, String langCode, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ItemRomByCatalogCmo> itemRomByCatalogCmos = itemRomByCatalogRepository.findAllByCatalogIdAndLangCode(catalogId, langCode, pageable);
        return itemRomByCatalogCmos
            .stream()
            .map(ItemRomByCatalogCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<ItemRom> retrieveBySalesAmount(String catalogId, String langCode, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ItemRomByCatalogCmo> itemRomByCatalogCmos = itemRomByCatalogRepository.findAllByCatalogIdAndLangCode(catalogId, langCode, pageable);
        return itemRomByCatalogCmos
            .stream()
            .map(ItemRomByCatalogCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<ItemRom> retrieveByTroupe(String troupeId, String langCode, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ItemRomByTroupeCmo> itemRomByTroupeCmos = itemRomByTroupeRepository.findAllByTroupeIdAndLangCode(troupeId, langCode, pageable);
        return itemRomByTroupeCmos
            .stream()
            .map(ItemRomByTroupeCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(ItemRom itemRom) {
        //
        itemRomRepository.save(new ItemRomCmo(itemRom));
        itemRomByDramaRepository.save(new ItemRomByDramaCmo(itemRom));
        itemRomByCatalogRepository.save(new ItemRomByCatalogCmo(itemRom));
        itemRomByTroupeRepository.save(new ItemRomByTroupeCmo(itemRom));
    }

    @Override
    public void deleteByDramaVersion(String dramaVersionId) {
        //
        List<ItemRomByDramaCmo> itemRomByDramaCmos = itemRomByDramaRepository.findAllByDramaVersionId(dramaVersionId);

        itemRomByDramaCmos.stream().forEach(romCmo -> itemRomByDramaRepository.delete(romCmo));
        itemRomByDramaCmos.stream().map(romCmo -> romCmo.toDomain()).forEach(itemRom -> itemRomRepository.delete(new ItemRomCmo(itemRom)));
        itemRomByDramaCmos.stream().map(romCmo -> romCmo.toDomain()).forEach(itemRom -> itemRomByCatalogRepository.delete(new ItemRomByCatalogCmo(itemRom)));
        itemRomByDramaCmos.stream().map(romCmo -> romCmo.toDomain()).forEach(itemRom -> itemRomByTroupeRepository.delete(new ItemRomByTroupeCmo(itemRom)));
    }

}
