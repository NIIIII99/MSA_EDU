package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionRomByDramaCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionRomCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaVersionRomByDramaRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaVersionRomRepository;
import io.naraplatform.artcenter.store.drama.DramaVersionRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DramaVersionRomCassandraStore implements DramaVersionRomStore {
    //
    @Autowired
    DramaVersionRomRepository dramaVersionRomRepository;
    @Autowired
    DramaVersionRomByDramaRepository dramaVersionRomByDramaRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DramaRom[%s] to retrieve.";

    @Override
    public void create(DramaVersionRom dramaVersionRom) {
        //
        dramaVersionRomRepository.insert(new DramaVersionRomCmo(dramaVersionRom));
        dramaVersionRomByDramaRepository.insert(new DramaVersionRomByDramaCmo(dramaVersionRom));
    }

    @Override
    public DramaVersionRom retrieve(String dramaVersionId, String langCode) {
        //
        Optional<DramaVersionRomCmo> dramaVersionRomCmo = dramaVersionRomRepository.findByIdAndLangCode(dramaVersionId, langCode);
        if (!dramaVersionRomCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaVersionId));
        }

        return dramaVersionRomCmo.get().toDomain();
    }

    @Override
    public List<DramaVersionRom> retrieve(String dramaId) {
        //
        return dramaVersionRomByDramaRepository.findByDramaId(dramaId)
            .stream()
            .map(DramaVersionRomByDramaCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<DramaVersionRom> retrieveAllByDramaId(String dramaId, String langCode) {
        //
        List<DramaVersionRomByDramaCmo> dramaVersionRomByDramaCmos = dramaVersionRomByDramaRepository.findAllByDramaIdAndLangCode(dramaId, langCode);
        return dramaVersionRomByDramaCmos
            .stream()
            .map(DramaVersionRomByDramaCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<DramaVersionRom> retrieveVersionsByDrama(String dramaId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        return dramaVersionRomByDramaRepository.findByDramaId(dramaId, pageable)
            .stream()
            .map(DramaVersionRomByDramaCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(DramaVersionRom dramaVersionRom) {
        //
        dramaVersionRomRepository.save(new DramaVersionRomCmo(dramaVersionRom));
        dramaVersionRomByDramaRepository.save(new DramaVersionRomByDramaCmo(dramaVersionRom));
    }

    @Override
    public void delete(String dramaVersionId) {
        //
        List<DramaVersionRomCmo> dramaVersionRomCmos = dramaVersionRomRepository.findAllById(dramaVersionId);

        dramaVersionRomCmos.stream().forEach(dramaVersionRom -> dramaVersionRomRepository.delete(dramaVersionRom));
        dramaVersionRomCmos.stream().map(cmo -> cmo.toDomain()).forEach(rom -> dramaVersionRomByDramaRepository.delete(new DramaVersionRomByDramaCmo(rom)));
    }

    @Override
    public void delete(String dramaVersionId, String langCode) {
        //
        Optional<DramaVersionRomCmo> dramaVersionRomCmo = dramaVersionRomRepository.findByIdAndLangCode(dramaVersionId, langCode);

        if (dramaVersionRomCmo.isPresent()) {
            DramaVersionRom dramaVersionRom = dramaVersionRomCmo.get().toDomain();

            dramaVersionRomRepository.delete(new DramaVersionRomCmo(dramaVersionRom));
            dramaVersionRomByDramaRepository.delete(new DramaVersionRomByDramaCmo(dramaVersionRom));
        }
    }

}
