package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Indexed;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.List;

@Table("drama_feature_rom")
@Getter
@Setter
@NoArgsConstructor
public class DramaFeatureRomCmo implements JsonSerializable{
    //
    @PrimaryKeyColumn(name = "id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String id;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "index", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private int index;

    private String defaultLang;
    private String name;
    private String description;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;

    @Indexed
    private String dramaId;

    public DramaFeatureRomCmo(DramaFeatureRom dramaFeatureRom){
        //
        BeanUtils.copyProperties(dramaFeatureRom, this);
    }

    public DramaFeatureRom toDomain(){
        //
        DramaFeatureRom dramaFeatureRom = new DramaFeatureRom(this.id);
        BeanUtils.copyProperties(this, dramaFeatureRom);
        return dramaFeatureRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaFeatureRomCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaFeatureRomCmo.class);
    }

    public static DramaFeatureRomCmo sample() {
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        return new DramaFeatureRomCmo(dramaFeatureRom);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }

}
