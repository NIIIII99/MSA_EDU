package io.naraplatform.artcenter.store.cassandra.order.repository;

import io.naraplatform.artcenter.store.cassandra.order.cmo.SubscriptionBySubscriberCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface SubscriptionBySubscriberRepository extends CassandraRepository<SubscriptionBySubscriberCmo, String> {
    //
    List<SubscriptionBySubscriberCmo> findAllBySubscriberId(String subscriberId);
}
