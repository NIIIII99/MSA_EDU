package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaTicketCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface DramaTicketRepository extends CassandraRepository<DramaTicketCmo, String> {
}
