package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionRomByDramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DramaVersionRomByDramaRepository extends CassandraRepository<DramaVersionRomByDramaCmo, String> {
    //
    List<DramaVersionRomByDramaCmo> findAllByDramaIdAndLangCode(String dramaId, String langCode);
    List<DramaVersionRomByDramaCmo> findByDramaId(String dramaId);
    List<DramaVersionRomByDramaCmo> findByDramaId(String dramaId, Pageable pageable);
}
