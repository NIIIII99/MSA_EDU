package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_version_rom")
@Getter
@Setter
@NoArgsConstructor
public class DramaVersionRomCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String id;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;

    private String versionName;
    private String releaseNote;
    private String supportLangs;
    private String priceJson;
    private String releaseDate;
    private String dramaId;

    public DramaVersionRomCmo(DramaVersionRom dramaVersionRom) {
        //
        BeanUtils.copyProperties(dramaVersionRom, this);
        this.priceJson = dramaVersionRom.getPrice().toJson();
    }

    public DramaVersionRom toDomain(){
        //
        DramaVersionRom dramaVersionRom = new DramaVersionRom(this.id);
        BeanUtils.copyProperties(this, dramaVersionRom);
        dramaVersionRom.setPrice(GlobalPrice.fromJson(this.priceJson));

        return dramaVersionRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaVersionRomCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaVersionRomCmo.class);
    }

    public static DramaVersionRomCmo sample() {
        //
        return new DramaVersionRomCmo(DramaVersionRom.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
