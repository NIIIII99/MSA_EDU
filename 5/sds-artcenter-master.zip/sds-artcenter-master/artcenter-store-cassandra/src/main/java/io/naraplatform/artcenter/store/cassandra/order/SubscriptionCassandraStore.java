package io.naraplatform.artcenter.store.cassandra.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.store.cassandra.order.cmo.SubscriptionBySubscriberCmo;
import io.naraplatform.artcenter.store.cassandra.order.cmo.SubscriptionByTeamCmo;
import io.naraplatform.artcenter.store.cassandra.order.cmo.SubscriptionCmo;
import io.naraplatform.artcenter.store.cassandra.order.repository.SubscriptionBySubscriberRepository;
import io.naraplatform.artcenter.store.cassandra.order.repository.SubscriptionByTeamRepository;
import io.naraplatform.artcenter.store.cassandra.order.repository.SubscriptionRepository;
import io.naraplatform.artcenter.store.order.SubscriptionDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class SubscriptionCassandraStore implements SubscriptionDomainStore {
    //
    @Autowired
    SubscriptionRepository subscriptionRepository;
    @Autowired
    SubscriptionBySubscriberRepository subscriptionBySubscriberRepository;
    @Autowired
    SubscriptionByTeamRepository subscriptionByTeamRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No Subscription[%s] to retrieve.";

    @Override
    public void create(Subscription subscription) {
        //
        subscriptionRepository.insert(new SubscriptionCmo(subscription));
        subscriptionBySubscriberRepository.insert(new SubscriptionBySubscriberCmo(subscription));
        subscriptionByTeamRepository.insert(new SubscriptionByTeamCmo(subscription));
    }

    @Override
    public Subscription retrieve(String subscriptionId) {
        //
        Optional<SubscriptionCmo> subscriptionCmo = subscriptionRepository.findById(subscriptionId);
        if (!subscriptionCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, subscriptionId));
        }

        return subscriptionCmo.get().toDomain();
    }

    @Override
    public Subscription retrieve(String subscriptionId, String langCode) {
        //
        Optional<SubscriptionCmo> subscriptionCmo = subscriptionRepository.findByIdAndLangCode(subscriptionId, langCode);
        if (!subscriptionCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, subscriptionId));
        }

        return subscriptionCmo.get().toDomain();
    }

    @Override
    public List<Subscription> retrieveSubscriptionsBySubscriber(String subscriberId) {
        //
        List<SubscriptionBySubscriberCmo> subscriptionBySubscriberCmos = subscriptionBySubscriberRepository.findAllBySubscriberId(subscriberId);
        return subscriptionBySubscriberCmos
            .stream()
            .map(cmo -> cmo.toDomain())
            .collect(Collectors.toList());
    }

    @Override
    public List<Subscription> retrieveSubscriptionsByTeam(String teamId) {
        //
        List<SubscriptionByTeamCmo> subscriptionByTeamCmos = subscriptionByTeamRepository.findAllByTeamId(teamId);
        return subscriptionByTeamCmos
            .stream()
            .map(cmo -> cmo.toDomain())
            .collect(Collectors.toList());
    }

    @Override
    public void update(Subscription subscription) {
        //
        subscriptionRepository.save(new SubscriptionCmo(subscription));
        subscriptionBySubscriberRepository.save(new SubscriptionBySubscriberCmo(subscription));
        subscriptionByTeamRepository.save(new SubscriptionByTeamCmo(subscription));
    }

    @Override
    public void delete(String subscriptionId) {
        //
        Optional<SubscriptionCmo> subscriptionCmo = subscriptionRepository.findById(subscriptionId);

        if (subscriptionCmo.isPresent()) {
            Subscription subscription = subscriptionCmo.get().toDomain();

            subscriptionRepository.delete(subscriptionCmo.get());
            subscriptionBySubscriberRepository.delete(new SubscriptionBySubscriberCmo(subscription));
            subscriptionByTeamRepository.delete(new SubscriptionByTeamCmo(subscription));
        }
    }
}
