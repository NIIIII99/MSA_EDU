package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;
import java.util.Optional;

public interface DramaVersionRomRepository extends CassandraRepository<DramaVersionRomCmo, String> {
    //
    Optional<DramaVersionRomCmo> findByIdAndLangCode(String dramaVersionId, String langCode);
    List<DramaVersionRomCmo> findAllById(String dramaVersionId);
}
