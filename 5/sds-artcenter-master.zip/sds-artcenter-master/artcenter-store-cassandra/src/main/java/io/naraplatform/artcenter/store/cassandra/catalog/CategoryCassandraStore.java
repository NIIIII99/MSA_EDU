package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CategoryRepository;
import io.naraplatform.artcenter.store.catalog.CategoryDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class CategoryCassandraStore implements CategoryDomainStore {
    //
    @Autowired
    CategoryRepository categoryRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No Category[%s] to retrieve.";

    @Override
    public void create(Category category) {
        //
        categoryRepository.insert(new CategoryCmo(category));
    }

    @Override
    public Category retrieve(String categoryId) {
        //
        Optional<CategoryCmo> categoryCmo = categoryRepository.findById(categoryId);
        if (!categoryCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, categoryId));
        }

        return categoryCmo.get().toDomain();
    }

    @Override
    public List<Category> retrieveAll() {
        //
        List<CategoryCmo> categoryCmos = categoryRepository.findAll();
        return categoryCmos
            .stream()
            .map(CategoryCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(Category category) {
        //
        categoryRepository.save(new CategoryCmo(category));
    }

    @Override
    public void delete(String categoryId) {
        //
        categoryRepository.deleteById(categoryId);
    }

    @Override
    public List<Category> retrieveAllByCatalogId(String catalogId) {
        List<CategoryCmo> categoryCmos = categoryRepository.findAllByCatalogId(catalogId);
        return categoryCmos
            .stream()
            .map(CategoryCmo::toDomain)
            .collect(Collectors.toList());
    }

}
