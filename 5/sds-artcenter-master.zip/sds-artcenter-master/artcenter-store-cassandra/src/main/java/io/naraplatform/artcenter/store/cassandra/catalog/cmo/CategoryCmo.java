package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.Indexed;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("category")
@Getter
@Setter
@NoArgsConstructor
public class CategoryCmo implements JsonSerializable{

    @PrimaryKey
    private String id;

    @Indexed
    private String catalogId;
    private String namesJson;
    private String memosJson;

    public CategoryCmo(Category category) {
        //
        BeanUtils.copyProperties(category,this);

        this.namesJson = category.getNames().toJson();
        this.memosJson = category.getMemos().toJson();
    }

    public Category toDomain() {
        //
        Category category = new Category(this.id);

        BeanUtils.copyProperties(this,category);

        category.setNames(LangStrings.fromJson(this.namesJson));
        category.setMemos(LangStrings.fromJson(this.memosJson));

        return category;
    }

    public String toString(){
        //
        return toJson();
    }

    public static CategoryCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CategoryCmo.class);
    }

    public static CategoryCmo sample() {
        //
        return new CategoryCmo(Category.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
