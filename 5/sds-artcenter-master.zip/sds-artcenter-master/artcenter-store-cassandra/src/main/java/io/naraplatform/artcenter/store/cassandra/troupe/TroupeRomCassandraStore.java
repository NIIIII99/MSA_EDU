package io.naraplatform.artcenter.store.cassandra.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeRomByEmailCmo;
import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeRomByLoginUserIdCmo;
import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeRomCmo;
import io.naraplatform.artcenter.store.cassandra.troupe.repository.TroupeRomByEmailRepository;
import io.naraplatform.artcenter.store.cassandra.troupe.repository.TroupeRomByLoginUserIdRepository;
import io.naraplatform.artcenter.store.cassandra.troupe.repository.TroupeRomRepository;
import io.naraplatform.artcenter.store.troupe.TroupeRomStore;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class TroupeRomCassandraStore implements TroupeRomStore {
    //
	@Autowired
    TroupeRomRepository troupeRomRepository;
    @Autowired
    TroupeRomByEmailRepository troupeRomByEmailRepository;
    @Autowired
    TroupeRomByLoginUserIdRepository troupeRomByLoginUserIdRepository;

	@Override
	public void create(Troupe troupe) {
		//
		troupeRomRepository.insert(new TroupeRomCmo(troupe));
        troupeRomByEmailRepository.insert(new TroupeRomByEmailCmo(troupe));
        troupeRomByLoginUserIdRepository.insert(new TroupeRomByLoginUserIdCmo(troupe));
	}
	
	@Override
	public String retrieveJson(String troupeId) {
		//
		Optional<TroupeRomCmo> troupeRCpo = troupeRomRepository.findById(troupeId);
		if (!troupeRCpo.isPresent()) {
			throw new NoSuchElementException(String.format("No troupe[%s] to retrieve.", troupeId));
		}
		
		return troupeRCpo.get().getJson();
	}

	@Override
	public String retrieveJsonByEmail(String email) {
		//
        Optional<TroupeRomByEmailCmo> troupeRomByEmailCmo = troupeRomByEmailRepository.findByEmail(email);
        if (!troupeRomByEmailCmo.isPresent()) {
            throw new NoSuchElementException(String.format("No troupe[%s] to retrieve.", email));
        }

        return troupeRomByEmailCmo.get().getJson();
	}

	@Override
	public String retrieveJsonByLoginUserId(String loginUserId) {
		//
		Optional<TroupeRomByLoginUserIdCmo> troupeRomByLoginUserIdCmo = troupeRomByLoginUserIdRepository.findByLoginUserId(loginUserId);
		if (!troupeRomByLoginUserIdCmo.isPresent()) {
			throw new NoSuchElementException(String.format("No troupe[%s] to retrieve.", loginUserId));
		}
		
		return troupeRomByLoginUserIdCmo.get().getJson();
	}

    @Override
    public List<String> retrieveAllJsons(int offset, int limit) {
	    //
        Pageable pageable = PageRequest.of(offset, limit);
        Slice<TroupeRomCmo> troupes = troupeRomRepository.findAll(pageable);

        return troupes
            .stream()
            .map(TroupeRomCmo::getJson)
            .collect(Collectors.toList());
	}

    @Override
    public void update(Troupe troupe) {
        //
        troupeRomRepository.save(new TroupeRomCmo(troupe));
        troupeRomByEmailRepository.save(new TroupeRomByEmailCmo(troupe));
        troupeRomByLoginUserIdRepository.save(new TroupeRomByLoginUserIdCmo(troupe));
    }

    @Override
    public void delete(String troupeId) {
	    //
        Optional<TroupeRomCmo> troupeRomCmo = troupeRomRepository.findById(troupeId);

        if (troupeRomCmo.isPresent()) {
            Troupe troupe = troupeRomCmo.get().toDomain();

            troupeRomRepository.delete(troupeRomCmo.get());
            troupeRomByEmailRepository.delete(new TroupeRomByEmailCmo(troupe));
            troupeRomByLoginUserIdRepository.delete(new TroupeRomByLoginUserIdCmo(troupe));
        }
    }

    @Override
    public boolean existsByEmail(String email) {
	    //
        String json = StringUtils.EMPTY;

        try {
            json = retrieveJsonByEmail(email);
        } catch (Exception e) {
            return false;
        }

        return !json.isEmpty();
    }
}
