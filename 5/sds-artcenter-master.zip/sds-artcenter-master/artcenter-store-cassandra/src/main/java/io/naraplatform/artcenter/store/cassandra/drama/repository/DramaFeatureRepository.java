package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface DramaFeatureRepository extends CassandraRepository<DramaFeatureCmo, String> {
}
