package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_ticket")
@Getter
@Setter
@NoArgsConstructor
public class DramaTicketCmo implements JsonSerializable {

    @PrimaryKey
    private String id;

    private String dramaId;
    private String troupeId;

    public DramaTicketCmo(String id) {
        //
        this.id = id;
    }

    public DramaTicketCmo(DramaTicket dramaTicket) {
        //
        BeanUtils.copyProperties(dramaTicket, this);
    }

    public DramaTicket toDomain(){
        //
        DramaTicket dramaTicket = new DramaTicket(this.id);

        BeanUtils.copyProperties(this, dramaTicket);

        return dramaTicket;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaTicketCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaTicketCmo.class);
    }

    public static DramaTicketCmo sample() {
        //
        DramaTicket dramaTicket = DramaTicket.sample();
        return new DramaTicketCmo(dramaTicket);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
