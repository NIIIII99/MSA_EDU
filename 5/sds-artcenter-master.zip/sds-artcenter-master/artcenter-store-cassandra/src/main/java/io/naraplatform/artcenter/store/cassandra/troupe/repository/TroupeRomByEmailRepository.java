package io.naraplatform.artcenter.store.cassandra.troupe.repository;

import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeRomByEmailCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TroupeRomByEmailRepository extends CassandraRepository<TroupeRomByEmailCmo, String> {
    //
	Optional<TroupeRomByEmailCmo> findByEmail(String email);
}
