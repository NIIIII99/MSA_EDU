package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryRomByCatalogCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryRomCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CategoryRomByCatalogRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CategoryRomRepository;
import io.naraplatform.artcenter.store.catalog.CategoryRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class CategoryRomCassandraStore implements CategoryRomStore {
    //
    @Autowired
    CategoryRomRepository categoryRomRepository;
    @Autowired
    CategoryRomByCatalogRepository categoryRomByCatalogRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No categoryRom[%s] to retrieve.";

    @Override
    public void create(CategoryRom categoryRom) {
        //
        CategoryRomCmo categoryRomCmo = new CategoryRomCmo(categoryRom);
        categoryRomRepository.insert(categoryRomCmo);
        categoryRomByCatalogRepository.insert(new CategoryRomByCatalogCmo(categoryRom));
    }

    @Override
    public List<CategoryRom> retrieve(String categoryId) {
        List<CategoryRomCmo> categoryRomCmos = categoryRomRepository.findAllById(categoryId);
        return categoryRomCmos
            .stream()
            .map(CategoryRomCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public CategoryRom retrieve(String categoryId, String langCode) {
        //
        Optional<CategoryRomCmo> categoryRomCmo = categoryRomRepository.findByIdAndLangCode(categoryId, langCode);
        if (!categoryRomCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, categoryId));
        }

        return categoryRomCmo.get().toDomain();
    }

    @Override
    public List<CategoryRom> retrieveAllByCatalogId(String catalogId) {
        //
        List<CategoryRomByCatalogCmo> categoryRomByCatalogCmos = categoryRomByCatalogRepository.findAllByCatalogId(catalogId);
        return categoryRomByCatalogCmos
            .stream()
            .map(CategoryRomByCatalogCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<CategoryRom> retrieveAllByCatalogId(String catalogId, String langCode) {
        //
        return categoryRomByCatalogRepository.findAllByCatalogIdAndLangCode(catalogId, langCode)
            .stream()
            .map(CategoryRomByCatalogCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(CategoryRom categoryRom) {
        //
        categoryRomRepository.save(new CategoryRomCmo(categoryRom));
        categoryRomByCatalogRepository.save(new CategoryRomByCatalogCmo(categoryRom));
    }

    @Override
    public void delete(String categoryId) {
        //
        List<CategoryRomCmo> categoryRomCmos = categoryRomRepository.findAllById(categoryId);

        categoryRomCmos.stream().forEach(categoryRomCmo -> categoryRomRepository.delete(categoryRomCmo));
        categoryRomCmos.stream().map(categoryRomCmo -> categoryRomCmo.toDomain()).forEach(categoryRom -> categoryRomByCatalogRepository.delete(new CategoryRomByCatalogCmo(categoryRom)));
    }
}
