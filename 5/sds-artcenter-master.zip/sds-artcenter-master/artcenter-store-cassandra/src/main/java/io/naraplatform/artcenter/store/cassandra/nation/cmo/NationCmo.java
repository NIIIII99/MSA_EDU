package io.naraplatform.artcenter.store.cassandra.nation.cmo;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("nation")
@Getter
@Setter
@NoArgsConstructor
public class NationCmo {

    @PrimaryKey
    private String id;

    private String json;

    public NationCmo(Nation nation) {
        //
        this.id = nation.getId();
        this.json = nation.toJson();
    }

    public Nation toDomain() {
        //
        return Nation.fromJson(this.json);
    }

}
