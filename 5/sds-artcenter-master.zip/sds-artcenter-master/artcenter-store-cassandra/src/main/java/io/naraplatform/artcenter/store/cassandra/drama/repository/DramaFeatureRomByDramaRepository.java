package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureRomByDramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface DramaFeatureRomByDramaRepository extends CassandraRepository<DramaFeatureRomByDramaCmo, String> {
    //
    List<DramaFeatureRomByDramaCmo> findAllByDramaIdAndLangCode(String dramaId, String langCode);
}
