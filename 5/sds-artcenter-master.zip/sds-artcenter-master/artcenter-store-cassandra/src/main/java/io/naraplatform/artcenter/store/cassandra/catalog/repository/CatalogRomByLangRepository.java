package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogRomByLangCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface CatalogRomByLangRepository extends CassandraRepository<CatalogRomByLangCmo, String> {
    //
    List<CatalogRomByLangCmo> findAllByLangCode(String langCode);
    List<CatalogRomByLangCmo> findAllById(String catalogId);
}
