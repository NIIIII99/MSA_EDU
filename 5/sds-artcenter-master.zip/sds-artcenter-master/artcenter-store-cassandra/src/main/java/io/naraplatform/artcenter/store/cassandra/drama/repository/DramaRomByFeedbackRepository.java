package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaRomByFeedbackCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface DramaRomByFeedbackRepository extends CassandraRepository<DramaRomByFeedbackCmo, String> {
    //
    List<DramaRomByFeedbackCmo> findAllByFeedbackIdAndLangCode(String feedbackId, String langCode);
}
