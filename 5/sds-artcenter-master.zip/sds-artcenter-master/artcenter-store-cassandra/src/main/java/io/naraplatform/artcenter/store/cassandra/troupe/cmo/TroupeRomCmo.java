package io.naraplatform.artcenter.store.cassandra.troupe.cmo;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("troupe_rom")
@Getter
@Setter
@ToString
@NoArgsConstructor
public class TroupeRomCmo {

	@PrimaryKey
	private String id;
	private String json;

	public TroupeRomCmo(Troupe troupe) {
	    //
        BeanUtils.copyProperties(troupe, this);

        this.json = JsonUtil.toJson(troupe);
    }

    public Troupe toDomain(){
        //
        return Troupe.fromJson(this.json);
    }

}
