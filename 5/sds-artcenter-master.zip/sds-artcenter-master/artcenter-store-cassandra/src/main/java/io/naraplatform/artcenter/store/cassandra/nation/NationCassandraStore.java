package io.naraplatform.artcenter.store.cassandra.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.artcenter.store.cassandra.nation.cmo.NationCmo;
import io.naraplatform.artcenter.store.cassandra.nation.repository.NationRepository;
import io.naraplatform.artcenter.store.nation.NationDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class NationCassandraStore implements NationDomainStore {

    @Autowired
    NationRepository nationRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No Nation[%s] to retrieve.";

    @Override
    public void create(Nation nation) {
        //
        nationRepository.insert(new NationCmo(nation));
    }

    @Override
    public Nation retrieve(String nationId) {
        //
        Optional<NationCmo> nationCmo = nationRepository.findById(nationId);
        if (!nationCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, nationId));
        }

        return nationCmo.get().toDomain();
    }

    @Override
    public List<Nation> retrieveAll() {
        //
        return nationRepository.findAll()
            .stream()
            .map(cmo -> cmo.toDomain())
            .collect(Collectors.toList());
    }

    @Override
    public void update(Nation nation) {
        //
        nationRepository.save(new NationCmo(nation));
    }

    @Override
    public void delete(String nationId) {
        //
        nationRepository.deleteById(nationId);
    }

}
