package io.naraplatform.artcenter.store.cassandra;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.SchemaAction;
import org.springframework.data.cassandra.core.cql.keyspace.CreateKeyspaceSpecification;
import org.springframework.data.cassandra.core.cql.keyspace.KeyspaceOption;

import java.util.Collections;
import java.util.List;

@Configuration
public class CassandraConfig extends AbstractCassandraConfiguration {

	@Value("${cassandra.contactPoints}")
	private String contactPoints;

	@Value("${cassandra.cqlPort}")
	private int port;

	@Value("${cassandra.keyspace-name}")
	private String keySpace;

	@Value("${cassandra.basePackages}")
	private String basePackages;

	@Override
	protected List<CreateKeyspaceSpecification> getKeyspaceCreations() {
		return Collections.singletonList(CreateKeyspaceSpecification.createKeyspace(keySpace)
				.ifNotExists()
				.with(KeyspaceOption.DURABLE_WRITES, true)
				.withSimpleReplication());
	}

	@Override
	protected String getKeyspaceName() {
		return keySpace;
	}

	@Override
	protected String getContactPoints() {
		return contactPoints;
	}

	@Override
	protected int getPort() {
		return port;
	}

	@Override
	public SchemaAction getSchemaAction() {
		return SchemaAction.CREATE_IF_NOT_EXISTS;
	}

	@Override
	public String[] getEntityBasePackages() {
		return new String[] {basePackages};
	}

	@Override
    public List<String> getStartupScripts() {
	    //
        return Collections.emptyList();
    }

}
