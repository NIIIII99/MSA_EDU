package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogRomByLangCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogRomByNationCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CatalogRomCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CatalogRomByLangRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CatalogRomByNationRepository;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.CatalogRomRepository;
import io.naraplatform.artcenter.store.catalog.CatalogRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class CatalogRomCassandraStore implements CatalogRomStore {
    //
    @Autowired
    CatalogRomRepository catalogRomRepository;
    @Autowired
    CatalogRomByLangRepository catalogRomByLangRepository;
    @Autowired
    CatalogRomByNationRepository catalogRomByNationRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No catalogRom[%s] to retrieve.";

    @Override
    public void create(CatalogRom catalogRom) {
        //
        catalogRomRepository.insert(new CatalogRomCmo(catalogRom));
        catalogRomByLangRepository.insert(new CatalogRomByLangCmo(catalogRom));
        catalogRomByNationRepository.insert(new CatalogRomByNationCmo(catalogRom));
    }

    @Override
    public CatalogRom retrieve(String catalogId, String langCode) {
        //
        Optional<CatalogRomCmo> catalogRomCmo = catalogRomRepository.findByIdAndLangCode(catalogId, langCode);
        if (!catalogRomCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, catalogId));
        }

        return catalogRomCmo.get().toDomain();
    }

    @Override
    public List<CatalogRom> retrieveAllByLangCode(String langCode) {
        //
        return catalogRomByLangRepository.findAllByLangCode(langCode)
            .stream()
            .map(CatalogRomByLangCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<CatalogRom> retrieveAllByNationId(String nationId) {
        //
        List<CatalogRomByNationCmo> catalogRomByNationCmos = catalogRomByNationRepository.findAllByNationId(nationId);
        return catalogRomByNationCmos
            .stream()
            .map(CatalogRomByNationCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(CatalogRom catalogRom) {
        //
        catalogRomRepository.save(new CatalogRomCmo(catalogRom));
        catalogRomByLangRepository.save(new CatalogRomByLangCmo(catalogRom));
        catalogRomByNationRepository.save(new CatalogRomByNationCmo(catalogRom));
    }

    @Override
    public void delete(String catalogId) {
        //
        List<CatalogRomCmo> catalogRoms = catalogRomRepository.findAllById(catalogId);

        catalogRoms.stream().forEach(catalogRom -> catalogRomRepository.delete(catalogRom));
        catalogRoms.stream().map(catalogRomCmo -> catalogRomCmo.toDomain()).forEach(catalogRom -> catalogRomByLangRepository.delete(new CatalogRomByLangCmo(catalogRom)));
        catalogRoms.stream().map(catalogRomCmo -> catalogRomCmo.toDomain()).forEach(catalogRom -> catalogRomByNationRepository.delete(new CatalogRomByNationCmo(catalogRom)));
    }
}
