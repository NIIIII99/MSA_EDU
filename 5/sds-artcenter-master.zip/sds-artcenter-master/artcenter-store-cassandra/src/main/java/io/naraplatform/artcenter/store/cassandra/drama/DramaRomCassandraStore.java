package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaRomByFeedbackCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaRomCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaRomByFeedbackRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaRomRepository;
import io.naraplatform.artcenter.store.drama.DramaRomStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DramaRomCassandraStore implements DramaRomStore {
    //
    @Autowired
    DramaRomRepository dramaRomRepository;
    @Autowired
    DramaRomByFeedbackRepository dramaRomByFeedbackRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DramaRom[%s] to retrieve.";

    @Override
    public void create(DramaRom drama) {
        //
        dramaRomRepository.insert(new DramaRomCmo(drama));
        dramaRomByFeedbackRepository.insert(new DramaRomByFeedbackCmo(drama));
    }

    @Override
    public DramaRom retrieve(String dramaId, String langCode) {
        //
        Optional<DramaRomCmo> dramaRomCmo = dramaRomRepository.findByIdAndLangCode(dramaId, langCode);
        if (!dramaRomCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaId));
        }

        return dramaRomCmo.get().toDomain();
    }

    @Override
    public List<DramaRom> retrieveDramasByFeedbackId(String feedbackId, String langCode) {
        //
        List<DramaRomByFeedbackCmo> dramaRomByFeedbackCmos = dramaRomByFeedbackRepository.findAllByFeedbackIdAndLangCode(feedbackId, langCode);
        return dramaRomByFeedbackCmos
            .stream()
            .map(DramaRomByFeedbackCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(DramaRom drama) {
        //
        dramaRomRepository.save(new DramaRomCmo(drama));
        dramaRomByFeedbackRepository.save(new DramaRomByFeedbackCmo(drama));
    }

    @Override
    public void delete(String dramaId) {
        //
        List<DramaRomCmo> dramaRomCmos = dramaRomRepository.findAllById(dramaId);

        dramaRomCmos.stream().forEach(dramaRom -> dramaRomRepository.delete(dramaRom));
        dramaRomCmos.stream().map(cmo -> cmo.toDomain()).forEach(dramaRom -> dramaRomByFeedbackRepository.delete(new DramaRomByFeedbackCmo(dramaRom)));
    }

}
