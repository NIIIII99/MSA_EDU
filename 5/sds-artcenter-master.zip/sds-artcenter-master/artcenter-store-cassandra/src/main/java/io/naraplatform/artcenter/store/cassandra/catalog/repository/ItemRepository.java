package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ItemRepository extends CassandraRepository<ItemCmo, String> {
    //
    Optional<ItemCmo> findByDramaVersionId(String dramaVersionId);
    List<ItemCmo> findAllByCatalogIdAndCategoryId(String catalogId, String categoryId, Pageable pageable);
}
