package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaTicketByDramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface DramaTicketByDramaRepository extends CassandraRepository<DramaTicketByDramaCmo, String> {
    //
    Optional<DramaTicketByDramaCmo> findByDramaId(String dramaId);
}
