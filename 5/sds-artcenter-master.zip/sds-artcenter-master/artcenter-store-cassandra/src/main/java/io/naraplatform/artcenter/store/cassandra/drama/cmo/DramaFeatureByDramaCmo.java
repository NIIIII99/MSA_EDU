package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.List;

@Table("drama_feature_by_drama")
@Getter
@Setter
@NoArgsConstructor
public class DramaFeatureByDramaCmo implements JsonSerializable {

    @PrimaryKeyColumn(name = "dramaId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String dramaId;
    @PrimaryKeyColumn(name = "index", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private int index;

    private String id;
    private String defaultLang;
    private String namesJson;
    private String descriptionsJson;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;

    public DramaFeatureByDramaCmo(DramaFeature dramaFeature) {
        //
        BeanUtils.copyProperties(dramaFeature, this);
        this.namesJson = dramaFeature.getNames().toJson();
        this.descriptionsJson = dramaFeature.getDescriptions().toJson();
    }

    public DramaFeature toDomain() {
        //
        DramaFeature dramaFeature = new DramaFeature(this.id);
        BeanUtils.copyProperties(this, dramaFeature);
        dramaFeature.setNames(LangStrings.fromJson(this.namesJson));
        dramaFeature.setDescriptions(LangStrings.fromJson(this.descriptionsJson));

        return dramaFeature;
    }
}
