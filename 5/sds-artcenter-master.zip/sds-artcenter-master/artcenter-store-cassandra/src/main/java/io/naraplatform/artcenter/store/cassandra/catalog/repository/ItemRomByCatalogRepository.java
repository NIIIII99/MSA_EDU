package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomByCatalogCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ItemRomByCatalogRepository extends CassandraRepository<ItemRomByCatalogCmo, String> {
    //
    List<ItemRomByCatalogCmo> findAllByCatalogIdAndCategoryIdAndLangCode(String catalogId, String categoryId, String langCode, Pageable pageable);
    List<ItemRomByCatalogCmo> findAllByCatalogIdAndLangCode(String catalogId, String langCode, Pageable pageable);

    //void deleteByCatalogIdAndCategoryIdAndLangCodeAndId(String catalogId, String categoryId, String langCode, String itemId);
}
