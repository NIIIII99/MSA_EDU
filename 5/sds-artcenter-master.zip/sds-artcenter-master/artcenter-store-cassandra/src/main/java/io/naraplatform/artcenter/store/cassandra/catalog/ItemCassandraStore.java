package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemCmo;
import io.naraplatform.artcenter.store.cassandra.catalog.repository.ItemRepository;
import io.naraplatform.artcenter.store.catalog.ItemDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class ItemCassandraStore implements ItemDomainStore {

    @Autowired
    ItemRepository itemRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No item[%s] to retrieve.";

    @Override
    public void create(Item item) {
        //
        ItemCmo itemCmo = new ItemCmo(item);
        itemRepository.insert(itemCmo);
    }

    @Override
    public Item retrieve(String itemId) {
        //
        Optional<ItemCmo> itemCmo = itemRepository.findById(itemId);
        if (!itemCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, itemId));
        }

        return itemCmo.get().toDomain();
    }

    @Override
    public Item retrieveByDramaVersion(String dramaVersionId) {
        //
        Optional<ItemCmo> itemCmo = itemRepository.findByDramaVersionId(dramaVersionId);
        if (!itemCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaVersionId));
        }

        return itemCmo.get().toDomain();
    }

    @Override
    public List<Item> retrieveByCatalogAndCategory(String catalogId, String categoryId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ItemCmo> itemCmos = itemRepository.findAllByCatalogIdAndCategoryId(catalogId, categoryId, pageable);
        return itemCmos.stream()
            .map(cmo -> cmo.toDomain())
            .collect(Collectors.toList());
    }

    @Override
    public void update(Item item) {
        //
        itemRepository.save(new ItemCmo(item));
    }

}
