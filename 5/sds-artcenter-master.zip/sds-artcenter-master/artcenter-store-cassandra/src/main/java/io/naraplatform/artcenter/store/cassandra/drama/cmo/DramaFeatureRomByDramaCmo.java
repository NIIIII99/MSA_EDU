package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.List;

@Table("drama_feature_rom_by_drama")
@Getter
@Setter
@NoArgsConstructor
public class DramaFeatureRomByDramaCmo implements JsonSerializable{
    //
    @PrimaryKeyColumn(name = "dramaId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String dramaId;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "index", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private int index;

    private String id;
    private String defaultLang;
    private String name;
    private String description;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;


    public DramaFeatureRomByDramaCmo(DramaFeatureRom dramaFeatureRom){
        //
        BeanUtils.copyProperties(dramaFeatureRom, this);
    }

    public DramaFeatureRom toDomain(){
        //
        DramaFeatureRom dramaFeatureRom = new DramaFeatureRom();
        BeanUtils.copyProperties(this, dramaFeatureRom);
        return dramaFeatureRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaFeatureRomByDramaCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaFeatureRomByDramaCmo.class);
    }

    public static DramaFeatureRomByDramaCmo sample() {
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        return new DramaFeatureRomByDramaCmo(dramaFeatureRom);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }

}
