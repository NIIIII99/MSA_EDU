package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.CategoryCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface CategoryRepository extends CassandraRepository<CategoryCmo, String> {

    List<CategoryCmo> findAllByCatalogId(String catalogId);

}
