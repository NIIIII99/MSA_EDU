package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface DramaRepository extends CassandraRepository<DramaCmo, String> {
}
