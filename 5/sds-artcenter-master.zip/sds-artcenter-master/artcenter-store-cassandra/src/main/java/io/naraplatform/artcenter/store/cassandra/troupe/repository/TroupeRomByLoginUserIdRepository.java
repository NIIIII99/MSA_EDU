package io.naraplatform.artcenter.store.cassandra.troupe.repository;

import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeRomByLoginUserIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TroupeRomByLoginUserIdRepository extends CassandraRepository<TroupeRomByLoginUserIdCmo, String> {
    //
	Optional<TroupeRomByLoginUserIdCmo> findByLoginUserId(String loginUserId);

}
