package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionByDramaCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaVersionByDramaRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaVersionRepository;
import io.naraplatform.artcenter.store.drama.DramaVersionDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class DramaVersionCassandraStore implements DramaVersionDomainStore {
    //
    @Autowired
    DramaVersionRepository dramaVersionRepository;
    @Autowired
    DramaVersionByDramaRepository dramaVersionByDramaRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DramaVersion[%s] to retrieve.";

    @Override
    public void create(DramaVersion dramaVersion) {
        //
        dramaVersionRepository.insert(new DramaVersionCmo(dramaVersion));
        dramaVersionByDramaRepository.insert(new DramaVersionByDramaCmo(dramaVersion));
    }

    @Override
    public DramaVersion retrieve(String versionId) {
        //
        Optional<DramaVersionCmo> dramaVersionCmo = dramaVersionRepository.findById(versionId);
        if (!dramaVersionCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, versionId));
        }

        return dramaVersionCmo.get().toDomain();
    }

    @Override
    public DramaVersion retrieve(String dramaId, String versionName) {
        //
        Optional<DramaVersionByDramaCmo> dramaVersionByDramaCmo = dramaVersionByDramaRepository.findByDramaIdAndVersionName(dramaId, versionName);
        if (!dramaVersionByDramaCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaId + "/" + versionName));
        }

        return dramaVersionByDramaCmo.get().toDomain();
    }

    @Override
    public List<DramaVersion> retrieveAllByDramaId(String dramaId) {
        //
        Collection<DramaVersionByDramaCmo> dramaVersionByDramaCmos = dramaVersionByDramaRepository.findAllByDramaId(dramaId);
        
        return dramaVersionByDramaCmos
            .stream()
            .map(DramaVersionByDramaCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<DramaVersion> retrieveAllByDramaId(String dramaId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        Slice<DramaVersionByDramaCmo> dramaVersionByDramaCmos = dramaVersionByDramaRepository.findAllByDramaId(dramaId, pageable);

        return dramaVersionByDramaCmos
            .stream()
            .map(cmo -> cmo.toDomain())
            .collect(Collectors.toList());
    }

    @Override
    public void update(DramaVersion dramaVersion) {
        //
        dramaVersionRepository.save(new DramaVersionCmo(dramaVersion));
        dramaVersionByDramaRepository.save(new DramaVersionByDramaCmo(dramaVersion));
    }

    @Override
    public void delete(String dramaVersionId) {
        //
        Optional<DramaVersionCmo> dramaVersionCmo = dramaVersionRepository.findById(dramaVersionId);

        if (dramaVersionCmo.isPresent()) {
            DramaVersion dramaVersion = dramaVersionCmo.get().toDomain();
            dramaVersionRepository.delete(dramaVersionCmo.get());
            dramaVersionByDramaRepository.delete(new DramaVersionByDramaCmo(dramaVersion));
        }
    }

}
