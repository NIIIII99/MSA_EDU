package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaVersionCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface DramaVersionRepository extends CassandraRepository<DramaVersionCmo, String> {
}
