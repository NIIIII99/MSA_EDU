package io.naraplatform.artcenter.store.cassandra.drama.repository;

import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaFeatureByDramaCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface DramaFeatureByDramaRepository extends CassandraRepository<DramaFeatureByDramaCmo, String> {
    //
    List<DramaFeatureByDramaCmo> findAllByDramaId(String dramaId);
}
