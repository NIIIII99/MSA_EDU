package io.naraplatform.artcenter.store.cassandra.catalog.cmo;


import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("catalog")
@Getter
@Setter
@NoArgsConstructor
public class CatalogCmo implements JsonSerializable{
    //
    @PrimaryKey
    private String id;

    private String nationJson;
    private String titlesJson;
    private String memosJson;
    private boolean global;             // local/global

    public CatalogCmo(Catalog catalog){
        //

        BeanUtils.copyProperties(catalog,this);

        this.nationJson = catalog.getNation().toJson();
        this.titlesJson = catalog.getTitles().toJson();
        this.memosJson = catalog.getMemos().toJson();
    }

    public Catalog toDomain(){
        //
        Catalog catalog = new Catalog(this.id);

        BeanUtils.copyProperties(this,catalog);
        catalog.setNation(IdLangName.fromJson(this.nationJson));
        catalog.setTitles(LangStrings.fromJson(this.titlesJson));
        catalog.setMemos(LangStrings.fromJson(this.memosJson));

        return catalog;
    }

    public String toString() {
        //
        return toJson();
    }

    public static CatalogCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CatalogCmo.class);
    }

    public static CatalogCmo sample() {
        //
        return new CatalogCmo(Catalog.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
