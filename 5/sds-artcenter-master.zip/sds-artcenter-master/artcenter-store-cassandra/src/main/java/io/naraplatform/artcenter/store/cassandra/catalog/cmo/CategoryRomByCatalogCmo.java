package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("category_rom_by_catalog")
@Getter
@Setter
@NoArgsConstructor
public class CategoryRomByCatalogCmo implements JsonSerializable{
    //
    @PrimaryKeyColumn(name = "catalogId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String catalogId;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String id;

    private String name;
    private String memo;

    public CategoryRomByCatalogCmo(CategoryRom categoryRom){
        //
        BeanUtils.copyProperties(categoryRom, this);
    }

    public CategoryRom toDomain(){
        //
        CategoryRom categoryRom = new CategoryRom(this.id);
        BeanUtils.copyProperties(this, categoryRom);

        return categoryRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static CategoryRomByCatalogCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CategoryRomByCatalogCmo.class);
    }

    public static CategoryRomByCatalogCmo sample() {
        //
        return new CategoryRomByCatalogCmo(CategoryRom.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
