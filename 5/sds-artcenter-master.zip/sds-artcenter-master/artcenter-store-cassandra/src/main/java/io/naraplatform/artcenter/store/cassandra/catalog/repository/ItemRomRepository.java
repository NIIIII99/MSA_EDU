package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;
import java.util.Optional;

public interface ItemRomRepository extends CassandraRepository<ItemRomCmo, String> {
    //
    List<ItemRomCmo> findAllById(String id);
    Optional<ItemRomCmo> findByIdAndLangCode(String id, String langCode);
    void deleteByIdAndLangCode(String id, String langCode);
}
