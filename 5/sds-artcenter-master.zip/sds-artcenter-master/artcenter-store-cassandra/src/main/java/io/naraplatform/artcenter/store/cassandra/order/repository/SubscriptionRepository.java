package io.naraplatform.artcenter.store.cassandra.order.repository;

import io.naraplatform.artcenter.store.cassandra.order.cmo.SubscriptionCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface SubscriptionRepository extends CassandraRepository<SubscriptionCmo, String> {
    //
    Optional<SubscriptionCmo> findByIdAndLangCode(String subcriptionId, String langCode);
}
