package io.naraplatform.artcenter.store.cassandra.order.repository;

import io.naraplatform.artcenter.store.cassandra.order.cmo.SubscriptionByTeamCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface SubscriptionByTeamRepository extends CassandraRepository<SubscriptionByTeamCmo, String> {
    //
    List<SubscriptionByTeamCmo> findAllByTeamId(String teamId);
}
