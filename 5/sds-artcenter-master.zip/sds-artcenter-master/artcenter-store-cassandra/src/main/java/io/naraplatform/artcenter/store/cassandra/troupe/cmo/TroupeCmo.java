package io.naraplatform.artcenter.store.cassandra.troupe.cmo;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.LoginUserInfo;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("troupe")
@Getter
@Setter
@NoArgsConstructor
public class TroupeCmo implements JsonSerializable {
    //
	@PrimaryKey
	private String id;
	
	private String nameJson;
	private String contactJson;
    private String email;
    private String loginUserId;
    private String phone;
	private String loginUserInfoJson;
    private String homeUrl;
    private String supportUrl;
    private boolean personal;
    private Long time;
    
    public TroupeCmo (Troupe troupe) {
    	//
        BeanUtils.copyProperties(troupe, this);
        this.nameJson = troupe.getNames().toJson();
        this.email = troupe.getContact().getEmail();
        this.phone = troupe.getContact().getPhone();
        this.loginUserId = troupe.getLoginUserInfo().getLoginId();
        this.contactJson = troupe.getContact().toJson();
        this.loginUserInfoJson = troupe.getLoginUserInfo().toJson();
    }
    
    @SuppressWarnings("unchecked")
	public Troupe toDomain() {
    	//
        Troupe troupe = new Troupe(this.id);
        BeanUtils.copyProperties(this, troupe);
        troupe.setNames(LangStrings.fromJson(nameJson));
        troupe.setContact(Contact.fromJson(contactJson));
        troupe.setLoginUserInfo(LoginUserInfo.fromJson(loginUserInfoJson));

    	return troupe;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TroupeCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TroupeCmo.class);
    }

    public static TroupeCmo sample() {
        //
        return new TroupeCmo(Troupe.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
