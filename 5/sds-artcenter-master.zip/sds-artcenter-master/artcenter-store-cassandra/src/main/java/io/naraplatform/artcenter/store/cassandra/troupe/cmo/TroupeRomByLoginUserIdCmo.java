package io.naraplatform.artcenter.store.cassandra.troupe.cmo;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("troupe_rom_by_loginuserid")
@Getter
@Setter
@ToString
@NoArgsConstructor
public class TroupeRomByLoginUserIdCmo {

    @PrimaryKeyColumn(name = "loginUserId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String loginUserId;
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
	private String id;
	private String json;

	public TroupeRomByLoginUserIdCmo(Troupe troupe) {
	    //
        BeanUtils.copyProperties(troupe, this);

        this.loginUserId = troupe.getLoginUserInfo().getLoginId();
        this.json = JsonUtil.toJson(troupe);
    }

    public Troupe toDomain(){
        //
        return Troupe.fromJson(this.json);
    }

}
