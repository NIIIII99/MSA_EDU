package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaTicketByDramaCmo;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaTicketCmo;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaTicketByDramaRepository;
import io.naraplatform.artcenter.store.cassandra.drama.repository.DramaTicketRepository;
import io.naraplatform.artcenter.store.drama.DramaTicketDomainStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.NoSuchElementException;
import java.util.Optional;

@Repository
public class DramaTicketCassandraStore implements DramaTicketDomainStore {
    //
    @Autowired
    DramaTicketRepository dramaTicketRepository;
    @Autowired
    DramaTicketByDramaRepository dramaTicketByDramaRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DramaTicket[%s] to retrieve.";
    private static final String NO_SUCH_ELEMENT_BYDRAMA_MESSAGE = "No DramaTicket[drama: %s] to retrieve.";

    @Override
    public void create(DramaTicket dramaTicket) {
        //
        dramaTicketRepository.insert(new DramaTicketCmo(dramaTicket));
        dramaTicketByDramaRepository.insert(new DramaTicketByDramaCmo(dramaTicket));
    }

    @Override
    public DramaTicket retrieve(String dramaTicketId) {
        //
        Optional<DramaTicketCmo> dramaTicketCmo = dramaTicketRepository.findById(dramaTicketId);
        if (!dramaTicketCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, dramaTicketId));
        }

        return dramaTicketCmo.get().toDomain();
    }

    @Override
    public DramaTicket retrieveByDrama(String dramaId) {
        //
        Optional<DramaTicketByDramaCmo> dramaTicketByDramaCmo = dramaTicketByDramaRepository.findByDramaId(dramaId);
        if (!dramaTicketByDramaCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_BYDRAMA_MESSAGE, dramaId));
        }

        return dramaTicketByDramaCmo.get().toDomain();
    }
}
