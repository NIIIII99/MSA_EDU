package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")

@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaFeatureCassandraStoreTest.class })
public class DramaRomCassandraStoreTest {
    //
    @Autowired
    DramaRomCassandraStore dramaRomCassandraStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate(){
        //
        DramaRom dramaRom = DramaRom.sample();
        dramaRomCassandraStore.create(dramaRom);
        DramaRom testDramaRom = dramaRomCassandraStore.retrieve(dramaRom.getDramaId(), dramaRom.getLangCode());

        Assert.assertNotNull(testDramaRom);
    }

    @Test
    public void testRetrieve(){
        //
        DramaRom dramaRom = DramaRom.sample();
        dramaRomCassandraStore.create(dramaRom);
        DramaRom testDramaRom = dramaRomCassandraStore.retrieve(dramaRom.getDramaId(), dramaRom.getLangCode());

        Assert.assertNotNull(testDramaRom);
    }

    @Test
    public void testRetrieveAllByFeedbackId(){
        //
        DramaRom dramaRom = DramaRom.sample();
        dramaRomCassandraStore.create(dramaRom);
        List<DramaRom> testDramaRom = dramaRomCassandraStore.retrieveDramasByFeedbackId(dramaRom.getFeedbackId(),dramaRom.getLangCode());

        Assert.assertNotNull(testDramaRom.get(0));
    }

    @Test
    public void testUpdate(){
        //
        DramaRom dramaRom = DramaRom.sample();
        dramaRomCassandraStore.create(dramaRom);
        String testDesceiption = dramaRom.getDescription();
        dramaRom.setDescription("test");
        dramaRomCassandraStore.update(dramaRom);
        DramaRom testDramaRom = dramaRomCassandraStore.retrieve(dramaRom.getDramaId(), dramaRom.getLangCode());

        Assert.assertNotSame(testDramaRom.getDescription(), testDesceiption);

    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        DramaRom dramaRom = DramaRom.sample();
        Drama drama = Drama.sample();
        dramaRomCassandraStore.create(new DramaRom(dramaRom.getLangCode(),drama));
        dramaRomCassandraStore.delete(drama.getId());
        dramaRomCassandraStore.retrieve(drama.getId(), dramaRom.getLangCode());

    }
}
