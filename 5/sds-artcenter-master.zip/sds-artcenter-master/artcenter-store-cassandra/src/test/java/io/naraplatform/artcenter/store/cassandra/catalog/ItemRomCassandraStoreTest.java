package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.SalesSummary;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.cassandra.drama.DramaCassandraStoreTest;
import io.naraplatform.artcenter.store.catalog.ItemRomStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/catalog.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaCassandraStoreTest.class })
public class ItemRomCassandraStoreTest {
    //
    @Autowired
    ItemRomStore itemReadStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        ItemRom itemRom = ItemRom.sample();
        itemRom.setSalesSummary(SalesSummary.sample());
        itemReadStore.create(itemRom);
        List<ItemRom> testItems = itemReadStore.retrieve(itemRom.getId());
        Assert.assertTrue(testItems.size() > 0);
    }

    @Test
    public void testRetrieveByCategory(){
        //
        List<ItemRom> testItems = itemReadStore.retrieve("86334e6c-f270-4171-85d3-a580552c4c12", "71b9418e-b7d0-4cb1-a219-71168e9b0e60", "en", 0, 1);
        Assert.assertFalse(testItems.isEmpty());
    }

    @Test
    public void testRetrieveByCatalogId(){
        //
        List<ItemRom> testItems = itemReadStore.retrieve("86334e6c-f270-4171-85d3-a580552c4c12", "en", 0, 1);
        Assert.assertFalse(testItems.isEmpty());
    }

    @Test
    public void testRetrieve(){
        //
        List<ItemRom> testItems = itemReadStore.retrieve("b1a51689-00a6-4295-a1f5-81b61c3574b7");
        Assert.assertTrue(testItems.size() > 0);
    }

    @Test
    public void testRetrieveBySubscriptionCount(){
        //
        List<ItemRom> testItems = itemReadStore.retrieveBySubscriptionCount("86334e6c-f270-4171-85d3-a580552c4c12", "en", 0, 1);
        Assert.assertFalse(testItems.isEmpty());
    }

    @Test
    public void testRetrieveBySalesAmount(){
        //
        List<ItemRom> testItems = itemReadStore.retrieveBySalesAmount("86334e6c-f270-4171-85d3-a580552c4c12", "en", 0, 1);
        Assert.assertFalse(testItems.isEmpty());
    }

    @Test
    public void testRetrieveByTroupe() {
        //
        List<ItemRom> testItems = itemReadStore.retrieveByTroupe("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0", "en", 0, 10);
    }

    @Test
    public void testDelete() {
        //
        ItemRom itemRom = ItemRom.sample();
        itemRom.setSalesSummary(SalesSummary.sample());
        itemReadStore.create(itemRom);

        itemReadStore.deleteByDramaVersion(itemRom.getDramaVersion().getId());

        String catalogId = itemRom.getCatalogId();
        String itemId = itemRom.getId();
        String categoryId = itemRom.getCategoryId();
        String langCode = itemRom.getLangCode();
        String troupeId = itemRom.getTroupe().getId();

        List<ItemRom> items = itemReadStore.retrieve(catalogId, categoryId, langCode, 0, 10);
        Assert.assertEquals(0, items.size());

        items = itemReadStore.retrieveByTroupe(troupeId, langCode,0, 10);
        Assert.assertEquals(0, items.size());

        try {
            itemReadStore.retrieve(itemId, langCode);
            Assert.fail();
        } catch (NoSuchElementException e) {
        }
    }

}
