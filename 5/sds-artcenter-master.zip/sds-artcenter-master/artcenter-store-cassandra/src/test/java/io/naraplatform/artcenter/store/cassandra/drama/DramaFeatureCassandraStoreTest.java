package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.drama.DramaFeatureDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
		CassandraUnitDependencyInjectionTestExecutionListener.class,
		DependencyInjectionTestExecutionListener.class}
		)
@ContextConfiguration(classes = { CassandraConfig.class,
		DramaFeatureCassandraStoreTest.class })
public class DramaFeatureCassandraStoreTest {

	@Autowired
    DramaFeatureDomainStore dramaFeatureDomainStore;

	@BeforeClass
	public static void beforeClass() {
	}
	
	@Before
	public void before() {
	}

	@Test
    public void testCreate(){
        //
        DramaFeature dramaFeature = DramaFeature.sample();
        dramaFeatureDomainStore.create(dramaFeature);
        DramaFeature testDramaFeature = dramaFeatureDomainStore.retrieve(dramaFeature.getId());
        Assert.assertNotNull(testDramaFeature);
    }

    @Test
    public void testRetrieve(){
        //
        DramaFeature dramaFeature = DramaFeature.sample();
        dramaFeatureDomainStore.create(dramaFeature);
        DramaFeature testDramaFeature = dramaFeatureDomainStore.retrieve(dramaFeature.getId());
        Assert.assertNotNull(testDramaFeature);
    }

    @Test
    public void testRetrieveAllByDramaId(){
        //
        DramaFeature dramaFeature = DramaFeature.sample();
        dramaFeatureDomainStore.create(dramaFeature);
        List<DramaFeature> testDramaFeature = dramaFeatureDomainStore.retrieveAllByDramaId(dramaFeature.getDramaId());
        Assert.assertNotNull( testDramaFeature.get(0));
    }

    @Test
    public void testUpdate(){
        //
        DramaFeature dramaFeature = DramaFeature.sample();
        dramaFeatureDomainStore.create(dramaFeature);
        int testIndex = dramaFeature.getIndex();
        dramaFeature.setIndex(7209);
        dramaFeatureDomainStore.update(dramaFeature);
        Assert.assertNotSame(testIndex, dramaFeature.getIndex());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        DramaFeature dramaFeature = DramaFeature.sample();
        dramaFeatureDomainStore.create(dramaFeature);
        dramaFeatureDomainStore.delete(dramaFeature.getId());
        dramaFeatureDomainStore.retrieve(dramaFeature.getId());
    }
    
}
