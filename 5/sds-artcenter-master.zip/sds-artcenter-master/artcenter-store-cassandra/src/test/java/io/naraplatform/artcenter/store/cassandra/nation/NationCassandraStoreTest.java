package io.naraplatform.artcenter.store.cassandra.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.cassandra.drama.DramaFeatureCassandraStoreTest;
import io.naraplatform.artcenter.store.nation.NationDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/nation.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaFeatureCassandraStoreTest.class })
public class NationCassandraStoreTest {

    @Autowired
    NationDomainStore nationDomainStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        Nation nation = Nation.sample();
        nationDomainStore.create(nation);

        Nation foundNation = nationDomainStore.retrieve(nation.getId());
        Assert.assertNotNull(foundNation);
    }

    @Test
    public void testRetrieve() {
        //
        Nation foundNation = nationDomainStore.retrieve("569fd95b-19a1-47f7-a5e8-4f15b78f023e");
        Assert.assertNotNull(foundNation);
    }

    @Test
    public void update() {
        //
        Nation nation = Nation.sample();
        nation.setVersion((long) 1110);
        nationDomainStore.update(nation);
        Nation compareNation = nationDomainStore.retrieve("569fd95b-19a1-47f7-a5e8-4f15b78f023e");

        Assert.assertNotEquals(nation.getVersion(), compareNation.getVersion());
    }

    @Test(expected = NoSuchElementException.class)
    public void delete(){
        //
        String id = "569fd95b-19a1-47f7-a5e8-4f15b78f023e";
        nationDomainStore.delete(id);
        nationDomainStore.retrieve(id);
    }

    @Test
    public void retrieveAll(){
        //
        List<Nation> testNations = nationDomainStore.retrieveAll();
        Assert.assertFalse(testNations.isEmpty());
    }

}
