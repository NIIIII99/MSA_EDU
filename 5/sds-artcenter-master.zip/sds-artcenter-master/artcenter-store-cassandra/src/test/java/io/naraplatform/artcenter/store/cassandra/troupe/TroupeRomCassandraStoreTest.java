package io.naraplatform.artcenter.store.cassandra.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/troupe.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    TroupeCassandraStoreTest.class })
public class TroupeRomCassandraStoreTest {

	@Autowired
    TroupeRomCassandraStore troupeReadCassandraStore;

	@Test
	public void testReadById() {
		String json = troupeReadCassandraStore.retrieveJson("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
		Assert.assertTrue(json.length() > 100);
	}
	
	//@Test
	public void testReadByEmail() {
		String json = troupeReadCassandraStore.retrieveJsonByEmail("jhone@company.com");
		Assert.assertTrue(json.length() > 100);
	}
	
	//@Test
	public void testReadByLoginUserId() {
		String json = troupeReadCassandraStore.retrieveJsonByLoginUserId("steve@google.com");
		Assert.assertTrue(json.length() > 100);
	}
	
	//@Test
	public void testReads() {
		List<String> jsons = troupeReadCassandraStore.retrieveAllJsons(0, 2);
		for (String json: jsons) {
			System.out.println(json);
		}
		Assert.assertTrue(jsons.size() > 0);
	}

    @Test
    public void testCreate(){
        //
        Troupe troupe = Troupe.sample();
        troupeReadCassandraStore.create(troupe);
        String json = troupeReadCassandraStore.retrieveJson(troupe.getId());
        Assert.assertNotNull(json);
    }

    @Test
    public void testRetrieveJson(){
        //
        String json = troupeReadCassandraStore.retrieveJson("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
        Assert.assertNotNull(json);
    }

    @Test
    public void testRetrieveJsonByEmail(){
        //
        String json = troupeReadCassandraStore.retrieveJsonByEmail("jhone@company.com");
        Assert.assertNotNull(json);
    }

    @Test
    public void testRetrieveJsonByLoginUserId(){
        //
        String json = troupeReadCassandraStore.retrieveJsonByLoginUserId("steve@google.com");
        Assert.assertNotNull(json);
    }

    @Test
    public void testRetrieveAllJson(){
        //
        List<String> jsons = troupeReadCassandraStore.retrieveAllJsons(0, 1);
        Assert.assertFalse(jsons.isEmpty());
    }

    @Test
    public void testUpdate(){
        //
        //String json = troupeRomCassandraStore.retrieveJson("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
        Troupe troupe = Troupe.sample();
        troupeReadCassandraStore.create(troupe);
        String originJson = troupeReadCassandraStore.retrieveJson(troupe.getId());
        troupe.setHomeUrl("test");
        troupeReadCassandraStore.update(troupe);
        String updatedJson = troupeReadCassandraStore.retrieveJson(troupe.getId());

        Assert.assertNotSame(originJson, updatedJson);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        troupeReadCassandraStore.delete("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
        troupeReadCassandraStore.retrieveJson("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
    }

    @Test
    public void ExistsByEmail(){
        //
        boolean isExist = troupeReadCassandraStore.existsByEmail("jhone@company.com");
        Assert.assertTrue(isExist);
    }
}
