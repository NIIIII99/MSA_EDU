package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.drama.DramaFeatureRomStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaFeatureCassandraStoreTest.class })
public class DramaFeatureRomCassandraStoreTest {
    //
    @Autowired
    DramaFeatureRomStore dramaFeatureReadStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate(){
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        dramaFeatureReadStore.create(dramaFeatureRom);
        DramaFeatureRom testDramaFeatureRom =  dramaFeatureReadStore.retrieve(dramaFeatureRom.getId(), dramaFeatureRom.getLangCode());
        Assert.assertNotNull(testDramaFeatureRom);
    }

    @Test
    public void testRetrieve(){
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        dramaFeatureReadStore.create(dramaFeatureRom);
        DramaFeatureRom testDramaFeatureRom =  dramaFeatureReadStore.retrieve(dramaFeatureRom.getId(), dramaFeatureRom.getLangCode());
        Assert.assertNotNull(testDramaFeatureRom);
    }
    @Test
    public void testRetrieveAllByDramaId(){
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        dramaFeatureReadStore.create(dramaFeatureRom);
        List<DramaFeatureRom> testDramaFeatureRoms = dramaFeatureReadStore.retrieveAllByDramaId(dramaFeatureRom.getDramaId(),dramaFeatureRom.getLangCode());
        Assert.assertNotNull( testDramaFeatureRoms.get(0));
    }

    @Test
    public void testUpdate(){
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        dramaFeatureReadStore.create(dramaFeatureRom);
        int testIndex = dramaFeatureRom.getIndex();
        dramaFeatureRom.setIndex(7209);
        dramaFeatureReadStore.update(dramaFeatureRom);

        Assert.assertNotSame(testIndex, dramaFeatureRom.getIndex());

    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        DramaFeatureRom dramaFeatureRom = DramaFeatureRom.sample();
        dramaFeatureReadStore.create(dramaFeatureRom);

        DramaFeatureRom test = dramaFeatureReadStore.retrieve(dramaFeatureRom.getId(), "kr");
        Assert.assertNull(test);
    }

}
