package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.catalog.CategoryDomainStore;
import io.naraplatform.share.domain.lang.LangStrings;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/catalog.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    CategoryCassandraStoreTest.class })
public class CategoryCassandraStoreTest {
    //
    @Autowired
    CategoryDomainStore categoryDomainStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate(){
        //
        Category category = Category.sample();
        categoryDomainStore.create(category);
        Category testCategory = categoryDomainStore.retrieve(category.getId());
        Assert.assertNotNull(testCategory);
    }

    @Test
    public void testRetrieve(){
        //
        Category category = Category.sample();
        categoryDomainStore.create(category);
        Category testCategory = categoryDomainStore.retrieve(category.getId());
        Assert.assertNotNull(testCategory);
    }

    @Test
    public void testUpdate(){
        //
        Category compareCategory = categoryDomainStore.retrieve("71b9418e-b7d0-4cb1-a219-71168e9b0e60");
        compareCategory.setNames(LangStrings.newString("ko","sanghyunTest"));
        categoryDomainStore.update(compareCategory);

        Assert.assertSame("ko", compareCategory.getNames().getLangs().get(0));
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        Category category = Category.sample();

        categoryDomainStore.create(category);
        categoryDomainStore.delete(category.getCatalogId());
        categoryDomainStore.retrieve(category.getCatalogId());
    }

    @Test
    public void testRetrieveAllByCatalogId(){
        //
        Category category = Category.sample();
        categoryDomainStore.create(category);
        List<Category> testCategorys = categoryDomainStore.retrieveAllByCatalogId(category.getCatalogId());
        Assert.assertFalse(testCategorys.isEmpty());
    }
}
