package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.drama.DramaDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
		CassandraUnitDependencyInjectionTestExecutionListener.class,
		DependencyInjectionTestExecutionListener.class}
		)
@ContextConfiguration(classes = { CassandraConfig.class,
		DramaCassandraStoreTest.class })
public class DramaCassandraStoreTest {

	@Autowired
    DramaDomainStore dramaDomainStore;

	@BeforeClass
	public static void beforeClass() {
	}
	
	@Before
	public void before() {
	}

	@Test
    public void testCreate(){
        //
        Drama drama = Drama.sample();
        dramaDomainStore.create(drama);

        Drama testDrama = dramaDomainStore.retrieve(drama.getId());
        Assert.assertNotNull(testDrama);
    }

    @Test
    public void testUpdate(){
	    //
        Drama drama = Drama.sample();
        dramaDomainStore.create(drama);
        String IconSample = drama.getBase64Icon();
        drama.setBase64Icon("sample");
        dramaDomainStore.update(drama);

        Drama testDrama = dramaDomainStore.retrieve(drama.getId());

        Assert.assertNotSame(drama, testDrama);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        Drama drama = Drama.sample();
        dramaDomainStore.create(drama);
        dramaDomainStore.delete(drama.getId());
        dramaDomainStore.retrieve(drama.getId());
    }

    @Test
    public void testRetrieve() {
	    //
        Drama drama = Drama.sample();
        dramaDomainStore.create(drama);

        Drama testDrama = dramaDomainStore.retrieve(drama.getId());
        Assert.assertNotNull(testDrama);
    }

    @Test
    public void testRetrieveDramasByTroupe(){
	    //
        List<Drama> testDramas = dramaDomainStore.retrieveDramasByTroupe("1e080039-21d6-4be7-abb8-1f5a2e1f607o", 0,1);
        Assert.assertNotNull(testDramas);
    }

}
