package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.cassandra.drama.DramaCassandraStoreTest;
import io.naraplatform.artcenter.store.catalog.CatalogDomainStore;
import io.naraplatform.artcenter.store.catalog.CategoryDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/catalog.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaCassandraStoreTest.class })
public class CatalogCasssandraStoreTest {
    //
    @Autowired
    CatalogDomainStore catalogDomainStore;
    @Autowired
    CategoryDomainStore categoryDomainStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        Catalog catalog = Catalog.sample();
        catalogDomainStore.create(catalog);
        Catalog foundCatalog = catalogDomainStore.retrieve(catalog.getId());
        Assert.assertNotNull(foundCatalog);
    }

    @Test
    public void testRetrieve(){
        //
        Catalog catalog = Catalog.sample();
        catalogDomainStore.create(catalog);
        Catalog foundCatalog = catalogDomainStore.retrieve(catalog.getId());
        Assert.assertNotNull(foundCatalog);
    }

    @Test
    public void testUpdate(){
        //
        Catalog catalog = Catalog.sample();
        long testVersion = catalog.getVersion();
        catalogDomainStore.create(catalog);

        catalog.setVersion((long)1);
        catalogDomainStore.update(catalog);

        Assert.assertNotEquals(testVersion, (long)catalog.getVersion());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        Catalog catalog = Catalog.sample();

        catalogDomainStore.create(catalog);
        catalogDomainStore.delete(catalog.getId());
        catalogDomainStore.retrieve(catalog.getId());
    }

    @Test
    public void testRetrieveCategory(){
        //
        Category testCateGory = catalogDomainStore.retrieveCategory("71b9418e-b7d0-4cb1-a219-71168e9b0e60");
        Assert.assertNotNull(testCateGory);
    }

    @Test
    public void testRetrieveCategoriesByCatalog(){
        //

        List<Category> testCategorys = catalogDomainStore.retrieveCategoriesByCatalog("86334e6c-f270-4171-85d3-a580552c4c12");

        Assert.assertNotNull(testCategorys.get(0));
    }
}
