package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.drama.DramaVersionDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
		CassandraUnitDependencyInjectionTestExecutionListener.class,
		DependencyInjectionTestExecutionListener.class}
		)
@ContextConfiguration(classes = { CassandraConfig.class,
		DramaVersionCassandraStoreTest.class })
public class DramaVersionCassandraStoreTest {

	@Autowired
    DramaVersionDomainStore dramaVersionDomainStore;

	@BeforeClass
	public static void beforeClass() {
	}
	
	@Before
	public void before() {
	}

    @Test
    public void testRetrieveByPaging() {
	    //
        List<DramaVersion> dramaFeatures = dramaVersionDomainStore.retrieveAllByDramaId("1e080039-21d6-4be7-abb8-1f5a2e1f6079");
        Assert.assertTrue(dramaFeatures.size() == 1);
    }

    @Test
    public void create(){
        DramaVersion dramaVersion = DramaVersion.sample();
        dramaVersionDomainStore.create(dramaVersion);
        DramaVersion testDramaVersion =  dramaVersionDomainStore.retrieve(dramaVersion.getId());
        Assert.assertNotNull(testDramaVersion);
    }

    @Test
    public void retrieve(){
        DramaVersion dramaVersion = DramaVersion.sample();
        dramaVersionDomainStore.create(dramaVersion);
        DramaVersion testDramaVersion =  dramaVersionDomainStore.retrieve(dramaVersion.getId());
        Assert.assertNotNull(dramaVersion);
    }

    @Test
    public void retrieveAllByDramaId(){
        DramaVersion dramaVersion = DramaVersion.sample();
        dramaVersionDomainStore.create(dramaVersion);
        List<DramaVersion> testDramaVersions = dramaVersionDomainStore.retrieveAllByDramaId(dramaVersion.getDramaId());

        Assert.assertNotNull(testDramaVersions.get(0));
    }

    @Test
    public void retrieveAllByDramaIdAndOffset(){
	    //
        List<DramaVersion> testDramaVersions = dramaVersionDomainStore.retrieveAllByDramaId("1e080039-21d6-4be7-abb8-1f5a2e1f6079", 0, 1);
        Assert.assertNotNull(testDramaVersions);
    }

    @Test
    public void update(){
        DramaVersion dramaVersion = DramaVersion.sample();
        dramaVersionDomainStore.create(dramaVersion);
        String testReleaseDate = dramaVersion.getReleaseDate();
        dramaVersion.setReleaseDate("test");
        dramaVersionDomainStore.update(dramaVersion);
        DramaVersion testDramaVersion = dramaVersionDomainStore.retrieve(dramaVersion.getId());

        Assert.assertNotSame(testDramaVersion.getReleaseDate(), testReleaseDate);
    }

    @Test(expected = NoSuchElementException.class)
    public void delete(){
        DramaVersion dramaVersion = DramaVersion.sample();
        dramaVersionDomainStore.create(dramaVersion);
        dramaVersionDomainStore.delete(dramaVersion.getId());
        dramaVersionDomainStore.retrieve(dramaVersion.getId());
    }
    
}
