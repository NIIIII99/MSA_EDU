package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")

@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaVersionRomCassandraStoreTest.class })
public class DramaVersionRomCassandraStoreTest {
    //
    @Autowired
    DramaVersionRomCassandraStore dramaVersionReadCassandraStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        DramaVersionRom dramaVersionRom = DramaVersionRom.sample();
        dramaVersionReadCassandraStore.create(dramaVersionRom);
        DramaVersionRom testDramaVersionRom = dramaVersionReadCassandraStore.retrieve(dramaVersionRom.getId(), dramaVersionRom.getLangCode());

        Assert.assertNotNull(testDramaVersionRom);
    }

    @Test
    public void testRetrieve() {
        //
        DramaVersionRom dramaVersionRom = DramaVersionRom.sample();
        dramaVersionReadCassandraStore.create(dramaVersionRom);
        DramaVersionRom testDramaVersion =  dramaVersionReadCassandraStore.retrieve(dramaVersionRom.getId(), dramaVersionRom.getLangCode());
        Assert.assertNotNull(dramaVersionRom);
    }

    @Test
    public void testRetrieveByLangCode() {
        //
        DramaVersionRom dramaVersionRom = DramaVersionRom.sample();
        dramaVersionReadCassandraStore.create(dramaVersionRom);
        DramaVersionRom testDramaVersionRom = dramaVersionReadCassandraStore.retrieve(dramaVersionRom.getId(), "en");
        Assert.assertNotNull(testDramaVersionRom);
    }

    @Test
    public void testRetrieveAllByDramaId() {
        //
        DramaVersionRom dramaVersionRom = DramaVersionRom.sample();
        dramaVersionReadCassandraStore.create(dramaVersionRom);
        List<DramaVersionRom> dramaVersionRoms = dramaVersionReadCassandraStore.retrieveAllByDramaId(dramaVersionRom.getDramaId(),dramaVersionRom.getLangCode());

        Assert.assertNotNull(dramaVersionRoms.get(0));
    }

    @Test
    public void testUpdate() {
        //
        DramaVersionRom dramaVersionRom = DramaVersionRom.sample();
        dramaVersionReadCassandraStore.create(dramaVersionRom);
        String testReleaseDate = dramaVersionRom.getReleaseDate();
        dramaVersionRom.setReleaseDate("test");
        dramaVersionReadCassandraStore.update(dramaVersionRom);
        DramaVersionRom testDramaVersion = dramaVersionReadCassandraStore.retrieve(dramaVersionRom.getId(), dramaVersionRom.getLangCode());

        Assert.assertNotSame(testDramaVersion.getReleaseDate(), testReleaseDate);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        DramaVersionRom dramaVersionRom = DramaVersionRom.sample();
        DramaVersion dramaVersion = DramaVersion.sample();
        dramaVersionReadCassandraStore.create(new DramaVersionRom(dramaVersionRom.getLangCode(), dramaVersion));
        dramaVersionReadCassandraStore.delete(dramaVersion.getId(),dramaVersionRom.getLangCode());
        dramaVersionReadCassandraStore.retrieve(dramaVersion.getId(), dramaVersionRom.getLangCode());
    }
}
