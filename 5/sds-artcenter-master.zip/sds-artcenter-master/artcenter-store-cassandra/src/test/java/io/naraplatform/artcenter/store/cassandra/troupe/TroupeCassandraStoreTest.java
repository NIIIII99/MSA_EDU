package io.naraplatform.artcenter.store.cassandra.troupe;

import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.troupe.TroupeDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.util.json.JsonUtil;

import java.util.NoSuchElementException;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/troupe.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
		CassandraUnitDependencyInjectionTestExecutionListener.class,
		DependencyInjectionTestExecutionListener.class}
		)
@ContextConfiguration(classes = { CassandraConfig.class,
		TroupeCassandraStoreTest.class })
public class TroupeCassandraStoreTest {

	@Autowired
    TroupeDomainStore troupeDomainStore;

	private Troupe createdTroupe;
	
	@BeforeClass
	public static void beforeClass() {
	    //System.setProperty("java.library.path", "./sigar-libs");
	}
	
	@Before
	public void before() {
	}

	@Test
	public void testCreate() {
		createdTroupe = Troupe.sample();
		String troupeId = createdTroupe.getId();
		System.out.println(JsonUtil.toJson(createdTroupe));
        troupeDomainStore.create(createdTroupe);
		Troupe troupe = troupeDomainStore.retrieve(troupeId);

		assertNotNull(troupe);
	}

	@Test
	public void testRetrieve() {
		//
		Troupe foundTroupe = troupeDomainStore.retrieve("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
		System.out.println(JsonUtil.toJson(foundTroupe));
		assertNotNull(foundTroupe);
	}

	@Test
    public void testUpdate(){
	    //
        Troupe troupe = troupeDomainStore.retrieve("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
        String comparedUrl = troupe.getHomeUrl();
        troupe.setHomeUrl("test");
        troupeDomainStore.update(troupe);
        troupe = troupeDomainStore.retrieve("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
        String updatedHomeUrl = troupe.getHomeUrl();

        Assert.assertNotSame(comparedUrl, updatedHomeUrl);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        troupeDomainStore.delete("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
        troupeDomainStore.retrieve("a8c41205-3c95-46ce-bc78-4fdd1bbaaea0");
    }

}
