package io.naraplatform.artcenter.store.cassandra;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TroupeBootTestApp {

}
