package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.cassandra.drama.DramaCassandraStoreTest;
import io.naraplatform.artcenter.store.catalog.CatalogRomStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/catalog.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaCassandraStoreTest.class })
public class CatalogRomCassandraStoreTest {
    //
    @Autowired
    CatalogRomStore catalogReadStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        CatalogRom catalogRom = CatalogRom.sample();
        catalogReadStore.create(catalogRom);
        CatalogRom testCatalogRom = catalogReadStore.retrieve(catalogRom.getId(), catalogRom.getLangCode());
        Assert.assertNotNull(testCatalogRom);
    }

    @Test
    public void testRetrieve(){
        //
        CatalogRom catalogRom = CatalogRom.sample();
        catalogReadStore.create(catalogRom);
        CatalogRom testCatalogRom = catalogReadStore.retrieve(catalogRom.getId(), catalogRom.getLangCode());
        Assert.assertNotNull(testCatalogRom);
    }

    @Test
    public void testRetrieveAllByNationId(){
        //
        CatalogRom catalogRom = CatalogRom.sample();
        catalogReadStore.create(catalogRom);
        List<CatalogRom> testCatalogRom = catalogReadStore.retrieveAllByNationId(catalogRom.getNationId());
        Assert.assertEquals(testCatalogRom.get(0), catalogRom);
    }

    @Test
    public void testRetrieveAllByLangCode(){
        //
        CatalogRom catalogRom = CatalogRom.sample();
        catalogReadStore.create(catalogRom);
        List<CatalogRom> testCatalogRom = catalogReadStore.retrieveAllByLangCode(catalogRom.getLangCode());
        Assert.assertTrue(testCatalogRom.contains(catalogRom));
    }

    @Test
    public void testUpdate(){
        //
        CatalogRom catalogRom = CatalogRom.sample();
        catalogRom.setMemo("MEMO");
        catalogReadStore.update(catalogRom);
        CatalogRom compareCatalogRom = catalogReadStore.retrieve(catalogRom.getId(), catalogRom.getLangCode());

        Assert.assertEquals(compareCatalogRom.getMemo(), "MEMO");
    }


//    @Test(expected = NoSuchElementException.class)
//    public void testDelete(){
//        //
//        catalogRomStore.delete("103de21d-6429-4613-92bd-9ab9090087ff", "en");
//        catalogRomStore.retrieve("103de21d-6429-4613-92bd-9ab9090087ff","en");
//    }
}
