package io.naraplatform.artcenter.store.cassandra.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.cassandra.drama.cmo.DramaTicketCmo;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/drama.cql")

@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaTicketCassandraStoreTest.class })
public class DramaTicketCassandraStoreTest {

    @Autowired
    DramaTicketCassandraStore dramaTicketCassandraStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        DramaTicket dramaTicket = DramaTicket.sample();
        dramaTicketCassandraStore.create(dramaTicket);

        DramaTicket foundDramaTicket = dramaTicketCassandraStore.retrieve(dramaTicket.getId());

        Assert.assertNotNull(foundDramaTicket);
    }

    @Test
    public void testRetrieve() {
        //
        DramaTicket foundDramaTicket = dramaTicketCassandraStore.retrieve("9c3dabbc-7b89-4cfc-b222-f7dc994566a7");
        Assert.assertNotNull(foundDramaTicket);
    }

    @Test(expected = NoSuchElementException.class)
    public void testRetrieveNotFound() {
        //
        dramaTicketCassandraStore.retrieve("9c3dabbc-7b89-4cfc-b222-f7dc994566a9");
    }
}
