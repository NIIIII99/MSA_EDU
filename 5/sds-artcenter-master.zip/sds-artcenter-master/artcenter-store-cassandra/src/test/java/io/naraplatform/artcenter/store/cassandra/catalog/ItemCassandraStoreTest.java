package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.catalog.ItemDomainStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/catalog.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    CategoryRomCassandraStoreTest.class })
public class ItemCassandraStoreTest {
    @Autowired
    ItemDomainStore itemDomainStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
        //
    }

    @Test
    public void retrieve(){
        //
        Item item = Item.sample();
        Item testItem = itemDomainStore.retrieve("f663fa15-3a62-4a37-9c3b-cbc62b5df623");

        Assert.assertNotNull(testItem);
    }

    //@Test
    //public void retrieveByCatalogAndCategory() {
    //    //
    //    itemDomainStore.retrieveByCatalogAndCategory("86334e6c-f270-4171-85d3-a580552c4c12","c3bc66aa-22d3-417c-860f-be89f16071db",0,1);
    //}
}
