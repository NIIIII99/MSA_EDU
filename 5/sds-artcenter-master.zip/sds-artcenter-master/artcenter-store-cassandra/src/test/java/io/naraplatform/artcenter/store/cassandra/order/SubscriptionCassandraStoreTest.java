package io.naraplatform.artcenter.store.cassandra.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.cassandra.drama.DramaCassandraStoreTest;
import io.naraplatform.artcenter.store.order.SubscriptionDomainStore;
import io.naraplatform.share.domain.IdName;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/subscription.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    DramaCassandraStoreTest.class })
public class SubscriptionCassandraStoreTest {
    //
    @Autowired
    SubscriptionDomainStore subscriptionDomainStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        Subscription subscription = Subscription.sample();
        subscriptionDomainStore.create(subscription);
        Subscription testSubscription = subscriptionDomainStore.retrieve(subscription.getId());
        Assert.assertNotNull(testSubscription);
    }

    @Test
    public void testRetrieveByLangCode(){
        //
        Subscription testSubscription = subscriptionDomainStore.retrieve("048cfdaf-1cb9-486c-a2b6-f80ecfaeasdf", "en");
        Assert.assertNotNull(testSubscription);
    }

    @Test
    public void testRetrieve(){
        //
        Subscription testSubscription = subscriptionDomainStore.retrieve("048cfdaf-1cb9-486c-a2b6-f80ecfaeasdf");
        Assert.assertNotNull(testSubscription);
    }

    @Test
    public void testRetrieveSubscriptionsBySubscriber(){
        //
        Subscription subscription = Subscription.sample();
        subscriptionDomainStore.create(subscription);
        List<Subscription> testSubscriptions = subscriptionDomainStore.retrieveSubscriptionsBySubscriber(subscription.getSubscriber().getId());
        Assert.assertFalse(testSubscriptions.isEmpty());
    }

    @Test
    public void testRetrieveSubscriptionsByTeam(){
        //
        List<Subscription> testSubscriptions = subscriptionDomainStore.retrieveSubscriptionsByTeam("AAA-BBB-CCC");
        Assert.assertFalse(testSubscriptions.isEmpty());
    }

    @Test
    public void testUpdate(){
        //
        Subscription testSubscription = subscriptionDomainStore.retrieve("048cfdaf-1cb9-486c-a2b6-f80ecfaesdfg");
        String comparedLang = testSubscription.getDramaVersion().getName();
        testSubscription.setLangCode("test");
        testSubscription.setDrama(IdName.sample());
        System.out.println("=> " + testSubscription);

        subscriptionDomainStore.update(testSubscription);

        testSubscription = subscriptionDomainStore.retrieve("048cfdaf-1cb9-486c-a2b6-f80ecfaesdfg");
        String updatedLang = testSubscription.getLangCode();

        Assert.assertNotSame(comparedLang, updatedLang);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete(){
        //
        Subscription subscription = Subscription.sample();
        subscriptionDomainStore.create(subscription);
        subscriptionDomainStore.delete(subscription.getId());
        subscriptionDomainStore.retrieve(subscription.getId());
    }
}
