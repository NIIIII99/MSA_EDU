package io.naraplatform.artcenter.store.cassandra.catalog;

import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.artcenter.store.cassandra.CassandraConfig;
import io.naraplatform.artcenter.store.cassandra.TroupeBootTestApp;
import io.naraplatform.artcenter.store.catalog.CategoryRomStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TroupeBootTestApp.class)
@CassandraDataSet(keyspace = "artcenter", value = "cql/catalog.cql")


@EmbeddedCassandra(timeout = 60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = {CassandraConfig.class,
    CategoryRomCassandraStoreTest.class})
public class CategoryRomCassandraStoreTest {
    //
    @Autowired
    CategoryRomStore categoryReadStore;

    @BeforeClass
    public static void beforeClass() {
    }

    @Before
    public void before() {
    }

    @Test
    public void testCreate() {
        //
        CategoryRom categoryRom = CategoryRom.sample();
        categoryReadStore.create(categoryRom);
        List<CategoryRom> testCategoryRoms = categoryReadStore.retrieve(categoryRom.getId());

        Assert.assertTrue(testCategoryRoms.size() > 0);
    }

    @Test
    public void testRetrieve() {
        //
        CategoryRom categoryRom = CategoryRom.sample();
        categoryReadStore.create(categoryRom);
        List<CategoryRom> testCategoryRoms = categoryReadStore.retrieve(categoryRom.getId());

        Assert.assertTrue(testCategoryRoms.size() > 0);
    }

    @Test
    public void testRetrieveWithLangCode() {
        //
        CategoryRom categoryRom = CategoryRom.sample();
        categoryReadStore.create(categoryRom);
        CategoryRom testCategoryRom = categoryReadStore.retrieve(categoryRom.getId(), categoryRom.getLangCode());

        Assert.assertNotNull(testCategoryRom);
    }

    @Test
    public void testRetrieveAllByCatalogId() {
        //
        CategoryRom categoryRom = CategoryRom.sample();
        categoryReadStore.create(categoryRom);
        List<CategoryRom> testCategoryRoms = categoryReadStore.retrieveAllByCatalogId(categoryRom.getCatalogId());

        Assert.assertEquals(testCategoryRoms.get(0), categoryRom);
    }

    @Test
    public void testRetrieveAllByCatalogIdWithLangCode() {
        //
        CategoryRom categoryRom = CategoryRom.sample();
        categoryReadStore.create(categoryRom);
        List<CategoryRom> testCategoryRoms = categoryReadStore.retrieveAllByCatalogId(categoryRom.getCatalogId(), categoryRom.getLangCode());

        Assert.assertEquals(testCategoryRoms.get(0), categoryRom);
    }

    @Test
    public void testDelete() {
        //
        CategoryRom categoryRom = CategoryRom.sample();
        categoryReadStore.create(categoryRom);

        String catalogId = categoryRom.getCatalogId();
        String categoryId = categoryRom.getId();

        System.out.println("catalogId: " + catalogId);
        System.out.println("categoryId: " + categoryId);

        List<CategoryRom> foundCategoryRomList1 = categoryReadStore.retrieve(categoryId);
        List<CategoryRom> foundCategoryRomList2 = categoryReadStore.retrieveAllByCatalogId(catalogId);
        System.out.println("foundCategoryRomList1: " + foundCategoryRomList1.size());
        System.out.println("foundCategoryRomList2: " + foundCategoryRomList2.size());

        categoryReadStore.delete(categoryId);

        List<CategoryRom> roms = categoryReadStore.retrieve(categoryId);
        Assert.assertTrue(roms.size() == 0);

        List<CategoryRom> categoryRoms = categoryReadStore.retrieveAllByCatalogId(catalogId);
        Assert.assertEquals(0, categoryRoms.size());
    }
}
