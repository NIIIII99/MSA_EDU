package io.naraplatform.artcenter.drama;

import io.naraplatform.artcenter.command.bind.drama.DramaEventBinder;
import io.naraplatform.artcenter.command.proxy.drama.DramaEventProducer;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.event.DramaEvent;
import io.naraplatform.share.event.EventType;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LambdaTest {

    public static void main(String[] args) {

        DramaEventProducer producer = new DramaEventBinder();

        //
        List<String> featureJsons = new ArrayList<String>();
        featureJsons.add(DramaFeature.sample().toJson());
        featureJsons.add(DramaFeature.sample().toString());

        List<DramaFeature> features = featureJsons.stream().map(DramaFeature::fromJson).collect(Collectors.toList());
        if (features.size() == 2) {
            System.out.println("STEP #1");
        }

        List<DramaEvent> events = featureJsons.stream().map(DramaFeature::fromJson).map(feature -> DramaEvent.buildDramaFeatureChildEvent(EventType.ChildAdded, feature)).collect(Collectors.toList());
        if (events.size() == 2) {
            System.out.println("STEP #2");
        }

        featureJsons.stream().map(DramaFeature::fromJson)
            .map(feature -> DramaEvent.buildDramaFeatureChildEvent(EventType.ChildAdded, feature))
            .forEach(event -> producer.produceDramaEvent(event));
        System.out.println("STEP #3");
    }

}
