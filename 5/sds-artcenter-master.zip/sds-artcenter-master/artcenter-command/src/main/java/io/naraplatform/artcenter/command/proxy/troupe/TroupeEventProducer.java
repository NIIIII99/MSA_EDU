package io.naraplatform.artcenter.command.proxy.troupe;

import io.naraplatform.artcenter.domain.troupe.event.TroupeEvent;
import io.naraplatform.share.event.loginuser.LoginUserEvent;

public interface TroupeEventProducer {
    //
    void produceTroupeEvent(TroupeEvent event);
    void produceLoginUserEvent(LoginUserEvent loginUserEvent);   
}
