package io.naraplatform.artcenter.command.bind.catalog;

import io.naraplatform.artcenter.command.proxy.catalog.CatalogQuery;
import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CatalogQueryDelegator implements CatalogQuery {

    @Autowired
    CatalogQueryClient catalogQueryClient;

    @Override
    public Catalog findCatalog(String catalogId) {
        //
        return catalogQueryClient.findCatalog(catalogId);
    }

    @Override
    public Category findCategory(String categoryId) {
        //
        return catalogQueryClient.findCategory(categoryId);
    }
}
