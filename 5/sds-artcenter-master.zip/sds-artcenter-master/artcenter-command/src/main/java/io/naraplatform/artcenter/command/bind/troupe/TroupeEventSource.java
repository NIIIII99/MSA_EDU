package io.naraplatform.artcenter.command.bind.troupe;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface TroupeEventSource {

    String TROUPE_OUTPUT = "troupeOutput";

    //
	@Output(TROUPE_OUTPUT)
    MessageChannel troupeOutput();

}
