package io.naraplatform.artcenter.command.proxy.drama;

import io.naraplatform.artcenter.domain.drama.event.DramaEvent;

public interface DramaEventProducer {
    //
    void produceDramaEvent(DramaEvent event);
}
