package io.naraplatform.artcenter.command.bind.troupe;

import io.naraplatform.artcenter.command.proxy.troupe.TroupeQuery;
import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TroupeQueryDelegator implements TroupeQuery {
    
	@Autowired
	TroupeQueryClient troupeQueryClient;
	
    public Troupe findTroupeSample() {
        return Troupe.sample();
    }

    public Troupe findTroupe(String id) {
        return troupeQueryClient.findById(id);
    }

    public boolean existTroupeByEmail(String email) {
    	return troupeQueryClient.existByEmail(email);
    }

    public Troupe findTroupeByLoginUserId(String loginUserId) {
    	return troupeQueryClient.findByUserId(loginUserId);
    }

    //
    // Troupe 서비스에서 외부의 서비스로 접근하는 곳
    // TroupeQueryClient를 사용하거나 직접 TroupeQueryLogic에 접근 <-- 로컬일 경우
}
