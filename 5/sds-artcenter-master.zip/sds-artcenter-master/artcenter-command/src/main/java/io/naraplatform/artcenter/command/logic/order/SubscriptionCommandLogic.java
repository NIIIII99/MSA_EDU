package io.naraplatform.artcenter.command.logic.order;

import io.naraplatform.artcenter.command.proxy.drama.DramaQuery;
import io.naraplatform.artcenter.command.proxy.order.SubscriptionEventProducer;
import io.naraplatform.artcenter.command.proxy.order.SubscriptionQuery;
import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.artcenter.domain.order.command.model.SubscriptionState;
import io.naraplatform.artcenter.domain.order.command.spec.SubscriptionService;
import io.naraplatform.artcenter.domain.order.command.spec.sdo.SubscriptionCdo;
import io.naraplatform.artcenter.domain.order.event.SubscriptionEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionCommandLogic implements SubscriptionService {

    @Autowired
    SubscriptionEventProducer subscriptionEventProducer;

    @Autowired
    SubscriptionQuery subscriptionQuery;
    @Autowired
    DramaQuery dramaQuery;

    @Override
    public String subscribe(SubscriptionCdo subscriptionCdo) {
        //
        Drama drama = dramaQuery.findDrama(subscriptionCdo.getDramaId());

        Subscription subscription = new Subscription(subscriptionCdo.getLang(),
            drama,
            subscriptionCdo.getEditionName(),
            subscriptionCdo.getDramaVersion(),
            subscriptionCdo.getTeam(),
            subscriptionCdo.getSubscriber());

        SubscriptionEvent subscriptionEvent = SubscriptionEvent.buildSubscriptionCreatedEvent(subscription);
        subscriptionEventProducer.produceSubscriptionEvent(subscriptionEvent);

        return subscription.getId();
    }

    @Override
    public void stopSubscription(String subscriptionId) {
        //
        Subscription subscription = subscriptionQuery.findSubscription(subscriptionId);
        subscription.setState(SubscriptionState.Suspended);

        SubscriptionEvent subscriptionEvent = SubscriptionEvent.buildSubscriptionStateChangedEvent(subscription);
        subscriptionEventProducer.produceSubscriptionEvent(subscriptionEvent);
    }

    @Override
    public void resumeSubscription(String subscriptionId) {
        //
        Subscription subscription = subscriptionQuery.findSubscription(subscriptionId);
        subscription.setState(SubscriptionState.Open);

        SubscriptionEvent subscriptionEvent = SubscriptionEvent.buildSubscriptionStateChangedEvent(subscription);
        subscriptionEventProducer.produceSubscriptionEvent(subscriptionEvent);
    }
}
