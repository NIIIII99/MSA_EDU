package io.naraplatform.artcenter.command.proxy.order;

import io.naraplatform.artcenter.domain.order.event.SubscriptionEvent;

public interface SubscriptionEventProducer {

    void produceSubscriptionEvent(SubscriptionEvent event);

}
