package io.naraplatform.artcenter.command.bind.troupe;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;

@FeignClient(name="${artcenter.command-feign-name}") // config 서버내 application.yml 설정
public interface TroupeQueryClient {
	
	@GetMapping(value="/troupe/{id}")
	public Troupe findById(@PathVariable("id") String id);
	
	@GetMapping(value="/troupe/email/{email}/exist")
	public boolean existByEmail(@PathVariable("email") String email);
	
	@GetMapping(value="/troupe/userId/{userId}")
	public Troupe findByUserId(@PathVariable("userId") String loginUserId);
	
}
