package io.naraplatform.artcenter.command.bind.troupe;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageBuilder;

import io.naraplatform.artcenter.command.proxy.troupe.TroupeEventProducer;
import io.naraplatform.artcenter.domain.troupe.event.TroupeEvent;
import io.naraplatform.share.event.loginuser.LoginUserEvent;

@EnableBinding(TroupeEventSource.class)
public class TroupeEventBinder implements TroupeEventProducer {

	@Autowired
	private TroupeEventSource troupeEventSource;
	
    @Override
    public void produceTroupeEvent(TroupeEvent event) {
        //
    	troupeEventSource.troupeOutput().send(MessageBuilder.withPayload(event).setHeader("domain", "TroupeEvent").build());
    }

    @Override
    public void produceLoginUserEvent(LoginUserEvent loginUserEvent) {
        //
    	troupeEventSource.troupeOutput().send(MessageBuilder.withPayload(loginUserEvent).setHeader("domain", "LoginUserEvent").build());
    }
}
