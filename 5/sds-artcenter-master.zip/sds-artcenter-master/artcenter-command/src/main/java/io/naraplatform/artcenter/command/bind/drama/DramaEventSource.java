package io.naraplatform.artcenter.command.bind.drama;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface DramaEventSource {

    String DRAMA_OUTPUT = "dramaOutput";

    //
	@Output(DRAMA_OUTPUT)
    MessageChannel dramaOutput();
}
