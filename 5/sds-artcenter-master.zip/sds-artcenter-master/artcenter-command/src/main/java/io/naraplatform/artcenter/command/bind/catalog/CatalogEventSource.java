package io.naraplatform.artcenter.command.bind.catalog;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface CatalogEventSource {

    String CATALOG_OUTPUT = "catalogOutput";

    //
    @Output(CATALOG_OUTPUT)
    MessageChannel catalogOutput();

}
