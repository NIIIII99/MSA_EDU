package io.naraplatform.artcenter.command.bind.order;

import io.naraplatform.artcenter.command.proxy.order.SubscriptionQuery;
import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SubscriptionQueryDelegator implements SubscriptionQuery {

    @Autowired
    SubscriptionQueryClient subscriptionQueryClient;

    @Override
    public Subscription findSubscription(String subscriptionId) {
        //
        return subscriptionQueryClient.findSubscription(subscriptionId);
    }
}
