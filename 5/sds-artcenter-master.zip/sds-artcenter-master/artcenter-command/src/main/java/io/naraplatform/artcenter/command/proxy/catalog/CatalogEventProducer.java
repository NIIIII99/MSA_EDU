package io.naraplatform.artcenter.command.proxy.catalog;

import io.naraplatform.artcenter.domain.catalog.event.CatalogEvent;

public interface CatalogEventProducer {

    //
    void produceCatalogEvent(CatalogEvent event);

}
