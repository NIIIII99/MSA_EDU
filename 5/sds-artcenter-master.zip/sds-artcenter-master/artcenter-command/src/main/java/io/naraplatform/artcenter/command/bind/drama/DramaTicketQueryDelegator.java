package io.naraplatform.artcenter.command.bind.drama;

import io.naraplatform.artcenter.command.proxy.drama.DramaTicketQuery;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DramaTicketQueryDelegator implements DramaTicketQuery {

    @Autowired
    DramaTicketQueryClient dramaTicketQueryClient;

    @Override
    public DramaTicket findDramaTicket(String ticketId) {
        //
        return dramaTicketQueryClient.findById(ticketId);
    }

}
