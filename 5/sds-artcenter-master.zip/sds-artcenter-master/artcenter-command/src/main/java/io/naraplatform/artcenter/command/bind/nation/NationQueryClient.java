package io.naraplatform.artcenter.command.bind.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="${artcenter.command-feign-name}")
public interface NationQueryClient {

    @GetMapping(value="/nation/{nationId}")
    public Nation findById(@PathVariable("nationId") String nationId);

}
