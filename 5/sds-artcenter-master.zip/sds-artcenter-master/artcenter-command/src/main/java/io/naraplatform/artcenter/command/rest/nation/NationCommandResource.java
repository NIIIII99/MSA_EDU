package io.naraplatform.artcenter.command.rest.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.artcenter.domain.nation.command.spec.NationService;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="nation")
public class NationCommandResource implements NationService {

    @Autowired
    NationService nationService;

    @Override
    @PostMapping(value={"/", ""})
    public String registerNation(@RequestBody Nation nation) {
        //
        nationService.registerNation(nation);
        return nation.getId();
    }

    @Override
    @PutMapping(value="/{nationId}")
    public void modifyNation(@PathVariable(value="nationId") String nationId, @RequestBody NameValueList nameValues) {
        //
        nationService.modifyNation(nationId, nameValues);
    }

    @Override
    @DeleteMapping(value="/{nationId}")
    public void removeNation(@PathVariable(value="nationId") String nationId) {
        //
        nationService.removeNation(nationId);
    }
}
