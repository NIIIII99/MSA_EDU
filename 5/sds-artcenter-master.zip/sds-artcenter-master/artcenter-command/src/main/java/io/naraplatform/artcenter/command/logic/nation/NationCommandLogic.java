package io.naraplatform.artcenter.command.logic.nation;

import io.naraplatform.artcenter.command.proxy.nation.NationEventProducer;
import io.naraplatform.artcenter.command.proxy.nation.NationQuery;
import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.artcenter.domain.nation.command.spec.NationService;
import io.naraplatform.artcenter.domain.nation.event.NationEvent;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NationCommandLogic implements NationService {

    @Autowired
    NationEventProducer nationEventProducer;

    @Autowired
    NationQuery nationQuery;

    @Override
    public String registerNation(Nation nation) {
        //
        NationEvent nationEvent = NationEvent.buildCreatedEvent(nation);
        nationEventProducer.produceNationEvent(nationEvent);
        return nation.getId();
    }

    @Override
    public void modifyNation(String nationId, NameValueList nameValues) {
        //
        Nation nation = nationQuery.findNation(nationId);
        nation.setValues(nameValues);

        NationEvent nationEvent = NationEvent.buildUpdatedEvent(nation);
        nationEventProducer.produceNationEvent(nationEvent);
    }

    @Override
    public void removeNation(String nationId) {
        NationEvent nationEvent = NationEvent.buildDeletedEvent(nationId);
        nationEventProducer.produceNationEvent(nationEvent);
    }
}
