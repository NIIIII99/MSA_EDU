package io.naraplatform.artcenter.command.rest.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.spec.CatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class CatalogCommandResource implements CatalogService {

    @Autowired
    CatalogService catalogService;

    @Override
    @PostMapping(value="/catalog")
    public String registerCatalog(@RequestBody Catalog catalog) {
        //
        return catalogService.registerCatalog(catalog);
    }

    @Override
    @PutMapping(value="/catalog")
    public void modifyCatalog(@RequestBody Catalog catalog) {
        //
        catalogService.modifyCatalog(catalog);
    }

    @Override
    @DeleteMapping(value={"/catalog/{catalogId}"})
    public void remove(@PathVariable(value="catalogId")  String catalogId) {
        //
        catalogService.remove(catalogId);
    }

    @Override
    @PostMapping(value="/category")
    public String addCategory(@RequestBody Category category) {
        //
        return catalogService.addCategory(category);
    }

    @Override
    @PutMapping(value="/category")
    public void modifyCategory(@RequestBody Category category) {
        //
        catalogService.modifyCategory(category);
    }

    @Override
    @DeleteMapping(value="/category/{categoryId}")
    public void removeCategory(@PathVariable(value="categoryId") String categoryId) {
        //
        catalogService.removeCategory(categoryId);
    }

}
