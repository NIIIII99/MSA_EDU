package io.naraplatform.artcenter.command.proxy.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;

public interface TroupeQuery {
    //
    public Troupe findTroupeSample();
    public Troupe findTroupe(String id);
    public boolean existTroupeByEmail(String email);
    public Troupe findTroupeByLoginUserId(String loginUserId);
}
