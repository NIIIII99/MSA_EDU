package io.naraplatform.artcenter.command.listen;

public class ArtCenterEventListener {
    //
    // Artcenter에서 필요한 모든 Event를 Listening 하는 곳
}
