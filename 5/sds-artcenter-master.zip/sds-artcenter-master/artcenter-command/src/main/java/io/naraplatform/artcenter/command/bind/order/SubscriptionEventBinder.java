package io.naraplatform.artcenter.command.bind.order;

import io.naraplatform.artcenter.command.bind.nation.NationEventSource;
import io.naraplatform.artcenter.command.proxy.order.SubscriptionEventProducer;
import io.naraplatform.artcenter.domain.order.event.SubscriptionEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageBuilder;

@EnableBinding(SubscriptionEventSource.class)
public class SubscriptionEventBinder implements SubscriptionEventProducer {

    @Autowired
    private SubscriptionEventSource subscriptionEventSource;

    @Override
    public void produceSubscriptionEvent(SubscriptionEvent event) {
        //
        subscriptionEventSource.subscriptionOutput()
            .send(MessageBuilder.withPayload(event)
                .setHeader("domain", "SubscriptionEvent").build());
    }
}
