package io.naraplatform.artcenter.command.proxy.nation;

import io.naraplatform.artcenter.domain.nation.event.NationEvent;

public interface NationEventProducer {

    //
    void produceNationEvent(NationEvent event);

}
