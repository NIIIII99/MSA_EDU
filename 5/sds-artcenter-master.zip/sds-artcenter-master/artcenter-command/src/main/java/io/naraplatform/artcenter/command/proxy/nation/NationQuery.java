package io.naraplatform.artcenter.command.proxy.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;

public interface NationQuery {

    public Nation findNation(String nationId);

}
