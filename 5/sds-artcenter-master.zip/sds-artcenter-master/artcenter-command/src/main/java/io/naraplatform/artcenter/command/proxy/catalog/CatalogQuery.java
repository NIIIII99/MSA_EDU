package io.naraplatform.artcenter.command.proxy.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;

public interface CatalogQuery {

    //
    Catalog findCatalog(String catalogId);

    Category findCategory(String categoryId);

}
