package io.naraplatform.artcenter.command.bind.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="${artcenter.command-feign-name}")
public interface SubscriptionQueryClient {

    @GetMapping(value="/order/{subscriptionId}")
    Subscription findSubscription(@PathVariable("subscriptionId") String subscriptionId);

}
