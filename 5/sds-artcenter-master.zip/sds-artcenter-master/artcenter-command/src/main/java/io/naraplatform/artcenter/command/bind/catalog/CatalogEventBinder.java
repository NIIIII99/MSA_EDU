package io.naraplatform.artcenter.command.bind.catalog;

import io.naraplatform.artcenter.command.proxy.catalog.CatalogEventProducer;
import io.naraplatform.artcenter.domain.catalog.event.CatalogEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageBuilder;

@EnableBinding(CatalogEventSource.class)
public class CatalogEventBinder implements CatalogEventProducer {

    @Autowired
    private CatalogEventSource catalogEventSource;

    @Override
    public void produceCatalogEvent(CatalogEvent event) {
        //
        String eventTypeName = event.getType().toString();
        String domainName = event.getClass().getSimpleName();

        catalogEventSource.catalogOutput()
            .send(MessageBuilder.withPayload(event)
                .setHeader("eventType", eventTypeName)
                .setHeader("domain", domainName).build());
    }
}
