package io.naraplatform.artcenter.command.bind.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="${artcenter.command-feign-name}")
public interface DramaTicketQueryClient {

    @GetMapping(value="/drama/ticket/{dramaTicketId}")
    DramaTicket findById(@PathVariable(value="dramaTicketId") String dramaTicketId);

}
