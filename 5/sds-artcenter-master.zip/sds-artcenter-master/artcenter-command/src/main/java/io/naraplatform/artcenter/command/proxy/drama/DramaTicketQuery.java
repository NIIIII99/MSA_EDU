package io.naraplatform.artcenter.command.proxy.drama;

import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;

public interface DramaTicketQuery {
    //
    DramaTicket findDramaTicket(String ticketId);
}
