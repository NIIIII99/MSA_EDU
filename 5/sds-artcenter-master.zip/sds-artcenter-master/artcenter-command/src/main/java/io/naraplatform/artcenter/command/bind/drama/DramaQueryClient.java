package io.naraplatform.artcenter.command.bind.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="${artcenter.command-feign-name}")
public interface DramaQueryClient {

    @GetMapping(value="/drama/{dramaId}")
    Drama findById(@PathVariable("dramaId") String dramaId);

    @GetMapping(value="/drama/feature/{featureId}")
    DramaFeature findFeature(@PathVariable("featureId") String featureId);

}
