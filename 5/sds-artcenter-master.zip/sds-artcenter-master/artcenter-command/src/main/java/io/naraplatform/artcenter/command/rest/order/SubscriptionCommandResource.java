package io.naraplatform.artcenter.command.rest.order;

import io.naraplatform.artcenter.domain.order.command.spec.SubscriptionService;
import io.naraplatform.artcenter.domain.order.command.spec.sdo.SubscriptionCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value="/order")
public class SubscriptionCommandResource implements SubscriptionService {

    @Autowired
    SubscriptionService subscriptionService;

    @Override
    @PostMapping(value={"/", ""})
    public String subscribe(@RequestBody SubscriptionCdo subscriptionCdo) {
        //
        return subscriptionService.subscribe(subscriptionCdo);
    }

    @Override
    @PutMapping(value="/{subscriptionId}/stop")
    public void stopSubscription(@PathVariable(value="subscriptionId") String subscriptionId) {
        //
        subscriptionService.stopSubscription(subscriptionId);
    }

    @Override
    @PutMapping(value="/{subscriptionId}/resume")
    public void resumeSubscription(@PathVariable(value="subscriptionId") String subscriptionId) {
        //
        subscriptionService.resumeSubscription(subscriptionId);
    }
}
