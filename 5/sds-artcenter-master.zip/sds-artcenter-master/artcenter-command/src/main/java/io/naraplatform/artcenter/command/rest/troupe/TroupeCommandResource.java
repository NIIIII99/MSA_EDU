package io.naraplatform.artcenter.command.rest.troupe;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.domain.troupe.command.spec.TroupeCommandService;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("troupe")
public class TroupeCommandResource implements TroupeCommandService {
    //
    @Autowired
    private TroupeCommandService troupeCommandService;
    
    @Override
    @PostMapping(value={"/", ""})
    public void registerTroupe(@RequestBody Troupe troupe) {
        //
    	troupeCommandService.registerTroupe(troupe);
    }
    
    @Override
    @PutMapping(value="/{id}")
    public void modifyTroupe(@PathVariable("id") String id, @RequestBody NameValueList nameValus) {
        //
    	troupeCommandService.modifyTroupe(id, nameValus);
    }

    @Override
    @DeleteMapping(value="/{id}")
    public void removeTroupe(@PathVariable("id") String id) {
        //
    	troupeCommandService.removeTroupe(id);
    }
}
