package io.naraplatform.artcenter.command.proxy.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;

public interface DramaQuery {
    //
    public Drama findDramaSample();
    public Drama findDrama(String id);
    public boolean existDramaByTitle(String title);
    public DramaFeature findFeature(String featureId);

}
