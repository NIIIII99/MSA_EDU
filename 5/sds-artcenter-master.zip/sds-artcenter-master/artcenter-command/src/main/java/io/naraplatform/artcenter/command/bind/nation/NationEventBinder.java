package io.naraplatform.artcenter.command.bind.nation;

import io.naraplatform.artcenter.command.proxy.nation.NationEventProducer;
import io.naraplatform.artcenter.domain.nation.event.NationEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageBuilder;

@EnableBinding(NationEventSource.class)
public class NationEventBinder implements NationEventProducer {

    @Autowired
    private NationEventSource nationEventSource;

    @Override
    public void produceNationEvent(NationEvent event) {
        //
        nationEventSource.nationOutput()
            .send(MessageBuilder.withPayload(event)
                .setHeader("domain", "NationEvent").build());

    }

}
