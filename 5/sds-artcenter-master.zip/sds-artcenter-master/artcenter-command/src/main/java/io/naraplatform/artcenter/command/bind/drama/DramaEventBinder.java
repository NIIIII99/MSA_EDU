package io.naraplatform.artcenter.command.bind.drama;

import io.naraplatform.artcenter.command.proxy.drama.DramaEventProducer;
import io.naraplatform.artcenter.domain.drama.event.DramaEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageBuilder;

@EnableBinding(DramaEventSource.class)
public class DramaEventBinder implements DramaEventProducer {

    @Autowired
    private DramaEventSource dramaEventSource;

    @Override
    public void produceDramaEvent(DramaEvent event) {
        //
        String eventTypeName = event.getType().toString();
        String domainName = event.getClass().getSimpleName();

        dramaEventSource.dramaOutput()
            .send(MessageBuilder.withPayload(event)
            .setHeader("eventType", eventTypeName)
            .setHeader("domain", domainName).build());
    }

}
