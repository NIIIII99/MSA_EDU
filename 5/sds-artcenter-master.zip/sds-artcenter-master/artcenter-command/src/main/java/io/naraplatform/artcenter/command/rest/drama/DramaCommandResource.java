package io.naraplatform.artcenter.command.rest.drama;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.command.spec.DramaService;
import io.naraplatform.artcenter.domain.drama.command.spec.sdo.DramaVersionCdo;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/drama")
public class DramaCommandResource implements DramaService {

    @Autowired
    private DramaService dramaService;

    @Override
    @PostMapping(value={"/", ""}, consumes="application/string")
    public String registerDramaJson(@RequestBody String dramaJson) {
        //
        return dramaService.registerDramaJson(dramaJson);
    }

    @Override
    @PostMapping(value={"/", ""})
    public String registerDrama(@RequestBody Drama drama, @RequestBody DramaVersion dramaVersion) {
        //
        return dramaService.registerDrama(drama, dramaVersion);
    }

    @Override
    @PutMapping(value={"/{dramaId}"})
    public void modifyDrama(@PathVariable(value="dramaId") String dramaId, @RequestBody NameValueList nameValues) {
        //
        dramaService.modifyDrama(dramaId, nameValues);
    }

    @Override
    @DeleteMapping(value={"/{dramaId}"})
    public void removeDrama(@PathVariable(value="dramaId") String dramaId) {
        //
        dramaService.removeDrama(dramaId);
    }

    @Override
    @PostMapping(value="/version")
    public void addVersion(@RequestBody DramaVersionCdo dramaVersionCdo) {
        //
        dramaService.addVersion(dramaVersionCdo);
    }

    @Override
    @PostMapping(value="/{dramaId}/version", consumes="application/string")
    public String addVersionJson(@PathVariable(value="dramaId") String dramaId, @RequestBody String versionJson) {
        //
        return dramaService.addVersionJson(dramaId, versionJson);
    }

    @Override
    @PostMapping(value="/{dramaId}/version")
    public String addVersion(@PathVariable(value="dramaId") String dramaId, @RequestBody DramaVersion dramaVersion) {
        //
        return dramaService.addVersion(dramaId, dramaVersion);
    }

    @Override
    @DeleteMapping(value="/{dramaId}/version/{versionId}")
    public void removeVersion(@PathVariable(value="dramaId") String dramaId, @PathVariable(value="versionId") String versionId) {
        //
        dramaService.removeVersion(dramaId, versionId);
    }

    @Override
    @PutMapping(value="/{dramaId}/version")
    public void updateVersion(@PathVariable(value="dramaId") String dramaId, @RequestBody DramaVersion dramaVersion) {
        //
        dramaService.updateVersion(dramaId, dramaVersion);
    }

    @Override
    @PostMapping(value="/{dramaId}/feature", consumes="application/string")
    public String addFeatureJson(@PathVariable(value="dramaId") String dramaId, @RequestBody List<String> featureJsons) {
        //
        return dramaService.addFeatureJson(dramaId, featureJsons);
    }

    @Override
    @PostMapping(value="/{dramaId}/feature")
    public String addFeature(@PathVariable(value="dramaId") String dramaId, @RequestBody List<DramaFeature> features) {
        //
        return dramaService.addFeature(dramaId, features);
    }

    @Override
    @DeleteMapping(value="/{dramaId}/feature/{featureId}")
    public void removeFeature(@PathVariable(value="dramaId") String dramaId, @PathVariable(value="featureId") String featureId) {
        //
        dramaService.removeFeature(dramaId, featureId);
    }

    @Override
    @PutMapping(value="/{dramaId}/feature")
    public void updateFeature(@PathVariable(value="dramaId") String dramaId, @RequestBody DramaFeature feature) {
        //
        dramaService.updateFeature(dramaId, feature);
    }
}
