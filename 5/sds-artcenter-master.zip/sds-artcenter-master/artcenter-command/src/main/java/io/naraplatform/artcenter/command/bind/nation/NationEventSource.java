package io.naraplatform.artcenter.command.bind.nation;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface NationEventSource {

    String NATION_OUTPUT = "nationOutput";

    //
    @Output(NATION_OUTPUT)
    MessageChannel nationOutput();

}
