package io.naraplatform.artcenter.command.logic.catalog;

import io.naraplatform.artcenter.command.proxy.catalog.CatalogEventProducer;
import io.naraplatform.artcenter.command.proxy.catalog.CatalogQuery;
import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.spec.CatalogService;
import io.naraplatform.artcenter.domain.catalog.event.CatalogEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CatalogCommandLogic implements CatalogService {

    @Autowired
    CatalogEventProducer catalogEventProducer;

    @Autowired
    CatalogQuery catalogQuery;

    @Override
    public String registerCatalog(Catalog catalog) {
        //
        CatalogEvent catalogEvent = CatalogEvent.buildCatalogCreatedEvent(catalog);
        catalogEventProducer.produceCatalogEvent(catalogEvent);

        return catalog.getId();
    }

    @Override
    public void modifyCatalog(Catalog catalog) {
        //
        CatalogEvent catalogEvent = CatalogEvent.buildCatalogUpdatedEvent(catalog);
        catalogEventProducer.produceCatalogEvent(catalogEvent);
    }

    @Override
    public void remove(String catalogId) {
        //
        Catalog catalog = catalogQuery.findCatalog(catalogId);
        CatalogEvent catalogEvent = CatalogEvent.buildCatalogDeletedEvent(catalog);
        catalogEventProducer.produceCatalogEvent(catalogEvent);
    }

    @Override
    public String addCategory(Category category) {
        //
        CatalogEvent catalogEvent = CatalogEvent.buildCategoryCreatedEvent(category);
        catalogEventProducer.produceCatalogEvent(catalogEvent);

        return category.getId();
    }

    @Override
    public void modifyCategory(Category category) {
        CatalogEvent catalogEvent = CatalogEvent.buildCategoryUpdatedEvent(category);
        catalogEventProducer.produceCatalogEvent(catalogEvent);
    }

    @Override
    public void removeCategory(String categoryId) {
        //
        Category category = catalogQuery.findCategory(categoryId);
        CatalogEvent catalogEvent = CatalogEvent.buildCategoryDeletedEvent(category);
        catalogEventProducer.produceCatalogEvent(catalogEvent);
    }

}
