package io.naraplatform.artcenter.command.bind.drama;

import io.naraplatform.artcenter.command.proxy.drama.DramaQuery;
import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DramaQueryDelegator implements DramaQuery {

    @Autowired
    DramaQueryClient dramaQueryClient;

    @Override
    public Drama findDramaSample() {
        //
        return Drama.sample();
    }

    @Override
    public Drama findDrama(String id) {
        //
        return dramaQueryClient.findById(id);
    }

    @Override
    public boolean existDramaByTitle(String title) {
        return false;
    }

    @Override
    public DramaFeature findFeature(String featureId) {
        //
        return dramaQueryClient.findFeature(featureId);
    }
}
