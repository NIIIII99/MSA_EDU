package io.naraplatform.artcenter.command.logic.troupe;

import io.naraplatform.artcenter.command.proxy.troupe.TroupeEventProducer;
import io.naraplatform.artcenter.command.proxy.troupe.TroupeQuery;
import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.domain.troupe.command.spec.TroupeCommandService;
import io.naraplatform.artcenter.domain.troupe.event.TroupeEvent;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.event.loginuser.LoginUserEvent;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;

@Service
public class TroupeCommandLogic implements TroupeCommandService {
    //
	@Autowired
    TroupeEventProducer eventProducer;
	@Autowired
    TroupeQuery troupeQuery;

    public TroupeCommandLogic() {
        //
    }

    @Override
    public void registerTroupe(Troupe troupe) {
        //
        String email = troupe.getContact().getEmail();
        if(troupeQuery.existTroupeByEmail(email)) {
            throw new AlreadyExistsException("Troupe: " + troupe.toJson());
        }

        TroupeEvent troupeEvent = TroupeEvent.buildCreateEvent(troupe);
        LoginUserEvent loginUserEvent = LoginUserEvent.buildCreateEvent(troupe.getLoginUserInfo());
        eventProducer.produceTroupeEvent(troupeEvent);
        eventProducer.produceLoginUserEvent(loginUserEvent);
    }

    @Override
    public void modifyTroupe(String troupeId, NameValueList nameValues) {
        //
        if(nameValues.size() == 0) {
            return;
        }

        Troupe troupe = findTroupe(troupeId);
        troupe.setValues(nameValues);

        TroupeEvent troupeEvent = TroupeEvent.buildUpdateEvent(troupe);
        eventProducer.produceTroupeEvent(troupeEvent);
    }

    @Override
    public void removeTroupe(String troupeId) {
        //
        Troupe troupe = findTroupe(troupeId);

        TroupeEvent troupeEvent = TroupeEvent.buildDeleteEvent(troupe);
        eventProducer.produceTroupeEvent(troupeEvent);
    }

    private Troupe findTroupe(String troupeId) {
        //
        Troupe troupe = troupeQuery.findTroupe(troupeId);
        if (troupe == null) {
            throw new NoSuchElementException("Troupe id: " + troupeId);
        }

        return troupe;
    }
}
