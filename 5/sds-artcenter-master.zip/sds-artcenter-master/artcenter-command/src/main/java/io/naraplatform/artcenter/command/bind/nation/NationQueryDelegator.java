package io.naraplatform.artcenter.command.bind.nation;

import io.naraplatform.artcenter.command.proxy.nation.NationQuery;
import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NationQueryDelegator implements NationQuery {

    @Autowired
    NationQueryClient nationQueryClient;

    @Override
    public Nation findNation(String nationId) {
        //
        return nationQueryClient.findById(nationId);
    }

}
