package io.naraplatform.artcenter.command.logic.drama;

import io.naraplatform.artcenter.command.proxy.catalog.CatalogQuery;
import io.naraplatform.artcenter.command.proxy.drama.DramaEventProducer;
import io.naraplatform.artcenter.command.proxy.drama.DramaQuery;
import io.naraplatform.artcenter.command.proxy.drama.DramaTicketQuery;
import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.command.spec.DramaService;
import io.naraplatform.artcenter.domain.drama.command.spec.sdo.DramaVersionCdo;
import io.naraplatform.artcenter.domain.drama.event.DramaEvent;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.exception.NaraException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class DramaCommandLogic implements DramaService {

    @Autowired
    DramaEventProducer eventProducer;

    @Autowired
    DramaQuery dramaQuery;
    @Autowired
    DramaTicketQuery dramaTicketQuery;

    @Autowired
    CatalogQuery catalogQuery;

    //@Autowired
    //FeedbackAdapter feedbackAdapter;

    @Override
    public String registerDramaJson(String dramaJson) {
        //
        Drama drama = Drama.fromJson(dramaJson);

        //IdName feedbackTicket = new IdName(drama.getId(), drama.getTitles().getString(drama.getDefaultLang()));
        //String feedbackId = feedbackAdapter.createTicket(feedbackTicket);
        drama.setFeedbackId(UUID.randomUUID().toString());

        DramaEvent dramaEvent = DramaEvent.buildCreateEvent(drama);
        eventProducer.produceDramaEvent(dramaEvent);

        return drama.getId();
    }

    @Override
    public String registerDrama(Drama drama, DramaVersion dramaVersion) {
        //
        DramaEvent dramaEvent = DramaEvent.buildCreateEvent(drama);
        eventProducer.produceDramaEvent(dramaEvent);

        DramaEvent dramaVersionEvent = DramaEvent.buildDramaVersionChildEvent(EventType.ChildAdded, dramaVersion);
        eventProducer.produceDramaEvent(dramaVersionEvent);

        return drama.getId();
    }

    @Override
    public void modifyDrama(String dramaId, NameValueList nameValues) {
        //
        Drama drama = dramaQuery.findDrama(dramaId);
        drama.setValues(nameValues);

        DramaEvent dramaEvent = DramaEvent.buildUpdateEvent(drama);
        eventProducer.produceDramaEvent(dramaEvent);
    }

    @Override
    public void removeDrama(String dramaId) {
        //
        Drama drama = dramaQuery.findDrama(dramaId);

        DramaEvent dramaEvent = DramaEvent.buildDeleteEvent(drama);
        eventProducer.produceDramaEvent(dramaEvent);
    }

    @Override
    public void addVersion(DramaVersionCdo dramaVersionCdo) {
        //
        String ticketId = dramaVersionCdo.getTicketId();
        DramaTicket dramaTicket = dramaTicketQuery.findDramaTicket(ticketId);

        String dramaId = dramaTicket.getDramaId();

        DramaVersion dramaVersion = dramaVersionCdo.getDramaVersion();
        dramaVersion.setDramaId(dramaId);

        List<DramaFeature> dramaFeatures = dramaVersionCdo.getDramaFeatures();
        dramaFeatures.stream().forEach(feature -> feature.setDramaId(dramaId));

        DramaEvent dramaEvent = DramaEvent.buildDramaVersionChildEvent(EventType.ChildAdded, dramaVersion);
        eventProducer.produceDramaEvent(dramaEvent);

        dramaFeatures.stream()
            .map(feature -> DramaEvent.buildDramaFeatureChildEvent(EventType.ChildAdded, feature))
            .forEach(event -> eventProducer.produceDramaEvent(event));
    }

    @Override
    public String addVersionJson(String dramaId, String versionJson) {
        //
        DramaVersion dramaVersion = DramaVersion.fromJson(versionJson);
        dramaVersion.setDramaId(dramaId);

        DramaEvent dramaEvent = DramaEvent.buildDramaVersionChildEvent(EventType.ChildAdded, dramaVersion);
        eventProducer.produceDramaEvent(dramaEvent);

        return dramaVersion.getId();
    }

    @Override
    public String addVersion(String dramaId, DramaVersion dramaVersion) {
        //
        dramaVersion.setDramaId(dramaId);

        DramaEvent dramaEvent = DramaEvent.buildDramaVersionChildEvent(EventType.ChildAdded, dramaVersion);
        eventProducer.produceDramaEvent(dramaEvent);

        return dramaVersion.getId();
    }

    @Override
    public void removeVersion(String dramaId, String versionId) {
        //
        DramaVersion dramaVersion = new DramaVersion(versionId);
        dramaVersion.setDramaId(dramaId);

        DramaEvent dramaEvent = DramaEvent.buildDramaVersionChildEvent(EventType.ChildRemoved, dramaVersion);
        eventProducer.produceDramaEvent(dramaEvent);
    }

    @Override
    public void updateVersion(String dramaId, DramaVersion dramaVersion) {
        //
        dramaVersion.setDramaId(dramaId);

        DramaEvent dramaEvent = DramaEvent.buildDramaVersionChildEvent(EventType.ChildUpdated, dramaVersion);
        eventProducer.produceDramaEvent(dramaEvent);
    }

    @Override
    public String addFeatureJson(String dramaId, List<String> featureJsons) {
        //
        if (featureJsons == null || featureJsons.isEmpty()) {
            throw new NaraException("DramaFeature is empty!");
        }

        featureJsons.stream()
            .map(DramaFeature::fromJson)
            .map(feature -> DramaEvent.buildDramaFeatureChildEvent(EventType.ChildAdded, feature))
            .forEach(event -> eventProducer.produceDramaEvent(event));

        return dramaId;
    }

    @Override
    public String addFeature(String dramaId, List<DramaFeature> features) {
        //
        if (features == null || features.isEmpty()) {
            throw new NaraException("DramaFeature is empty!");
        }

        features.stream()
            .map(feature -> DramaEvent.buildDramaFeatureChildEvent(EventType.ChildAdded, feature))
            .forEach(event -> eventProducer.produceDramaEvent(event));

        return dramaId;
    }

    @Override
    public void removeFeature(String dramaId, String featureId) {
        //
        DramaFeature dramaFeature = dramaQuery.findFeature(featureId);
        DramaEvent dramaEvent = DramaEvent.buildDramaFeatureChildEvent(EventType.ChildRemoved, dramaFeature);
        eventProducer.produceDramaEvent(dramaEvent);
    }

    @Override
    public void updateFeature(String dramaId, DramaFeature feature) {
        //
        DramaEvent dramaEvent = DramaEvent.buildDramaFeatureChildEvent(EventType.ChildUpdated, feature);
        eventProducer.produceDramaEvent(dramaEvent);
    }
}
