package io.naraplatform.artcenter.command.proxy.order;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;

public interface SubscriptionQuery {

    Subscription findSubscription(String subscriptionId);

}
