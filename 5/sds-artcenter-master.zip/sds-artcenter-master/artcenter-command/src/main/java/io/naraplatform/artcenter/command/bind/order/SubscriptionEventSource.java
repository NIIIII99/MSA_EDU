package io.naraplatform.artcenter.command.bind.order;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface SubscriptionEventSource {

    String SUBSCRIPTION_OUTPUT = "subscriptionOutput";

    //
    @Output(SUBSCRIPTION_OUTPUT)
    MessageChannel subscriptionOutput();

}
