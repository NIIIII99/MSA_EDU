package io.naraplatform.artcenter.command.bind.catalog;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="${artcenter.command-feign-name}")
public interface CatalogQueryClient {

    @GetMapping(value="/catalog/{catalogId}")
    Catalog findCatalog(@PathVariable("catalogId") String catalogId);

    @GetMapping(value="/category/{categoryId}")
    Category findCategory(@PathVariable("categoryId") String categoryId);
}
