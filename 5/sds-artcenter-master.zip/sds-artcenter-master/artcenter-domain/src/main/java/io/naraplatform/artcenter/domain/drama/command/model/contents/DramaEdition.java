package io.naraplatform.artcenter.domain.drama.command.model.contents;


import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class DramaEdition implements ValueObject {
    //
    private String key;
    private LangStrings names;
    private LangStrings memos;

    transient List<DramaFeature> features;

    public DramaEdition(LangStrings names) {
        //
        this(null, names);
    }

    public DramaEdition(String key, LangStrings names) {
        //
        if (names == null || names.size() == 0) {
            throw new IllegalArgumentException("DramaEdition name should not be null.");
        }

        if(!names.firstLang().equals(Locale.US.getLanguage())) {
            throw new IllegalArgumentException("Default language should be an English: " + names.toJson());
        }

        if (key == null) {
            String name = names.getString("en");
            this.key = name.substring(0, name.indexOf(' '));
        } else {
            this.key = key;
        }

        this.names = names;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaEdition sample() {
        //
        return new DramaEdition(LangStrings.newString("en", "Community Edition").addString("ko", "커뮤니티 에디션"));
    }

    public static List<DramaEdition> samples() {
        //
        ArrayList<DramaEdition> edtions = new ArrayList<DramaEdition>();
        edtions.add(new DramaEdition(LangStrings.newString("en", "Community Edition").addString("ko", "커뮤니티 에디션")));
        edtions.add(new DramaEdition(LangStrings.newString("en", "Professional Edition").addString("ko", "프로페셔널 에디션")));
        edtions.add(new DramaEdition(LangStrings.newString("en", "Enterprise Edition").addString("ko", "엔터프라이즈 에디션")));

        return edtions;
    }

    public static List<String> sampleKeys() {
        //
        List<DramaEdition> samples = samples();

        List<String> keys = new ArrayList<>(samples.size());
        for(DramaEdition edition : samples()) {
            keys.add(edition.getKey());
        }

        return keys;
    }

    public static DramaEdition fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaEdition.class);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
