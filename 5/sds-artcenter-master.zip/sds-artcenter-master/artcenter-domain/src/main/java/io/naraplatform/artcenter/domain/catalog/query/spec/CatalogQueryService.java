package io.naraplatform.artcenter.domain.catalog.query.spec;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;

import java.util.List;
import java.util.Optional;

public interface CatalogQueryService {
    //
    Catalog findCatalog(String catalogId);
    List<Category> findCategoris(String catalogId);
    Category findCategory(String categoryId);
    List<Category> findCategoris();
    Item findItem(String itemId);
    List<Item> findItemByCatalogAndCategory(String catalogId, String categoryId, int offset, int limit);

    CatalogRom findCatalogRom(String langCode, String catalogId);
    List<CatalogRom> findAllCatalogRoms(String langCode);
    List<CategoryRom> findCategoryRoms(String langCode, String catalogId);
    CategoryRom findCategoryRom(String langCode, String categoryId);

    List<ItemRom> findItemRoms(String catalogId, String categoryId, String langCode, int offset, int limit, Optional<String> keyword);
    List<ItemRom> findItemRoms(String catalogId, String langCode, int offset, int limit, Optional<String> keyword);
    List<ItemRom> findItemRoms(String troupeId, String langCode, int offset, int limit);
    List<ItemRom> findItemRomsBySubscriptionCount(String catalogId, String langCode, int offset, int limit);
    List<ItemRom> findItemRomsBySalesAmount(String catalogId, String langCode, int offset, int limit);
}
