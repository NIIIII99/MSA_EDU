package io.naraplatform.artcenter.domain.troupe.command.spec;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.domain.NameValueList;

public interface TroupeCommandService {
    //
    void registerTroupe(Troupe troupe);
    void modifyTroupe(String troupeId, NameValueList nameValus);
    void removeTroupe(String troupeId);
}
