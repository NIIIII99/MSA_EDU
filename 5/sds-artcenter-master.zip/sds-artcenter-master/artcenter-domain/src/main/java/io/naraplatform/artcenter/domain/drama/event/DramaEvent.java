package io.naraplatform.artcenter.domain.drama.event;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.event.NaraEvent;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class DramaEvent extends NaraEvent {
    //
    private String dramaId;
    private Drama drama;
    private DramaVersion dramaVersion;
    private DramaFeature dramaFeature;

    private DramaEvent(EventType eventType, Drama drama) {
        //
        super(eventType, Drama.class.getSimpleName());
        this.drama = drama;
    }

    private DramaEvent(EventType eventType, DramaVersion dramaVersion) {
        //
        super(eventType, DramaVersion.class.getSimpleName());
        this.dramaVersion = dramaVersion;
    }

    private DramaEvent(EventType eventType, DramaFeature dramaFeature) {
        //
        super(eventType, DramaFeature.class.getSimpleName());
        this.dramaFeature = dramaFeature;
    }

    public static DramaEvent buildCreateEvent(Drama drama) {
        //
        return buildDramaEvent(EventType.Created, drama);
    }

    public static DramaEvent buildUpdateEvent(Drama drama) {
        //
        return buildDramaEvent(EventType.Updated, drama);
    }

    public static DramaEvent buildDeleteEvent(Drama drama) {
        //
        return buildDramaEvent(EventType.Deleted, drama);
    }

    private static DramaEvent buildDramaEvent(EventType eventType, Drama drama) {
        //
        return new DramaEvent(eventType, drama);
    }

    public static DramaEvent buildDramaVersionChildEvent(EventType eventType, DramaVersion dramaVersion) {
        //
        return new DramaEvent(eventType, dramaVersion);
    }

    public static DramaEvent buildDramaFeatureChildEvent(EventType eventType, DramaFeature dramaFeature) {
        //
        return new DramaEvent(eventType, dramaFeature);
    }
}
