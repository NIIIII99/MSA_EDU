package io.naraplatform.artcenter.domain.drama.command.model;

import io.naraplatform.artcenter.domain.drama.command.model.contents.DramaContents;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Getter
@Setter
@NoArgsConstructor
public class DramaVersion extends NaraEntity {
    //
    private String versionName;                     // 1.2.1, 1.3.12
    private LangStrings releaseNotes;
    private LangStrings supportLangs;
    private GlobalPrice price;
    private String releaseDate;                     // ISO, 2018-10-18
    private String dramaId;

    private DramaContents dramaContents;            // 1:1

    public DramaVersion(String id) {
        //
        super(id);
    }

    public DramaVersion(String dramaId,
                        String versionName,
                        LangStrings supportLangs,
                        GlobalPrice price,
                        String releaseDate) {
        //
        super();
        this.versionName = versionName;
        this.releaseNotes = null;
        this.supportLangs = supportLangs;
        this.price = price;
        this.releaseDate = releaseDate;
        this.dramaId = dramaId;
    }

    public DramaVersion(String versionName, DramaVersion previousVersion) {
        //
        super();
        this.versionName = versionName;
        this.releaseNotes = previousVersion.getReleaseNotes();
        this.releaseDate = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        this.supportLangs = previousVersion.getSupportLangs();
        this.price = previousVersion.getPrice();
        this.dramaId = previousVersion.getDramaId();
    }

    public static DramaVersion fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaVersion.class);
    }

    public static DramaVersion sample() {
        //
        String versionName = "1.2.1";
        LangStrings releaseNotes = LangStrings.newString("en", "Bug fix release").addString("ko", "버그수정 버전입니다.");
        LangStrings supportLangs = LangStrings.newString("ko", "영어, 한국어").addString("en", "English, Korean");

        GlobalPrice price = new GlobalPrice(Currency.getInstance(Locale.KOREA), 32000);
        String releaseDate = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        String dramaId = UUID.randomUUID().toString();

        DramaVersion sample = new DramaVersion(
            dramaId,
            versionName,
            supportLangs,
            price,
            releaseDate);
        sample.setReleaseNotes(releaseNotes);
        sample.setDramaContents(DramaContents.sample());

        return sample;
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "versionName":
                    this.versionName = value;
                    break;
                case "releaseNotes":
                    this.releaseNotes = LangStrings.fromJson(value);
                    break;
                case "supportLangs":
                    this.supportLangs = LangStrings.fromJson(value);
                    break;
                case "price":
                    this.price = GlobalPrice.fromJson(value);
                    break;
                case "releaseDate":
                    this.releaseDate = value;
                    break;
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
