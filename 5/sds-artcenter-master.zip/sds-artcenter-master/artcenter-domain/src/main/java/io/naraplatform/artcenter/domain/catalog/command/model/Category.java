package io.naraplatform.artcenter.domain.catalog.command.model;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class Category extends NaraEntity {
    //
    private LangStrings names;
    private LangStrings memos;
    private String catalogId;

    transient List<Item> items;

    public Category(String id) {
        //
        super(id);
    }

    public Category(Catalog catalog, LangStrings names) {
        //
        this(catalog, names, null);
    }

    public Category(Catalog catalog, LangStrings names, LangStrings memos) {
        //
        super();
        this.catalogId = catalog.getId();
        this.names = names;
        this.memos = memos;
    }

    public String toString() {
        //
        return toJson();
    }

    public static Category fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Category.class);
    }

    public static Category sample() {
        //
        Catalog catalog = Catalog.sample();
        LangStrings names = LangStrings.newString(
            Locale.KOREA.getLanguage(), "교육")
            .addString(Locale.US.getLanguage(), "Education");

        LangStrings memos = LangStrings.newString(Locale.KOREA.getLanguage(), "메모")
            .addString(Locale.US.getLanguage(), "MEMO");

        Category sample = new Category(catalog, names);
        sample.setMemos(memos);

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
