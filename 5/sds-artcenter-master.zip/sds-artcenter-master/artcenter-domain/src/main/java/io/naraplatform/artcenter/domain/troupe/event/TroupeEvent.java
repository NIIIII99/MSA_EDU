package io.naraplatform.artcenter.domain.troupe.event;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.event.NaraEvent;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class TroupeEvent extends NaraEvent {
    //
    private Troupe troupe;
    
    private TroupeEvent(EventType eventType, Troupe troupe) {
        //
        super(eventType, TroupeEvent.class.getSimpleName());
        this.troupe = troupe;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TroupeEvent fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TroupeEvent.class);
    }

    public static TroupeEvent sample() {
        //
        return TroupeEvent.buildTroupeEvent(EventType.Created, Troupe.sample());
    }

    public static TroupeEvent buildCreateEvent(Troupe troupe) {
        //
        return buildTroupeEvent(EventType.Created, troupe);
    }

    public static TroupeEvent buildUpdateEvent(Troupe troupe) {
        //
        return buildTroupeEvent(EventType.Updated, troupe);
    }

    public static TroupeEvent buildDeleteEvent(Troupe troupe) {
        //
        return buildTroupeEvent(EventType.Deleted, troupe);
    }

    private static TroupeEvent buildTroupeEvent(EventType eventType, Troupe troupe) {
        //
        return new TroupeEvent(eventType, troupe);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
