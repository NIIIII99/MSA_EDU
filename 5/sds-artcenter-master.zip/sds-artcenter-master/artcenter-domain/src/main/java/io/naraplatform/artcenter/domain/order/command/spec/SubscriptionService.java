package io.naraplatform.artcenter.domain.order.command.spec;

import io.naraplatform.artcenter.domain.order.command.spec.sdo.SubscriptionCdo;

public interface SubscriptionService {
    //
    String subscribe(SubscriptionCdo subscriptionCdo);
    // No modification allowed
    void stopSubscription(String subscriptionId);
    void resumeSubscription(String subscriptionId);
}
