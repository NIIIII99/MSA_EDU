package io.naraplatform.artcenter.domain.order.command.model;

public enum UserBase {
    //
    Square,
    Pavilion,
    Cineroom,
    UserCount
}
