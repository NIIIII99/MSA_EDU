package io.naraplatform.artcenter.domain.drama.command.spec;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.command.spec.sdo.DramaVersionCdo;
import io.naraplatform.share.domain.NameValueList;

import java.util.List;

public interface DramaService {
    //
    String registerDramaJson(String dramaJson);
    String registerDrama(Drama drama, DramaVersion dramaVersion);
    void modifyDrama(String dramaId, NameValueList nameValues);
    void removeDrama(String dramaId);

    void addVersion(DramaVersionCdo dramaVersionCdo);

    String addVersionJson(String dramaId, String versionJson);
    String addVersion(String dramaId, DramaVersion dramaVersion);
    void removeVersion(String dramaId, String versionId);
    void updateVersion(String dramaId, DramaVersion dramaVersion);

    String addFeatureJson(String dramaId, List<String> featureJsons);
    String addFeature(String dramaId, List<DramaFeature> features);
    void removeFeature(String dramaId, String featureId);
    void updateFeature(String dramaId, DramaFeature feature);
}
