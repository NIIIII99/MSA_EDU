package io.naraplatform.artcenter.domain.nation.command.model;

import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.exception.IllegalRequestException;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Nation extends NaraEntity {
    //
    // singleton (== nation)
    //
    private String defaultLang;
    private LangStrings names;
    private Contact contact;
    private NationScope scope;
    private String authKey;             // auth key from global nation
    private long time;

    public Nation(String id) {
        //
        super(id);
    }

    public Nation(LangStrings names, Contact contact) {
        //
        super();
        this.defaultLang = names.firstLang();
        this.names = names;
        this.contact = contact;
        this.scope = NationScope.Local;
        this.time = System.currentTimeMillis();
    }

    public String toString() {
        //
        return toJson();
    }

    public static Nation fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Nation.class);
    }

    public static Nation sample() {
        //
        LangStrings names = LangStrings.newString("en", "nation.app").addString("ko", "나라.앱");
        Contact contact = Contact.sample();

        Nation sample = new Nation(names, contact);
        sample.setScope(NationScope.Global);

        return sample;
    }

    public IdLangName idName() {
        //
        return new IdLangName(getId(), getNames());
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "names":
                    this.names = LangStrings.fromJson(value);
                    break;
                case "defaultLang":
                    this.defaultLang = value;
                    break;
                case "contact":
                    this.contact = Contact.fromJson(value);
                    break;
                case "scope":
                    this.scope = NationScope.valueOf(value);
                    break;
                case "authKey":
                    this.authKey = value;
                    break;
                default:
                    throw new IllegalRequestException(String.format("[%s] is not permitted property", nameValue.getName()));
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
