package io.naraplatform.artcenter.domain.nation.event;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.event.NaraEvent;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class NationEvent extends NaraEvent {
    //
    private Nation nation;
    
    private NationEvent(EventType eventType, Nation nation) {
        //
        super(eventType, NationEvent.class.getSimpleName());
        this.nation = nation;
    }

    private NationEvent(EventType eventType, String id) {
        //
        super(id, eventType, NationEvent.class.getSimpleName());
    }

    public String toString() {
        //
        return toJson();
    }

    public static NationEvent fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NationEvent.class);
    }

    public static NationEvent sample() {
        //
        return NationEvent.buildEvent(EventType.Created, Nation.sample());
    }

    public static NationEvent buildCreatedEvent(Nation nation) {
        //
        return buildEvent(EventType.Created, nation);
    }

    public static NationEvent buildUpdatedEvent(Nation nation) {
        //
        return buildEvent(EventType.Updated, nation);
    }

    public static NationEvent buildDeletedEvent(String nationId) {
        //
        return new NationEvent(EventType.Deleted, nationId);
    }

    public static NationEvent buildEvent(EventType eventType, Nation nation) {
        //
        return new NationEvent(eventType, nation);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
