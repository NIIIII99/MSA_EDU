package io.naraplatform.artcenter.domain.catalog.query.model;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class CategoryRom extends NaraEntity {
    //
    private String langCode;
    private String name;
    private String memo;
    private String catalogId;

    public CategoryRom(String id) {
        //
        super(id);
    }

    public CategoryRom(String langCode, Category category) {
        //
        super(category.getId());
        this.langCode = langCode;
        this.name = category.getNames().getString(langCode);
        if(category.getMemos() != null) {
            this.memo = category.getMemos().getString(langCode);
        }
        this.catalogId = category.getCatalogId();
    }

    public String toString() {
        //
        return toJson();
    }

    public static CategoryRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CategoryRom.class);
    }

    public static CategoryRom sample() {
        //
        String langCode = Locale.US.getLanguage();
        Category catalog = Category.sample();

        return new CategoryRom(langCode, catalog);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
