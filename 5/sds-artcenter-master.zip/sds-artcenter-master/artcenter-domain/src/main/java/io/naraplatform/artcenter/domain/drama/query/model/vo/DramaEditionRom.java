package io.naraplatform.artcenter.domain.drama.query.model.vo;


import io.naraplatform.artcenter.domain.drama.command.model.contents.DramaEdition;
import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DramaEditionRom implements ValueObject {
    //
    private String langCode;
    private String key;
    private String name;
    private String memo;

    public DramaEditionRom(String langCode, DramaEdition edition) {
        //
        this.langCode = langCode;
        this.key = edition.getKey();
        this.name = edition.getNames().getString(langCode);
        if(edition.getMemos() != null) {
            this.memo = edition.getMemos().getString(langCode);
        }
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaEditionRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaEditionRom.class);
    }

    public static DramaEditionRom sample() {
        //
        return new DramaEditionRom("en", DramaEdition.sample());
    }

    public static DramaEditionRom koSample() {
        //
        return new DramaEditionRom("ko", DramaEdition.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
        System.out.println(koSample());
    }
}
