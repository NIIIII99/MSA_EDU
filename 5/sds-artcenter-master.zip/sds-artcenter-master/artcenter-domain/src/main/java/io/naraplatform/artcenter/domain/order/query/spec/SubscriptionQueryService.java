package io.naraplatform.artcenter.domain.order.query.spec;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;

import java.util.List;

public interface SubscriptionQueryService {
    //
    Subscription findSubscription(String subscriptionId);
    List<Subscription> findSubscriptionsBySubscriber(String subscriberId);
    List<Subscription> findSubscriptionsByTeam(String teamId);
}
