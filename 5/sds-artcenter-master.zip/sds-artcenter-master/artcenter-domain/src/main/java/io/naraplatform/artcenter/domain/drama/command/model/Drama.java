package io.naraplatform.artcenter.domain.drama.command.model;


import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class Drama extends NaraEntity implements NaraAggregate {
    //
    private String defaultLang;
    private LangStrings categoryNames;
    private LangStrings titles;
    private LangStrings descriptions;
    private IdLangName troupe;
    private String base64Icon;
    private String feedbackId;
    private String date;
    // List<String> tags <-- TBD

    private String categoryId;

    transient private List<DramaVersion> versions;

    public Drama(String id) {
        //
        super(id);
    }

    public Drama(LangStrings titles, Troupe troupe, String base64Icon) {
        //
        super();      //
        this.titles = titles;
        this.descriptions = null;
        this.troupe = troupe.getIdLangName();
        this.base64Icon = base64Icon;
        this.date = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Drama sample() {
        //
        LangStrings langTitle = LangStrings.newString("ko", "나라보드").addString("en", "NaraBoard");
        byte[] icon = new byte[10];
        String base64Icon = Base64.getEncoder().encodeToString(icon);

        Drama sample = new Drama(langTitle, Troupe.sample(), base64Icon);
        sample.setCategoryNames(Category.sample().getNames());
        sample.setDefaultLang("ko");
        sample.setFeedbackId(UUID.randomUUID().toString());

        LangStrings langDescription = LangStrings.newString("ko", "나라보드설명").addString("en", "NaraBoard describe");
        sample.setDescriptions(langDescription);

        return sample;
    }

    public static Drama fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Drama.class);
    }

    public IdName idName(String lang) {
        //
        return new IdName(getId(), getTitles().getString(lang));
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "titles":
                    this.titles = LangStrings.fromJson(value);
                    break;
                case "descriptions":
                    this.descriptions = LangStrings.fromJson(value);
                    break;
                case "troupe":
                    this.troupe = IdLangName.fromJson(value);
                    break;
                case "base64Icon":
                    this.base64Icon = value;
                    break;
                case "feedbackId":
                    this.feedbackId = value;
                    break;
                case "categoryNames":
                    this.categoryNames = LangStrings.fromJson(value);
                    break;
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
