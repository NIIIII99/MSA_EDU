package io.naraplatform.artcenter.domain.drama.query.model;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.contents.DramaEdition;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class DramaFeatureRom extends NaraEntity {
    //
    private String langCode;
    private String defaultLang;
    private int index;
    private String name;
    private String description;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;

    private String dramaId;

    public DramaFeatureRom(String id) {
        //
        super(id);
    }

    public DramaFeatureRom(String langCode, DramaFeature sourceFeature) {
        //
        super(sourceFeature.getId());
        this.langCode = langCode;
        this.defaultLang = sourceFeature.getNames().firstLang();
        this.index = sourceFeature.getIndex();
        this.name = sourceFeature.getNames().getString(langCode);
        this.description = sourceFeature.getDescriptions().getString(langCode);
        this.editionKeys = sourceFeature.getEditionKeys();
        this.authorizedRoleKeys = sourceFeature.getAuthorizedRoleKeys();

        this.dramaId = sourceFeature.getDramaId();
    }

    public static List<DramaFeatureRom> newInstances(String lang, List<DramaFeature> sourceFeatures) {
        //
        List<DramaFeatureRom> dramaFeatureRoms = new ArrayList<>(sourceFeatures.size());
        for(DramaFeature dramaFeature : sourceFeatures) {
            dramaFeatureRoms.add(new DramaFeatureRom(lang, dramaFeature));
        }

        return dramaFeatureRoms;
    }


    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaFeatureRom sample() {
        //
        String lang = Locale.US.getLanguage();
        DramaFeature feature = DramaFeature.sample();
        DramaFeatureRom sample = new DramaFeatureRom(lang, feature);

        sample.getEditionKeys().addAll(DramaEdition.sampleKeys());
        return sample;
    }

    public static List<DramaFeatureRom> samples() {
        //
        return DramaFeatureRom.newInstances("en", DramaFeature.samples());
    }

    public static DramaFeatureRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaFeatureRom.class);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
