package io.naraplatform.artcenter.domain.nation.command.spec;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.share.domain.NameValueList;

public interface NationService {
    //
    String registerNation(Nation nation);
    void modifyNation(String nationId, NameValueList nameValues);
    void removeNation(String nationId);
}
