package io.naraplatform.artcenter.domain.troupe.query.spec;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;

import java.util.List;

public interface TroupeQueryService {
    //
    Troupe findTroupeSample();

    Troupe findTroupe(String troupeId);
    String findTroupeJson(String troupeId);
    Troupe findTroupeByEmail(String email);
    String findTroupeJsonByEmail(String email);
    Troupe findTroupeByLoginUserId(String loginUserId);
    String findTroupeJsonByLoginUserId(String loginUserId);
    List<Troupe> findAllTroupes(int offset, int limit);
    List<String> findAllTroupeJsons(int offset, int limit);
    boolean existTroupeByEmail(String email);
}
