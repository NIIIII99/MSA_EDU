package io.naraplatform.artcenter.domain.nation.command.model;

public enum NationScope {
    //
    Global,         // nation like a UN
    Local           // Organization local
}
