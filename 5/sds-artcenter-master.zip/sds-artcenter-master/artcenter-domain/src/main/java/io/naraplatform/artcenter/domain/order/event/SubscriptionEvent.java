package io.naraplatform.artcenter.domain.order.event;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.event.NaraEvent;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class SubscriptionEvent extends NaraEvent {
    //
    private Subscription subscription;

    private SubscriptionEvent(EventType eventType, Subscription subscription) {
        //
        super(eventType, Subscription.class.getSimpleName());
        this.subscription = subscription;
    }

    public static SubscriptionEvent buildSubscriptionCreatedEvent(Subscription subscription) {
        //
        return buildSubscriptionEvent(EventType.Created, subscription);
    }

    public static SubscriptionEvent buildSubscriptionStateChangedEvent(Subscription subscription) {
        //
        return buildSubscriptionEvent(EventType.StateChanged, subscription);
    }

    private static SubscriptionEvent buildSubscriptionEvent(EventType eventType, Subscription subscription) {
        //
        return new SubscriptionEvent(eventType, subscription);
    }

    public String toString() {
        //
        return toJson();
    }

    public static SubscriptionEvent fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubscriptionEvent.class);
    }

    public static SubscriptionEvent sample() {
        //
        return SubscriptionEvent.buildSubscriptionEvent(EventType.Created, Subscription.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
