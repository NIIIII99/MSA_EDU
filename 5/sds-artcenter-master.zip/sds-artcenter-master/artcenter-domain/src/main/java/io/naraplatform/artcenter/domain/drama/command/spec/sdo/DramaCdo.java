package io.naraplatform.artcenter.domain.drama.command.spec.sdo;

import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Base64;

@Getter
@Setter
@NoArgsConstructor
public class DramaCdo implements JsonSerializable {
    //
    private LangStrings titles;
    private String troupeId;
    private String base64Icon;
    private String categoryId;

    public DramaCdo(LangStrings titles, String troupeId, String base64Icon, String categoryId) {
        //
        this.titles = titles;
        this.troupeId = troupeId;
        this.base64Icon = base64Icon;
        this.categoryId = categoryId;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaCdo.class);
    }

    public static DramaCdo sample() {
        //
        LangStrings titles = LangStrings.newString("ko", "나라게시판").addString("en", "NaraBoard");
        String troupeId = Troupe.sample().getId();
        byte[] icon = new byte[10];
        String base64Icon = Base64.getEncoder().encodeToString(icon);
        String categoryId = Category.sample().getId();

        DramaCdo sample = new DramaCdo(titles, troupeId, base64Icon, categoryId);

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
