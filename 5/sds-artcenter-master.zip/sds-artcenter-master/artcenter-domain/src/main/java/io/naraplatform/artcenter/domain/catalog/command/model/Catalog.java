package io.naraplatform.artcenter.domain.catalog.command.model;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Catalog extends NaraEntity {
    //
    private IdLangName nation;
    private LangStrings titles;         // Several catalogs are possible.
    private LangStrings memos;
    private boolean global;             // local/global

    transient List<Category> categories;
    transient List<Item> items;

    public Catalog(String id) {
        //
        super(id);
    }

    public Catalog(Nation nation, LangStrings titles) {
        //
        super();
        this.global = false;
        this.titles = titles;
        this.nation = nation.idName();
    }

    public String toString() {
        //
        return toJson();
    }

    public static Catalog fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Catalog.class);
    }

    public static Catalog sample() {
        //
        Nation nation = Nation.sample();
        LangStrings titles = LangStrings.newString("en", "Basic Catalog").addString("ko", "기본 카탈로그");
        LangStrings memos = LangStrings.newString("en", "Basic Catalog").addString("ko", "기본 카탈로그");

        Catalog sampleCatalog = new Catalog(nation, titles);
        sampleCatalog.setMemos(memos);

        return sampleCatalog;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
