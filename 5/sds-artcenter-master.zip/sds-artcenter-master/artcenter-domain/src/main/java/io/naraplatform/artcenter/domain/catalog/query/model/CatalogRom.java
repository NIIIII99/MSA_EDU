package io.naraplatform.artcenter.domain.catalog.query.model;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class CatalogRom extends NaraEntity {
    //
    private String langCode;
    private String nationId;
    private String nationName;
    private String title;         // Several catalogs are possible.
    private String memo;
    private boolean global;         // local/global

    public CatalogRom(String id) {
        //
        super(id);
    }

    public CatalogRom(String langCode, Catalog catalog) {
        //
        super(catalog.getId());
        this.langCode = langCode;
        this.nationId = catalog.getNation().getId();
        this.nationName = catalog.getNation().idName(langCode).getName();
        this.global = false;
        this.title = catalog.getTitles().getString(langCode);
        if(catalog.getMemos() != null) {
            this.memo = catalog.getMemos().getString(langCode);
        }
    }

    public String toString() {
        //
        return toJson();
    }

    public static CatalogRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CatalogRom.class);
    }

    public static CatalogRom sample() {
        //
        String langCode = Locale.US.getLanguage();
        Catalog catalog = Catalog.sample();

        return new CatalogRom(langCode, catalog);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
