package io.naraplatform.artcenter.domain.order.command.model;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class Subscription extends NaraEntity implements NaraAggregate {
    //
    private String langCode;
    private IdName drama;
    private String base64Icon;
    private String editionName;
    private IdName dramaVersion;
    private IdName team;                // square or pavilion or cineroom
    private IdName subscriber;          // citizen
    private String startDate;
    private String endDate;
    private SubscriptionState state;

    public Subscription(String id) {
        //
        super(id);
    }

    public Subscription(String langCode,
                        Drama drama,
                        String editionName,
                        IdName dramaVersion,
                        IdName team,
                        IdName subscriber) {
        //
        super();
        this.langCode = langCode;
        this.drama = drama.idName(langCode);
        this.base64Icon = drama.getBase64Icon();
        this.editionName = editionName;
        this.dramaVersion = dramaVersion;
        this.team = team;
        this.subscriber = subscriber;
        this.startDate = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        this.state = SubscriptionState.Open;
    }

    public static Subscription fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Subscription.class);
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Subscription sample() {
        //
        String lang = Locale.US.getLanguage();
        Drama drama = Drama.sample();
        DramaVersion version = DramaVersion.sample();
        IdName dramaVersion = new IdName(version.getId(), version.getVersionName());
        String editionName = version.getDramaContents().getEditions().get(0).getNames().getString(lang);
        IdName team = new IdName("AAA-BBB-CCC", "NaraDevTeam");
        IdName subscriber = new IdName("AAA-12345", "Steve Jobs");

        Subscription sample = new Subscription(
            lang,
            drama,
            editionName,
            dramaVersion,
            team,
            subscriber
        );

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
