package io.naraplatform.artcenter.domain.catalog.command.model;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Item extends NaraEntity {
    //
    private LangStrings titles;
    private IdName dramaVersion;
    private String base64Icon;
    private IdLangName troupe;
    private GlobalPrice price;
    private String releaseDate;
    private SalesSummary salesSummary;

    private LangStrings categoryNames;
    private String catalogId;
    private String categoryId;

    public Item(String id) {
        //
        super(id);
    }

    public Item(String catalogId, Drama drama, DramaVersion version) {
        //
        super(drama.getId());
        this.titles = drama.getTitles();
        this.dramaVersion = new IdName(version.getId(), version.getVersionName());
        this.base64Icon = drama.getBase64Icon();
        this.troupe = drama.getTroupe();
        this.price = version.getPrice();
        this.releaseDate = version.getReleaseDate();
        this.categoryNames = drama.getCategoryNames();
        this.salesSummary = new SalesSummary();
        this.catalogId = catalogId;
        this.categoryId = drama.getCategoryId();
    }

    public static Item fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Item.class);
    }

    public static Item sample() {
        //
        String catalogId = Catalog.sample().getId();
        String categoryId = Category.sample().getId();
        Drama drama = Drama.sample();
        DramaVersion version = DramaVersion.sample();
        GlobalPrice globalPrice = GlobalPrice.sample();
        Item sampleItem = new Item(catalogId, drama, version);
        sampleItem.setPrice(globalPrice);
        sampleItem.setCategoryId(categoryId);
        return sampleItem;
    }

    public void update(Drama drama, DramaVersion version) {
        //
        this.titles = drama.getTitles();
        this.dramaVersion = new IdName(version.getId(), version.getVersionName());
        this.base64Icon = drama.getBase64Icon();
        this.troupe = drama.getTroupe();
        this.price = version.getPrice();
        this.releaseDate = version.getReleaseDate();
        this.categoryNames = drama.getCategoryNames();
    }

    public void updateSaleSummary(SalesSummary salesSummary) {
        //
        this.salesSummary = salesSummary;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
