package io.naraplatform.artcenter.domain.drama.query.model;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class DramaRom extends NaraEntity implements NaraAggregate {
    //
    private String dramaId;
    private String langCode;
    private String title;
    private String description;

    private IdName troupe;
    private String base64Icon;
    private String feedbackId;
    private String categoryName;

    transient private DramaVersionRom versions;

    public DramaRom(String id) {
        //
        super(id);
    }

    public DramaRom(String langCode, Drama drama) {
        //
        super(drama.getId());
        super.setVersion(drama.getVersion());
        this.dramaId = drama.getId();
        this.langCode = langCode;
        this.title = drama.getTitles().getString(langCode);
        if(drama.getDescriptions() != null) {
            this.description = drama.getDescriptions().getString(langCode);
        }
        this.troupe = drama.getTroupe().idName(langCode);
        this.base64Icon = drama.getBase64Icon();
        this.feedbackId = drama.getFeedbackId();
        this.categoryName = drama.getCategoryNames().getString(langCode);
    }

    public String toString() {
        //
        return toJson();
    }

    public static DramaRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaRom.class);
    }

    public static DramaRom sample() {
        //
        return new DramaRom(Locale.US.getLanguage(), Drama.sample());
    }

    public static DramaRom koSample() {
        //
        return new DramaRom(Locale.KOREA.getLanguage(), Drama.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
        System.out.println("====");
        System.out.println(koSample());
    }
}
