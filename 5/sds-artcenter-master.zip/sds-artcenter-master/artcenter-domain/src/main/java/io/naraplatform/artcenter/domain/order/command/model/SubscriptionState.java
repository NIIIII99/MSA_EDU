package io.naraplatform.artcenter.domain.order.command.model;

public enum SubscriptionState {
    //
    Ordered,        // 구독신청
    Open,           // 구독중
    Suspended,      // 구독일시중지
    Closed,         // 구독종료
    Cancelled       // 구독신청취소
}
