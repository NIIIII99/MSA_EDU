package io.naraplatform.artcenter.domain.order.command.model;

public enum BillType {
    //
    Free,
    OneTime,
    Monthly,
    Yearly,
    Usage
}
