package io.naraplatform.artcenter.domain.catalog.command.model;

import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Currency;
import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class SalesSummary implements ValueObject {
    //
    private double starRate;                // 추천점수: from Drama.feedbackId, 5점 만점
    private long feedbackCount;             // 추천건수
    private long subscriptionCount;         // 판매건수: from order
    private GlobalPrice salesAmount;        // 판매총액: from order
    private String date;

    public SalesSummary(double startRate,
                        long feedbackCount,
                        long subscriptionCount,
                        GlobalPrice salesAmount) {
        //
        this.starRate = startRate;
        this.feedbackCount = feedbackCount;
        this.subscriptionCount = subscriptionCount;
        this.salesAmount = salesAmount;
        this.date = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    public void newSales(GlobalPrice price) {
        //
        subscriptionCount++;
        if (salesAmount != null) {
            salesAmount = salesAmount.addPrice(price.getDefaultCurrency(), price.getPrice());
        } else {
            salesAmount = price;
        }
    }

    public String toString() {
        //
        return toJson();
    }

    public static SalesSummary fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SalesSummary.class);
    }

    public static SalesSummary sample() {
        //
        Currency currency = Currency.getInstance(Locale.KOREA);
        double amount = 12340000.0;

        GlobalPrice salesAmount = new GlobalPrice(currency, amount);
        return new SalesSummary(4.5, 120, 300, salesAmount);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
