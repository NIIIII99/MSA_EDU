package io.naraplatform.artcenter.domain.drama.command.model;

import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class DramaTicket extends NaraEntity {

    private String dramaId;
    private String troupeId;

    public DramaTicket(Drama drama) {
        //
        super();
        this.dramaId = drama.getId();
        this.troupeId = drama.getTroupe().getId();
    }

    public DramaTicket(String id) {
        //
        super(id);
    }

    public DramaTicket(String dramaId, String troupeId) {
        //
        super();
        this.dramaId = dramaId;
        this.troupeId = troupeId;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaTicket sample() {
        //
        DramaTicket sample = new DramaTicket();

        sample.setDramaId(UUID.randomUUID().toString());
        sample.setTroupeId(UUID.randomUUID().toString());

        return sample;
    }

    public static DramaTicket fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaTicket.class);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
