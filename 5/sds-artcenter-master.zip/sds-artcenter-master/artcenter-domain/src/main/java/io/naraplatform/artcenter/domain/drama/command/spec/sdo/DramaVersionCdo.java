package io.naraplatform.artcenter.domain.drama.command.spec.sdo;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class DramaVersionCdo implements JsonSerializable {

    //
    //private DramaTicket dramaTicket;
    private String ticketId;
    private DramaVersion dramaVersion;
    private List<DramaFeature> dramaFeatures;

    public DramaVersionCdo() {
        //
        dramaFeatures = new ArrayList<DramaFeature>();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaVersionCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaVersionCdo.class);
    }

    public static DramaVersionCdo sample() {
        //
        DramaVersionCdo sample = new DramaVersionCdo();

        DramaTicket dramaTicket = DramaTicket.sample();
        DramaVersion dramaVersion = DramaVersion.sample();
        DramaFeature dramaFeature = DramaFeature.sample();

        sample.setTicketId(DramaTicket.sample().getId());
        sample.setDramaVersion(dramaVersion);
        sample.getDramaFeatures().add(dramaFeature);

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }

}
