package io.naraplatform.artcenter.domain.catalog.event;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;
import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.share.event.EventType;
import io.naraplatform.share.event.NaraEvent;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class CatalogEvent extends NaraEvent {
    //
    private Catalog catalog;
    private Category category;      // catalog:category = 1:Many
    private Item item;              // catalog:item = 1:Many, catetory:item = 1:Many

    private CatalogEvent(EventType eventType, Catalog catalog) {
        //
        super(eventType, Catalog.class.getSimpleName());
        this.catalog = catalog;
    }

    private CatalogEvent(EventType eventType, Category category) {
        //
        super(eventType, Category.class.getSimpleName());
        this.category = category;
    }

    private CatalogEvent(EventType eventType, Item item) {
        //
        super(eventType, Item.class.getSimpleName());
        this.item = item;
    }

    public String toString() {
        //
        return toJson();
    }

    public static CatalogEvent fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CatalogEvent.class);
    }

    public static CatalogEvent sample() {
        //
        return CatalogEvent.buildItemChildEvent(EventType.ChildAdded, Item.sample());
    }

    public static CatalogEvent buildCatalogCreatedEvent(Catalog catalog) {
        //
        return new CatalogEvent(EventType.Created, catalog);
    }

    public static CatalogEvent buildCatalogUpdatedEvent(Catalog catalog) {
        //
        return new CatalogEvent(EventType.Updated, catalog);
    }

    public static CatalogEvent buildCatalogDeletedEvent(Catalog catalog) {
        //
        return new CatalogEvent(EventType.Deleted, catalog);
    }

    private static CatalogEvent buildCatalogEvent(EventType eventType, Catalog catalog) {
        //
        return new CatalogEvent(eventType, catalog);
    }

    public static CatalogEvent buildCategoryCreatedEvent(Category category) {
        //
        return new CatalogEvent(EventType.Created, category);
    }

    public static CatalogEvent buildCategoryUpdatedEvent(Category category) {
        //
        return new CatalogEvent(EventType.Updated, category);
    }

    public static CatalogEvent buildCategoryDeletedEvent(Category category) {
        //
        return new CatalogEvent(EventType.Deleted, category);
    }

    private static CatalogEvent buildCategoryChildEvent(EventType eventType, Category category) {
        // childAdded, childRemoved, childUpdated
        return new CatalogEvent(eventType, category);
    }

    public static CatalogEvent buildItemChildEvent(EventType eventType, Item item) {
        // childAdded, childRemoved, childUpdated
        return new CatalogEvent(eventType, item);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
