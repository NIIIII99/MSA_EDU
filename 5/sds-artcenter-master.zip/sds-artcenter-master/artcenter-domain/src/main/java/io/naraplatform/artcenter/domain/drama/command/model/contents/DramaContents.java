package io.naraplatform.artcenter.domain.drama.command.model.contents;

import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.domain.drama.DramaRole;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DramaContents implements ValueObject {
    //
    private List<DramaEdition> editions;
    private List<DramaRole> roles;

    transient List<DramaFeature> features;

    public DramaContents(List<DramaRole> roles,
                         List<DramaEdition> editions) {
        //
        super();
        this.roles = roles;
        this.editions = editions;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaContents sample() {
        //
        List<DramaEdition> editions = DramaEdition.samples();
        List<DramaRole> roles = Arrays.asList(
                DramaRole.adminSample(),
                DramaRole.userSample());

        DramaContents sample = new DramaContents(roles, editions);

        return sample;
    }

    public static DramaContents fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaContents.class);
    }

    public DramaEdition findEdition(String editionKey) {
        //
        return this.editions.stream()
            .filter(dramaEdition -> editionKey.equals(dramaEdition.getNames()))
            .findFirst()
            .orElse(null);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
