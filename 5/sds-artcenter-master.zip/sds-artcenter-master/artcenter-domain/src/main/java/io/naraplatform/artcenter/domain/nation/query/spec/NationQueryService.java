package io.naraplatform.artcenter.domain.nation.query.spec;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;

import java.util.List;

public interface NationQueryService {
    //
    Nation findNation(String nationId);
    List<Nation> findAllNations();
}
