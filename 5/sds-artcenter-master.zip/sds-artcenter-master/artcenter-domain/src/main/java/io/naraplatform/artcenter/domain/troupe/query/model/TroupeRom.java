package io.naraplatform.artcenter.domain.troupe.query.model;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TroupeRom extends NaraEntity implements NaraAggregate {
    //
    private String loginUserId;
    private String email;
    private String json;

    public TroupeRom(Troupe troupe) {
        //
        super(troupe.getId());
        this.loginUserId = troupe.getLoginUserInfo().getLoginId();
        this.email = troupe.getContact().getEmail();
        this.json = troupe.toJson();
    }

    public static TroupeRom sample() {
        //
        return new TroupeRom(Troupe.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
