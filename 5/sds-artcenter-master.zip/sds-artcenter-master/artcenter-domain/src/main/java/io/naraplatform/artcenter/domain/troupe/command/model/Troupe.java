package io.naraplatform.artcenter.domain.troupe.command.model;

import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.LoginUserInfo;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.exception.IllegalRequestException;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Troupe extends NaraEntity implements NaraAggregate {
    //
    private String defaultLang;
    private LangStrings names;          // 개발회사 또는 개인 이름
    private Contact contact;
    private LoginUserInfo loginUserInfo;
    private String homeUrl;
    private String supportUrl;
    private boolean personal;
    private Long time;

    private IdLangName square;              // if (!personal && hasSquare)

    public Troupe(String id) {
        //
        super(id);
    }

    public Troupe(LangStrings names,
                  Contact contact,
                  LoginUserInfo loginUserInfo,
                  String supportUrl) {
        //
        super();
        this.defaultLang = names.firstLang();
        this.names = names;
        this.contact = contact;
        this.loginUserInfo = loginUserInfo;
        this.supportUrl = supportUrl;
        this.personal = false;
        this.time = System.currentTimeMillis();
    }

    public static Troupe fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Troupe.class);
    }

    public static List<Troupe> fromJsons(List<String> jsons) {
        //
        if (jsons == null || jsons.size() == 0) {
            return Collections.emptyList();
        }

        List<Troupe> troupes = new ArrayList<>(jsons.size());
        for (String troupeJson : jsons) {
            troupes.add(Troupe.fromJson(troupeJson));
        }

        return troupes;
    }

    public static Troupe sample() {
        //
        LangStrings names = LangStrings.newString("en", "Namoosori").addString("ko", "나무소리");
        Contact contact = Contact.sample();
        LoginUserInfo loginUserInfo = LoginUserInfo.sample();
        String supportUrl = "www.namoosori.com/support";

        Troupe sample = new Troupe(
            names,
            contact,
            loginUserInfo,
            supportUrl);

        sample.setHomeUrl("www.namoosori.com");

        return sample;
    }

    public IdLangName getIdLangName() {
        //
        return new IdLangName(getId(), getNames());
    }

    public void setValues(NameValueList nameValues) {
        //
        for (NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "names":
                    this.names = LangStrings.fromJson(value);
                    break;
                case "contact":
                    this.contact = Contact.fromJson(value);
                    break;
                case "loginUserInfo":
                    this.loginUserInfo = LoginUserInfo.fromJson(value);
                    break;
                case "homeUrl":
                    this.homeUrl = value;
                    break;
                case "supportUrl":
                    this.supportUrl = value;
                    break;
                case "personal":
                    this.personal = Boolean.parseBoolean(value);
                    break;
                case "square":
                    this.square = IdLangName.fromJson(value);
                    break;
                default:
                    throw new IllegalRequestException(String.format("[%s] is not permitted property", nameValue.getName()));
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
