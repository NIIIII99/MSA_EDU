package io.naraplatform.artcenter.domain.catalog.command.spec;

import io.naraplatform.artcenter.domain.catalog.command.model.Catalog;
import io.naraplatform.artcenter.domain.catalog.command.model.Category;

public interface CatalogService {
    //
    String registerCatalog(Catalog catalog);
    void modifyCatalog(Catalog catalog);
    void remove(String catalogId);

    String addCategory(Category category);
    void modifyCategory(Category category);
    void removeCategory(String categoryId);
}
