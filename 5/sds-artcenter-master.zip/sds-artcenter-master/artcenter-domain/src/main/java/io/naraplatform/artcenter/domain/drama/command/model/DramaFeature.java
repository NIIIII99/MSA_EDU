package io.naraplatform.artcenter.domain.drama.command.model;

import io.naraplatform.artcenter.domain.drama.command.model.contents.DramaEdition;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DramaFeature extends NaraEntity {
    //
    private String defaultLang;
    private int index;
    private LangStrings names;
    private LangStrings descriptions;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;

    private String dramaId;

    public DramaFeature(String id) {
        //
        super(id);
    }

    public DramaFeature(Drama drama, int index, LangStrings names) {
        //
        super();
        this.defaultLang = names.firstLang();
        this.index = index;
        this.names = names;
        this.descriptions = null;
        this.editionKeys = new ArrayList<>();
        this.authorizedRoleKeys = new ArrayList<>();
        this.dramaId = drama.getId();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DramaFeature sample() {
        //
        Drama drama  = Drama.sample();
        DramaFeature sample = new DramaFeature(
            drama,
            0, LangStrings.newString("en", "BoardService").addString("ko", "보드서비스")
        );
        sample.getEditionKeys().addAll(DramaEdition.sampleKeys());
        sample.setDescriptions(LangStrings.newString("en", "BoardService").addString("ko", "보드서비스"));
        return sample;
    }

    public static List<DramaFeature> samples() {
        //
        Drama drama = Drama.sample();
        List<DramaFeature> features = new ArrayList<>();

        DramaFeature feature1 = new DramaFeature(
            drama,
            0,
            LangStrings.newString("en", "BoardService").addString("ko", "보드서비스"));
        List<String> editionKeys = DramaEdition.sampleKeys();
        editionKeys.remove(editionKeys.size()-1);
        feature1.getEditionKeys().addAll(editionKeys);
        features.add(feature1);

        DramaFeature feature2 = new DramaFeature(
            drama,
            0,
            LangStrings.newString("en", "PostingService").addString("ko", "포스팅서비스"));
        feature2.getEditionKeys().addAll(DramaEdition.sampleKeys());
        features.add(feature2);

        return features;
    }

    public static DramaFeature fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaFeature.class);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
