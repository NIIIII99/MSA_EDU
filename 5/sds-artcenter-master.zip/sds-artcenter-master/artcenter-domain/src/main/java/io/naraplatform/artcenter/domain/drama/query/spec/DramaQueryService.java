package io.naraplatform.artcenter.domain.drama.query.spec;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.artcenter.domain.drama.command.model.DramaFeature;
import io.naraplatform.artcenter.domain.drama.command.model.DramaTicket;
import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.query.model.DramaFeatureRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.artcenter.domain.drama.query.model.DramaVersionRom;

import java.util.List;

public interface DramaQueryService {
    //
    Drama findDrama(String dramaId);
    DramaTicket findDramaTicket(String dramaTicketId);
    DramaTicket findDramaTicketByDrama(String dramaId);
    DramaRom findDramaRom(String lang, String dramaId);
    DramaFeature findFeature(String featureId);
    List<DramaFeature> findFeatures(String dramaId);
    List<DramaFeatureRom> findFeatureRoms(String dramaId, String lang);
    DramaVersion findLatestVersion(String dramaId);
    List<DramaVersion> findVersions(String dramaId, int offset, int limit);
    DramaVersionRom findLatestVersionRom(String dramaId);
    List<DramaVersionRom> findVersionRoms(String dramaId, int offset, int limit);
    List<Drama> findDramaByTroupe(String troupeId, int offset, int limit);
}
