package io.naraplatform.artcenter.domain.drama.query.model;

import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DramaVersionRom extends NaraEntity {
    //
    private String langCode;

    private String versionName;                     // 1.2.1, 1.3.12
    private String releaseNote;
    private String supportLangs;
    private GlobalPrice price;
    private String releaseDate;
    private String dramaId;

    public DramaVersionRom(String id) {
        //
        super(id);
    }

    public DramaVersionRom(String langCode, DramaVersion dramaVersion) {
        //
        super(dramaVersion.getId());
        this.langCode = langCode;

        this.versionName = dramaVersion.getVersionName();
        if(dramaVersion.getReleaseNotes() != null) {
            this.releaseNote = dramaVersion.getReleaseNotes().getString(langCode);
        }
        this.supportLangs = dramaVersion.getSupportLangs().getString(langCode);
        this.price = dramaVersion.getPrice();
        this.releaseDate = dramaVersion.getReleaseDate();
        this.dramaId = dramaVersion.getDramaId();
    }

    public String toString() {
        //
        return toJson();
    }

    public static DramaVersionRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DramaVersionRom.class);
    }

    public static DramaVersionRom sample() {
        //
        return new DramaVersionRom("en", DramaVersion.sample());
    }

    public static DramaVersionRom koSample() {
        //
        return new DramaVersionRom("ko", DramaVersion.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
        System.out.println(koSample());
    }
}
