package io.naraplatform.artcenter.domain.catalog.query.model;

import io.naraplatform.artcenter.domain.catalog.command.model.Item;
import io.naraplatform.artcenter.domain.catalog.command.model.SalesSummary;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Locale;

@Getter
@Setter
@NoArgsConstructor
public class ItemRom extends NaraEntity {
    //
    private String langCode;
    private String title;
    private IdName dramaVersion;
    private String base64Icon;
    private IdName troupe;
    private GlobalPrice price;
    private String releaseDate;
    private SalesSummary salesSummary;

    private String categoryName;
    private String catalogId;
    private String categoryId;

    public ItemRom(String id) {
        //
        super(id);
    }

    public ItemRom(String langCode, Item item) {
        //
        super(item.getId());
        this.langCode = langCode;

        this.title = item.getTitles().getString(langCode);
        this.dramaVersion = item.getDramaVersion();
        this.base64Icon = item.getBase64Icon();
        this.troupe = new IdName(item.getTroupe().getId(), item.getTroupe().getNames().getString(langCode));
        this.price = item.getPrice();
        this.releaseDate = item.getReleaseDate();
        this.salesSummary = item.getSalesSummary();
        this.categoryName = item.getCategoryNames().getString(langCode);
        this.catalogId = item.getCatalogId();
        this.categoryId = item.getCategoryId();
    }

    public static ItemRom fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ItemRom.class);
    }

    public static ItemRom sample() {
        //
        String langCode = Locale.US.getLanguage();
        Item item = Item.sample();

        return new ItemRom(langCode, item);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
