package io.naraplatform.artcenter.domain.order.command.spec.sdo;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SubscriptionCdo implements JsonSerializable {
    //
    private String lang;
    private String dramaId;
    private String editionName;
    private IdName dramaVersion;
    private IdName team;
    private IdName subscriber;

    public SubscriptionCdo(String lang,
                           String dramaId,
                           String editionName,
                           String dramaVersionId,
                           String versionName,
                           IdName team,
                           IdName subscriber
                           ) {
        //
        this.lang = lang;
        this.dramaId = dramaId;
        this.editionName = editionName;
        this.dramaVersion = new IdName(dramaVersionId, versionName);
        this.team = team;
        this.subscriber = subscriber;
    }

    public String toString() {
        //
        return toJson();
    }

    public static SubscriptionCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubscriptionCdo.class);
    }

    public static SubscriptionCdo sample() {
        //
        Subscription subscription = Subscription.sample();
        SubscriptionCdo sample = new SubscriptionCdo(
            subscription.getLangCode(),
            subscription.getDrama().getId(),
            subscription.getEditionName(),
            subscription.getDramaVersion().getId(),
            subscription.getDramaVersion().getName(),
            subscription.getTeam(),
            subscription.getSubscriber()
        );

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
