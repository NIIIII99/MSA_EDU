package io.naraplatform.artcenter;

public class ArtcenterBootQueryTestApplication {
	
    public void contextLoads() {
    }

}
