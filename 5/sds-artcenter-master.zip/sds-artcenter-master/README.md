# Art Center

[![pipeline status](https://git.nextree.co.kr:8088/nara/artcenter/badges/master/pipeline.svg)](https://git.nextree.co.kr:8088/nara/artcenter/commits/master)

## Versioning

## gitlab-runner
독립적인 gitlab-runner 등록
