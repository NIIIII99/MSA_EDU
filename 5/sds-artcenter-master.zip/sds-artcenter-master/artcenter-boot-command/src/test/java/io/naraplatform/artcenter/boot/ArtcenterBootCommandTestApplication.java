package io.naraplatform.artcenter.boot;

public class ArtcenterBootCommandTestApplication {

    public void contextLoads() {
    }

}
