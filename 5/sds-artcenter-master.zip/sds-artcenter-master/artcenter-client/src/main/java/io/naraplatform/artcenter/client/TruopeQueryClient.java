package io.naraplatform.artcenter.client;

import io.naraplatform.artcenter.domain.troupe.command.model.Troupe;
import io.naraplatform.artcenter.domain.troupe.query.spec.TroupeQueryService;

import java.util.List;

public class TruopeQueryClient implements TroupeQueryService {

	@Override
	public Troupe findTroupeSample() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Troupe findTroupe(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findTroupeJson(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Troupe findTroupeByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existTroupeByEmail(String email) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String findTroupeJsonByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Troupe findTroupeByLoginUserId(String loginUserId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findTroupeJsonByLoginUserId(String loginUserId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Troupe> findAllTroupes(int offset, int limit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> findAllTroupeJsons(int offset, int limit) {
		// TODO Auto-generated method stub
		return null;
	}

}
