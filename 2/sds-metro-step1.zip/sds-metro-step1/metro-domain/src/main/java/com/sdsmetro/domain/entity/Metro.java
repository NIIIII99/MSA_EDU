package com.sdsmetro.domain.entity;

import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.NaraAggregate;
import io.naraplatform.share.domain.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Metro extends NaraEntity implements NaraAggregate {
    //
    private String name;
    private String memo;
    private String adminEmail;
    private long time;

    public Metro(String id) {
        //
        super(id);
    }

    public Metro(String name, String adminEmail) {
        //
        super();
        this.name = name;
        this.adminEmail = adminEmail;
        this.time = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "name":
                    this.name = value;
                    break;
                case "memo":
                    this.memo = value;
                    break;
                default:
                    throw new IllegalArgumentException("Update now allowed: " + nameValue);
            }
        }
    }

    public static Metro fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Metro.class);
    }

    public static Metro sample() {
        //
        String name = "SDS";
        String adminEmail = "kim@sds.com";
        String memo = "Welcome to SDS Metro";

        Metro sample = new Metro(name, adminEmail);
        sample.setMemo(memo);

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}