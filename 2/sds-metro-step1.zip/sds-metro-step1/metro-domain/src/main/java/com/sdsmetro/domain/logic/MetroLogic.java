package com.sdsmetro.domain.logic;

import com.sdsmetro.domain.entity.Metro;
import com.sdsmetro.domain.spec.MetroService;
import com.sdsmetro.domain.spec.sdo.MetroCdo;
import com.sdsmetro.domain.store.MetroStore;
import com.sdsmetro.domain.store.MetroStoreFactory;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.exception.store.AlreadyExistsException;

import java.util.NoSuchElementException;

public class MetroLogic implements MetroService {
    //
    private MetroStore metroStore;

    public MetroLogic(MetroStoreFactory storeFactory) {
        //
        this.metroStore = storeFactory.requestMetroStore();
    }

    @Override
    public String buildMetro(MetroCdo metroCdo) {
        //
        String name = metroCdo.getName();
        if (metroStore.existsByName(name)) {
            throw new AlreadyExistsException("Metro name: " + name);
        }

        Metro metro = new Metro(
                name,
                metroCdo.getAdminEmail()
        );
        metroStore.crete(metro);

        return metro.getId();
    }

    @Override
    public Metro findMetro(String metroId) {
        //
        Metro metro = metroStore.retrieve(metroId);
        if(metro == null) {
            throw new NoSuchElementException("Metro id: " + metroId);
        }

        return metro;
    }

    @Override
    public void modifyMetro(String metroId, NameValueList nameValues) {
        //
        Metro metro = findMetro(metroId);
        metro.setValues(nameValues);

        metroStore.update(metro);
    }

    @Override
    public void removeMetro(String metroId) {
        //
        Metro metro = findMetro(metroId);
        //
        // remove all citizens
        //
        metroStore.delete(metro);
    }
}