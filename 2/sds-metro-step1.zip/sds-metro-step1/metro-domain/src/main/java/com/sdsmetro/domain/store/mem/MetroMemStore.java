package com.sdsmetro.domain.store.mem;

import com.sdsmetro.domain.entity.Metro;
import com.sdsmetro.domain.store.MetroStore;

import java.util.*;

public class MetroMemStore implements MetroStore {
    //
    private Map<String,Metro> metroMap;

    public MetroMemStore() {
        //
        this.metroMap = new HashMap<>();
    }

    @Override
    public void crete(Metro metro) {
        //
        this.metroMap.put(metro.getId(), metro);
    }

    @Override
    public Metro retrieve(String id) {
        //
        return metroMap.get(id);
    }

    @Override
    public List<Metro> retrieveByAdminEmail(String adminEmail) {
        //
        List<Metro> metros = new ArrayList<>();

        Iterator<Metro> metroIter = metroMap.values().iterator();
        while(metroIter.hasNext()) {
            Metro metro = metroIter.next();
            if(metro.getAdminEmail().equals(adminEmail)) {
                metros.add(metro);
            }
        }

        return metros;
    }

    @Override
    public void update(Metro metro) {
        //
        // do nothing
    }

    @Override
    public void delete(Metro metro) {
        //
        metroMap.remove(metro.getId());
    }

    @Override
    public boolean existsByName(String name) {
        //
        boolean exist = false;

        Iterator<Metro> metroIter = metroMap.values().iterator();
        while(metroIter.hasNext()) {
            Metro metro = metroIter.next();
            if(metro.getName().equals(name)) {
                exist = true;
                break;
            }
        }

        return exist;
    }
}
