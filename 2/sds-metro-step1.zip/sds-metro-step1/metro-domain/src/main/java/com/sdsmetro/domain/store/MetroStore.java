package com.sdsmetro.domain.store;

import com.sdsmetro.domain.entity.Metro;

import java.util.List;

public interface MetroStore {
    //
    void crete(Metro metro);
    Metro retrieve(String id);
    List<Metro> retrieveByAdminEmail(String adminEmail);
    void update(Metro metro);
    void delete(Metro metro);
    boolean existsByName(String name);
}
