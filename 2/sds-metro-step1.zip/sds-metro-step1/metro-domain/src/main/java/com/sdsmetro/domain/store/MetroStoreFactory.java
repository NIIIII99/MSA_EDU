package com.sdsmetro.domain.store;

public interface MetroStoreFactory {
    //
    MetroStore requestMetroStore();
}
