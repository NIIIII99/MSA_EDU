package com.sdsmetro.domain.store.mem;

import com.sdsmetro.domain.store.MetroStore;
import com.sdsmetro.domain.store.MetroStoreFactory;

public class MetroMemStoreFactory implements MetroStoreFactory {
    //
    @Override
    public MetroStore requestMetroStore() {
        //
        return new MetroMemStore();
    }
}
