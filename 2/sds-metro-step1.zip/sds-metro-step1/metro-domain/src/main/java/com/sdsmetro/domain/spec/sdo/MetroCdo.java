package com.sdsmetro.domain.spec.sdo;

import com.sdsmetro.domain.entity.Metro;
import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MetroCdo implements JsonSerializable {
    //
    private String name;
    private String adminEmail;

    public MetroCdo(String name, String adminEmail) {
        //
        this.name = name;
        this.adminEmail = adminEmail;
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroCdo sample() {
        //
        Metro metro = Metro.sample();

        return new MetroCdo(metro.getName(), metro.getAdminEmail());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}