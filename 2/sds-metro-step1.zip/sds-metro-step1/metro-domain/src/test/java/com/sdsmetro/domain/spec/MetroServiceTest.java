package com.sdsmetro.domain.spec;

import com.sdsmetro.domain.entity.Metro;
import com.sdsmetro.domain.logic.MetroLogic;
import com.sdsmetro.domain.spec.sdo.MetroCdo;
import com.sdsmetro.domain.store.MetroStoreFactory;
import com.sdsmetro.domain.store.mem.MetroMemStoreFactory;
import io.naraplatform.share.domain.NameValueList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MetroServiceTest {
    //
    private MetroService metroService;
    private Metro metro;

    @Before
    public void setUp() throws Exception {
        //
        MetroStoreFactory storeFactory = new MetroMemStoreFactory();
        this.metroService = new MetroLogic(storeFactory);
        this.metro = Metro.sample();
    }

    @Test
    public void buildMetro() {
        //
        MetroCdo metroCdo = MetroCdo.sample();
        String metroId = metroService.buildMetro(metroCdo);
        Assert.assertNotNull(metroId);
    }

    @Test
    public void findMetro() {
        //
        MetroCdo metroCdo = MetroCdo.sample();
        String metroId = metroService.buildMetro(metroCdo);

        Metro resultMetro = metroService.findMetro(metroId);
        Assert.assertNotNull(resultMetro);
    }

    @Test
    public void modifyMetro() {
        //
        MetroCdo metroCdo = MetroCdo.sample();
        String metroId = metroService.buildMetro(metroCdo);

        String newName = "SDS Modified";
        NameValueList nameValues = new NameValueList("name", newName);
        metroService.modifyMetro(metroId, nameValues);
        Metro resultMetro = metroService.findMetro(metroId);

        Assert.assertEquals(newName, resultMetro.getName());
    }

    @Test
    public void removeMetro() {
        //
//        MetroCdo metroCdo = MetroCdo.sample();
//        String metroId = metroService.buildMetro(metroCdo);
//
//        metroService.removeMetro(metroId);
    }
}