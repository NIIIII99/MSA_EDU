package io.naraplatform.share.exception;

public class IllegalRequestException extends NaraException {
    //
    public IllegalRequestException(String message) {
        super(message);
    }
}
