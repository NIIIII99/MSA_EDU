package io.naraplatform.share.domain.enumtype;

public enum ContentType {
    //
    PlainText,
    Json,
    Xml,
    Html
}
