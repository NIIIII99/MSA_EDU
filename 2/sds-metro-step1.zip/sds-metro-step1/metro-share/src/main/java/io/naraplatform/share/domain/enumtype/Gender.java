package io.naraplatform.share.domain.enumtype;

public enum Gender {
    //
    Male,
    Female
}
