package io.naraplatform.share.restclient;


public interface NaraRestUrl {
    //
    String getUrl();

    HttpMethod getMethod();
}
