package io.naraplatform.share.domain.enumtype;

public enum NamingStyle {
    //
    DisplayName,
    MemberId,           // == employee id
    UserLoginId,
    Email,
    Nickname;
}
