package io.naraplatform.share.domain.util.numeral36;

public interface DramaShareable {
    //
    boolean isShared();
    boolean firendOf(String ceneroomId);
}