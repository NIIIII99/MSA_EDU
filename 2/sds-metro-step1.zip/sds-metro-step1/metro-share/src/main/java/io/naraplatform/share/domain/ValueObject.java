package io.naraplatform.share.domain;

import io.naraplatform.share.util.json.JsonSerializable;

public interface ValueObject extends JsonSerializable {
    // mark interface
}
