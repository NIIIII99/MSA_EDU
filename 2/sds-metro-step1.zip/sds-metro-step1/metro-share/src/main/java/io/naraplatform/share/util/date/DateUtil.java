package io.naraplatform.share.util.date;

public class DateUtil extends org.apache.commons.lang3.time.DateUtils {
    //
}
