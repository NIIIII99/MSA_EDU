package io.naraplatform.share.domain.nara;

public enum LoginIdType {
    //
    Email,
    UserId,
    MemberId,
    EmployeeId,
    RegistrationId
}
