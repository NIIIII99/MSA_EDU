package io.naraplatform.share.domain.enumtype;

public enum Marriage {
    //
    Single,
    Married,
    Divorced
}