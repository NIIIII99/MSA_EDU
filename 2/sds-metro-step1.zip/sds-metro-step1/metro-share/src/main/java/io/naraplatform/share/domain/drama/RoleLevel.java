package io.naraplatform.share.domain.drama;

public enum RoleLevel {
    //
    Admin,
    Special,
    Specific,
    Normal
}
