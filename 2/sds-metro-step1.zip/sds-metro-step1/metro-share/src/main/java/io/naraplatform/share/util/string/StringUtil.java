package io.naraplatform.share.util.string;

public class StringUtil extends org.apache.commons.lang3.StringUtils {
    //
}
