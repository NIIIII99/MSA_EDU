package io.naraplatform.share.domain;

public interface NaraAggregate {
	// mark interface
}
